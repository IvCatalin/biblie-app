# Haftarot de sărbători și ocazii speciale

Sursă: ediția Rosen, pagini tipărite 1031–1109+ (foto p162–p247).
Index calendaristic: `citiri_sarbatori.json` (toate rândurile din cele două tabele, cu Tora / maftir / pagini / fișier haftara).

Categorie JSON: `sarbatoare` | `ocazie_speciala` | `post` | `patru_parshiyot`.

## Fișiere de haftara (text)

| Fișier | Ocazie | Referință tipică | Pag. |
|---|---|---|---|
| haftarat_shabat_erev_rosh_hodesh.json | Șabat Erev Roș Hodeș | 1 Sam 20:18-42 | 1031 |
| haftarat_shabat_rosh_hodesh.json | Șabat Roș Hodeș | Isaia 66:1-24 | 1034 |
| haftarat_shabat_hanuca_1.json | Șabat Hanuca (I) | Zaharia 2:14-4:7 | 1037/1040 |
| haftarat_shekalim.json | Parașat Șekalim | 2 Regi 12:1-17 | 1045 |
| haftarat_para.json | Parașat Para | Ez. 36:16-38 | 1049 |
| haftarat_hahodesh.json | Parașat Hahodeș | Ez. 45:16-46:18 | 1052 |
| haftarat_shabat_hagadol.json | Șabat Hagadol | Maleahi 3:4-24 | 1056 |
| haftarat_pesah_1.json | Pesah ziua 1 | Iosua 3:5-7; 5:2-6:1; 6:27 | 1059 |
| haftarat_pesah_2.json | Pesah ziua 2 | 2 Regi 23:1-9, 21-25 | 1062 |
| haftarat_pesah_shabat_hol_hamoed.json | Pesah Șabat Hol Hamoed | Ez. 37:1-14 | 1064 |
| haftarat_pesah_7.json | Pesah ziua 7 | 2 Sam 22:1-51 | 1066 |
| haftarat_pesah_8.json | Pesah ziua 8 | Isaia 10:32-12:6 | 1069 |
| haftarat_shavuot_1.json | Șavuot ziua 1 | Ez. 1:1-28; 3:12 | 1072 |
| haftarat_shavuot_2.json | Șavuot ziua 2 | Habacuc 2:20-3:19 | 1075 |
| haftarat_tisha_bav_shaharit.json | Tișa Be’Av dimineață | Ier. 8:13-9:23 | 1078 |
| haftarat_zile_de_post.json | Ghedalia / 10 Tevet / 17 Tamuz / Estera / TBA minha | Isaia 55:6-56:8 | 1082 |
| haftarat_zahor.json | Parașat Zahor | 1 Sam 15:2-34 | 1082 |
| haftarat_shabat_hanuca_2.json | Șabat Hanuca (II) | 1 Regi 7:40-50 | 1082 |
| haftarat_rosh_hashana_1.json | Roș Hașana 1 | 1 Sam 1:1-2:10 | 1084 |
| haftarat_rosh_hashana_2.json | Roș Hașana 2 | Ier. 31:1-19 | 1088 |
| haftarat_yom_kippur_shaharit.json | Iom Kipur dimineață | Isaia 57:14-58:14 | 1091 |
| haftarat_yom_kippur_minha.json | Iom Kipur după-amiază | Iona + Mica 7:18-20 | 1093 |
| haftarat_sucot_1.json | Sucot 1 | Zaharia 14:1-21 | 1099 |
| haftarat_sucot_2.json | Sucot 2 | 1 Regi 8:2-21 | 1102 |
| haftarat_sucot_shabat_hol_hamoed.json | Sucot Șabat Hol Hamoed | Ez. 38:18-39:16 | 1104 |
| haftarat_shemini_atzeret.json | Șemini Ațeret | 1 Regi 8:54-66 | 1107 |
| haftarat_simhat_tora.json | Simhat Tora | Iosua 1:1-18 | 1109 |

Zilele de Hol Hamoed fără Șabat și zilele de Hanuca lucrătoare **nu au haftara**.
