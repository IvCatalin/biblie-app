# Haftarot Numeri / Bamidbar — lista finală

Categorie: ciclul săptămânal (nu sărbători).
Sursă: ediția Rosen, pagini tipărite 975–1004.
Behukotai se oprește sus pe pag. 975. Devarim începe pag. 1005 — nu e inclus.

| # | Fișier | Parasha | Referință | Versete | Pagini tipărite | Foto |
|---|---|---|---|---|---|---|
| 1 | haftarat_bamidbar.json | Bamidbar | Hoșea 2:1-22 | 22 | 975–977 | p106–p108 |
| 2 | haftarat_naso.json | Naso | Judecători 13:2-25 | 24 | 978–980 | p109–p111 |
| 3 | haftarat_behaalotecha.json | Behaalotha | Zaharia 2:14-4:7 | 21 | 981–983 | p112–p114 |
| 4 | haftarat_selah.json | Șelah | Ioșua 2:1-24 | 24 | 983–986 | p114–p117 |
| 5 | haftarat_korah.json | Korah | Samuel I 11:14-12:22 | 24 | 986–989 | p117–p120 |
| 6 | haftarat_hukat.json | Hukat | Judecători 11:1-33 | 33 | 990–993 | p121–p124 |
| 7 | haftarat_balak.json | Balak | Mica 5:6-6:8 | 17 | 994–995 | p125–p126 |
| 8 | haftarat_pinhas.json | Pinhas | Regi I 18:46-19:21 | 22 | 996–998 | p127–p129 |
| 9 | haftarat_matot.json | Matot | Ieremia 1:1-2:3 | 22 | 999–1001 | p130–p132 |
| 10 | haftarat_masei.json | Masēi | Ieremia 2:4-28; 3:4; 4:1-2 (+ Isaia 66:1,23) | 30 | 1001–1004 | p132–p135 |

Total fișiere: 10. Total versete (sumă fișiere): 239.

Note tradiție (din volum):
- Hukat+Balak împreună: se citește haftara Balak (pag. 994).
- Pinhas după 17 Tamuz: de obicei omisă când Matot+Masēi se unesc; se citește Matot.
- Masēi: unele comunități se opresc la 2:28; așkenazii adaugă 3:4; sefarzi/Chabad adaugă și 4:1-2. Când Roș Hodeș Av cade sâmbăta, unele comunități adaugă Isaia 66:1 și 66:23 (incluse la finalul fișierului Masēi).

Ilizibil: nicio pagină din interval nu e ilizibilă în întregime. Degetul acoperă ocazional ultima linie de transliterare.
