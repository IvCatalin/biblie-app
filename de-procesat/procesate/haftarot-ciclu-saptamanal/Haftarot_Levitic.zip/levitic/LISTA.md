# Haftarot Levitic / Vaikra — lista finală

Categorie: ciclul săptămânal (nu sărbători).
Sursă: ediția Rosen, pagini tipărite 945–975.
Bamidbar începe jos pe pag. 975 — nu e inclus.

| # | Fișier | Parasha | Tradiție | Referință | Versete | Pagini tipărite | Foto |
|---|---|---|---|---|---|---|---|
| 1 | haftarat_vaikra.json | Vaikra | comună | Isaia 43:21–44:23 | 31 | 945–948 | p075–p078 |
| 2 | haftarat_tav.json | Țav | comună (+ notă Chabad) | Ieremia 7:21–8:3; 9:22–23 | 19 | 949–951 | p079–p081 |
| 3 | haftarat_semini_sefard.json | Șemini | sefard + Chabad | Samuel II 6:1–19 | 19 | 952–954 | p082–p085 |
| 4 | haftarat_semini_askenaz.json | Șemini | așkenaz | Samuel II 6:1–7:17 | 40 | 952–956 | p082–p087 |
| 5 | haftarat_tazria.json | Tazria | comună | Regi II 4:42–5:19 | 22 | 957–959 | p088–p090 |
| 6 | haftarat_metzora.json | Mețora | comună | Regi II 7:3–20 | 18 | 960–962 | p091–p093 |
| 7 | haftarat_aharei_mot.json | Aharéi Mot | sefard; așk. separat; Aharéi+Kedoșim împreună (sef.) | Amos 9:7–15 | 9 | 963–964 | p094–p095 |
| 8 | haftarat_kedosim_askenaz.json | Kedoșim | așkenaz | Ezechiel 22:1–16 | 16 | 964–966 | p095–p097 |
| 9 | haftarat_kedosim_sefard.json | Kedoșim | sefard + Chabad | Ezechiel 20:2–20 | 19 | 966–968 | p097–p099 |
| 10 | haftarat_emor.json | Emor | comună | Ezechiel 44:15–31 | 17 | 968–970 | p099–p101 |
| 11 | haftarat_behar.json | Behar | comună | Ieremia 32:6–27 | 22 | 970–973 | p101–p104 |
| 12 | haftarat_behukotai.json | Behukotai | comună | Ieremia 16:19–17:14 | 17 | 973–975 | p104–p106 |

Total fișiere pericope: 12.
Total versete (sumă fișiere): 249.

## Pagini
Șirul tipărit 945–975 este continuu (foto p075–p106). Nicio pagină lipsă.

## Ilizibil / neclar
Nicio pagină din intervalul Levitic nu e ilizibilă în întregime. Degetul acoperă ocazional ultima linie de transliterare de subsol; acolo transliterarea e aliniată la ebraica de pe aceeași pagină.

## Nu e inclus (intenționat)
- Binecuvântările de dinaintea ciclului
- Comentariul introductiv Rosen de pe fiecare titlu
- Lexicon, Septuaginta, trimiteri
- Haftarot de sărbători
- Bamidbar (începe pag. 975) — cartea următoare
