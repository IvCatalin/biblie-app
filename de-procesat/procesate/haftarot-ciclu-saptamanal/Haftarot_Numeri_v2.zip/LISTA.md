# Haftarot Numeri — v2 (text identic cu pagina)

| # | Fișier | Pagini | Foto | Control |
|---|---|---|---|---|
| 1 | haftarat_bamidbar.json | 975–977 | p106–p108 | pag. 975 ✔ \| 976 ✔ \| 977 ✔ — [ILIZIBIL]: niciunul |
| 2 | haftarat_naso.json | 978–980 | p109–p111 | pag. 978 ✔ \| 979 ✔ \| 980 ✔ — [ILIZIBIL]: niciunul |
| 3 | haftarat_behaalotecha.json | 981–983 | p112–p114 | pag. 981 ✔ \| 982 ✔ \| 983 ✔ — [ILIZIBIL]: niciunul |
| 4 | haftarat_selah.json | 983–986 | p114–p117 | pag. 983 ✔ \| 984 ✔ \| 985 ✔ \| 986 ✔ — [ILIZIBIL]: niciunul |
| 5 | haftarat_korah.json | 986–989 | p117–p120 | pag. 986 ✔ \| 987 ✔ \| 988 ✔ \| 989 ✔ — [ILIZIBIL]: niciunul |
| 6 | haftarat_hukat.json | 990–993 | p121–p124 | pag. 990 ✔ \| 991 ✔ \| 992 ✔ \| 993 ✔ — [ILIZIBIL]: niciunul |
| 7 | haftarat_balak.json | 994–995 | p125–p126 | pag. 994 ✔ \| 995 ✔ — [ILIZIBIL]: niciunul |
| 8 | haftarat_pinhas.json | 996–998 | p127–p129 | pag. 996 ✔ \| 997 ✔ \| 998 ✔ — [ILIZIBIL]: niciunul |
| 9 | haftarat_matot.json | 999–1001 | p130–p132 | pag. 999 ✔ \| 1000 ✔ \| 1001 ✔ — [ILIZIBIL]: niciunul |
| 10 | haftarat_masei.json | 1001–1004 | p132–p135 | pag. 1001 ✔ \| 1002 ✔ \| 1003 ✔ \| 1004 ✔ — [ILIZIBIL]: niciunul |
