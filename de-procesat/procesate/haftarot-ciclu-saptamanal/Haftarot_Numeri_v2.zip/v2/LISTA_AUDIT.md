# Audit v2 — text identic cu pagina tipărită

## Levitic (doar cele cerute)

| Fișier | Pagini | Foto | Control |
|---|---|---|---|
| haftarat_behar.json | 970–973 | p101–p104 | pag. 970 ✔ \| pag. 971 ✔ \| pag. 972 ✔ \| pag. 973 ✔ — [ILIZIBIL]: niciunul |
| haftarat_behukotai.json | 973–975 | p104–p106 | pag. 973 ✔ \| pag. 974 ✔ \| pag. 975 ✔ — [ILIZIBIL]: niciunul |

## Numeri

| Fișier | Pagini | Foto | Control |
|---|---|---|---|
| haftarat_bamidbar.json | 975–977 | p106–p108 | pag. 975 ✔ \| pag. 976 ✔ \| pag. 977 ✔ — [ILIZIBIL]: niciunul |
| haftarat_naso.json | 978– | p109– | ÎN LUCRU |
| restul 8 | | | nerefăcute încă |

## Deuteronom

Nerefăcute încă (10 fișiere).

## Sărbători

Nerefăcute încă.

Regula: fiecare pagină e recitită după transcriere. Nu se livrează fișierul până nu e bifat.
