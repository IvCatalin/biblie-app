# Haftarot Deuteronom — v2 (text identic cu pagina)

| # | Fișier | Pagini | Foto | Control |
|---|---|---|---|---|
| 1 | haftarat_devarim.json | 1005–1007 | p136–p138 | pag. 1005 ✔ \| 1006 ✔ \| 1007 ✔ — [ILIZIBIL]: niciunul |
| 2 | haftarat_vaethanan.json | 1007–1009 | p138–p140 | pag. 1007 ✔ \| 1008 ✔ \| 1009 ✔ — [ILIZIBIL]: niciunul |
| 3 | haftarat_ekev.json | 1010–1013 | p141–p144 | pag. 1010 ✔ \| 1011 ✔ \| 1012 ✔ \| 1013 ✔ — [ILIZIBIL]: niciunul |
| 4 | haftarat_ree.json | 1013–1015 | p144–p146 | pag. 1013 ✔ \| 1014 ✔ \| 1015 ✔ — [ILIZIBIL]: niciunul |
| 5 | haftarat_softim.json | 1015–1018 | p146–p149 | pag. 1015 ✔ \| 1016 ✔ \| 1017 ✔ \| 1018 ✔ — [ILIZIBIL]: niciunul |
| 6 | haftarat_ki_tete.json | 1018–1019 | p149–p150 | pag. 1018 ✔ \| 1019 ✔ — [ILIZIBIL]: niciunul |
| 7 | haftarat_ki_tavo.json | 1019–1021 | p150–p152 | pag. 1019 ✔ \| 1020 ✔ \| 1021 ✔ — [ILIZIBIL]: niciunul |
| 8 | haftarat_nitzavim.json | 1022–1024 | p153–p155 | pag. 1022 ✔ \| 1023 ✔ \| 1024 ✔ — [ILIZIBIL]: niciunul |
| 9 | haftarat_vaieleh.json | 1024–1027 | p155–p158 | pag. 1024 ✔ \| 1025 ✔ \| 1026 ✔ \| 1027 ✔ — [ILIZIBIL]: niciunul |
| 10 | haftarat_haazinu.json | 1028–1031 | p159–p162 | pag. 1028 ✔ \| 1029 ✔ \| 1030 ✔ \| 1031 ✔ — [ILIZIBIL]: niciunul |
