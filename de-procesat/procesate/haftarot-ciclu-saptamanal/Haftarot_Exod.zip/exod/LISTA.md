# Haftarot Exod / Șemot — lista finală

Categorie: ciclul săptămânal (nu sărbători).
Sursă: ediția Rosen, pagini tipărite 908–945.
Geneza se oprește pe pag. 908 (final Vaihi). Vaikra începe jos pe pag. 945 — nu e inclusă.

| # | Fișier | Parasha | Tradiție | Referință | Versete | Pagini tipărite | Foto |
|---|---|---|---|---|---|---|---|
| 1 | haftarat_semot_askenaz.json | Șemot | așkenaz | Isaia 27:6–28:13; 29:22–23 | 23 | 908–910 | p039–p041 |
| 2 | haftarat_semot_sefard.json | Șemot | sefard | Ieremia 1:1–2:3 | 22 | 911–913 | p042–p044 |
| 3 | haftarat_vaera.json | Vaera | comună | Ezechiel 28:25–29:21 | 23 | 913–916 | p044–p047 |
| 4 | haftarat_bo.json | Bo | comună | Ieremia 46:13–28 | 16 | 916–918 | p047–p049 |
| 5 | haftarat_besalah.json | Beșalah | așk. 4:4 / sef. 5:1 | Judecători 4:4–5:31 | 52 | 918–924 | p049–p054 + page-924.jpeg |
| 6 | haftarat_itro.json | Itro | așk. complet; sef./Chabad până la 6:13 | Isaia 6:1–7:6; 9:5–6 | 21 | 924–926 | page-924 + p055–p056 |
| 7 | haftarat_mispatim.json | Mișpatim | comună | Ieremia 34:8–22; 33:25–26 | 17 | 927–929 | p057–p059 |
| 8 | haftarat_teruma.json | Teruma | comună | Regi I 5:26–6:13 | 20 | 929–931 | p059–p061 |
| 9 | haftarat_tetzave.json | Tețave | comună | Ezechiel 43:10–27 | 18 | 932–934 | p062–p064 |
| 10 | haftarat_ki_tisa.json | Ki Tisa | așk. de la 18:1; sef./Chabad de la 18:20 | Regi I 18:1–39 | 39 | 934–939 | p064–p069 |
| 11 | haftarat_vaiakhel_sefard.json | Vaiakhél | sefard + Chabad | Regi I 7:13–26 | 14 | 939–941 | p069–p071 |
| 12 | haftarat_vaiakhel_askenaz.json | Vaiakhél | așkenaz (și Hanuca când e dublu Șabat) | Regi I 7:40–50 | 11 | 941–942 | p071–p072 |
| 13 | haftarat_pekudei.json | Pekudēi | așkenaz | Regi I 7:51–8:21 | 22 | 943–945 | p073–p075 |

Total fișiere pericope: 13.
Total versete (sumă fișiere): 298.

## Pagini
Șirul tipărit 908–945 este continuu.
Pagina 924 nu e `p055`, ci fișierul separat `ordered/page-924.jpeg` (Beșalah 5:30–31 + început Itro 6:1–4). Semnalat, nu presupus.

## Ilizibil / neclar
Nicio pagină din intervalul Exod nu e ilizibilă în întregime. Degetul acoperă ocazional ultima linie de transliterare de subsol (ex. p048, p064); acolo transliterarea e aliniată la ebraica de pe aceeași pagină, nu inventată din altă ediție.

## Nu e inclus (intenționat)
- Binecuvântările de dinaintea ciclului
- Comentariul introductiv Rosen de pe fiecare titlu
- Lexicon, Septuaginta, trimiteri
- Haftarot de sărbători (vin după Deuteronom în volum)
- Vaikra (începe pag. 945) — cartea următoare
