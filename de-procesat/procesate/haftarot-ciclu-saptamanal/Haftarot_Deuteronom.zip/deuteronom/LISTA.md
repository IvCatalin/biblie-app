# Haftarot Deuteronom / Devarim — lista finală

Categorie: ciclul săptămânal (nu sărbători speciale).
Sursă: ediția Rosen, pagini tipărite 1005–1031.
Masēi se oprește pag. 1004. De la pag. 1031 începe Șabat Erev Roș Hodeș — nu e inclus.

| # | Fișier | Parasha | Referință | Pagini | Foto |
|---|---|---|---|---|---|
| 1 | haftarat_devarim.json | Devarim | Isaia 1:1-27 | 1005–1007 | p136–p138 |
| 2 | haftarat_vaethanan.json | Vaethanan | Isaia 40:1-26 | 1007–1009 | p138–p140 |
| 3 | haftarat_ekev.json | Ékev | Isaia 49:14-51:3 | 1010–1012 | p141–p143 |
| 4 | haftarat_ree.json | Reē | Isaia 54:11-55:5 | 1013–1014 | p144–p145 |
| 5 | haftarat_softim.json | Șoftim | Isaia 51:12-52:12 | 1015–1018 | p146–p149 |
| 6 | haftarat_ki_tete.json | Ki Țețe | Isaia 54:1-10 | 1018–1019 | p149–p150 |
| 7 | haftarat_ki_tavo.json | Ki Tavo | Isaia 60:1-22 | 1019–1021 | p150–p152 |
| 8 | haftarat_nitzavim.json | Nițavim | Isaia 61:10-63:9 | 1022–1024 | p153–p155 |
| 9 | haftarat_vaieleh.json | Vaiēleh | Hoșea 14:2-10; Ioel 2:11-27; Mica 7:18-20 | 1024–1027 | p155–p158 |
| 10 | haftarat_haazinu.json | Haazinu | Samuel II 22:1-51 | 1028–1031 | p159–p162 |

Note:
- Devarim e ultima din telat depuranuta.
- Vaethanan–Nițavim = șeva denehemta.
- Vaiēleh în acest volum = haftara de Șabat Șuva (când e separat). Sefarzi/Chabad omites 2:11 și sar la Mica.
- Haazinu în Șabat Șuva: se citește Vaiēleh; după Iom Kipur: haftara de mai jos (2 Sam 22).
- Vezot Haberacha nu e în ciclul săptămânal al volumului aici (e la Simhat Tora, după secțiunea de sărbători).

Ilizibil: nicio pagină ilizibilă în întregime.
