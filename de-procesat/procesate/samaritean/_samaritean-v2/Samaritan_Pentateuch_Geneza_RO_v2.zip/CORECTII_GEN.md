# Corecții Geneza — audit A/B/C (text samaritean)

`samaritan_hebrew` neschimbat. 1533 versete, 50 capitole. Structura cu `english` păstrată.

## Partea A
- **Geneza 30:36** — adaosul visului (îngerul, țapii brăzdați, Bet-El, întoarcerea). Româna avea doar prima frază.

## Partea B (conținut SP ≠ TM; româna urma TM)
- **2:2** — lucrarea isprăvită în ziua a **șasea** (nu a șaptea).
- **4:8** — vorbirea lui Cain: „Haidem la câmp.”
- **5:18–20** Iared: 62 / 785 / 847 (nu 162 / 800 / 962).
- **5:25–27** Metușelah: 67 / 653 / 720 (nu 187 / 782 / 969).
- **5:28, 30–31** Lameh: 53 / 600 / 653 (nu 182 / 595 / 777).
- **10:4** Rodanim (nu Dodanim).
- **11:11** + toate zilele lui Șem 600 și a murit.
- **11:12–25** vârstele SP (Arpahșad 135+303=438; Șelah 130+303=433; Ever 134+270=404; Peleg 130+109=239; Reu 132+107=239; Serug 130+100=230; Nahor 79+69=148), plus formula „toate zilele… și a murit”.
- **11:31** Milca și Nahor incluși.
- **17:14** tăierea împrejur **în ziua a opta**.
- **19:12** îngerii (nu „oamenii”).
- **20:13** + „din țara nașterii mele”.
- **31:13** „ai uns o piatră stâlp” (nu libație).
- **36:2** Ana, **fiul** lui Țibeon.
- **47:21** poporul făcut **robi** (nu mutat în cetăți).
- **48:16** **Împăratul** care răscumpără (`המלך`, nu „îngerul”).
- **49:14** măgar al celor **pribegi** (`גרים`, nu „ciolănos”).

## Partea C
Nu s-au retradus versete doar pentru stil; s-au atins doar locurile unde româna nu urma ebraica samariteană.

## Tur 2 (completare B)
- 2:4 ordine „cerurile și pământul”
- 2:19 עוד = „a mai plăsmuit”
- 3:6 ויאכלו = „au mâncat”
- 7:3 păsările **curate**
- 15:21 + hivit
- 22:13 איל אחד = un berbec (nu „după aceea”)
- 46:13 Iașub (nu Iov)
- 46:16 Țafon, Adi
- 46:21 Ahim, Mappim, Appim
- 49:10 דגליו = steagurile; שלה = Șela
- 49:11 עירו = cetatea lui (nu asinul)
- 49:22 בני צעירי = fiii tinereții
- 49:26 ואמך + הרי עד = mama + munții veșnici
