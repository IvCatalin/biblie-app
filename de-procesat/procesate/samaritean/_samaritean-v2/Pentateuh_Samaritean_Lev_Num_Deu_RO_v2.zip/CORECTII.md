# Corecții v2 — Partea A (retraducere integrală din ebraica samariteană)

Versete modificate: 37

- Levitic 1:10
- Levitic 4:5
- Levitic 5:6
- Levitic 7:3
- Levitic 10:6
- Levitic 15:3
- Levitic 17:4
- Numeri 4:14
- Numeri 10:10
- Numeri 12:16
- Numeri 13:33
- Numeri 14:40
- Numeri 14:45
- Numeri 20:13
- Numeri 21:11
- Numeri 21:20
- Numeri 21:22
- Numeri 21:23
- Numeri 21:24
- Numeri 24:4
- Numeri 26:40
- Numeri 27:23
- Numeri 28:27
- Numeri 31:20
- Numeri 32:6
- Numeri 32:25
- Numeri 32:29
- Numeri 32:31
- Deuteronom 2:7
- Deuteronom 2:11
- Deuteronom 5:21
- Deuteronom 10:8
- Deuteronom 11:6
- Deuteronom 14:8
- Deuteronom 22:1
- Deuteronom 22:4
- Deuteronom 34:4

# Partea B (diferențe de conținut corectate)

- Numeri 10:6
- Numeri 11:32
- Numeri 13:21
- Numeri 14:12
- Numeri 20:17
- Numeri 21:5
- Numeri 25:4
- Numeri 26:10
- Numeri 31:15
- Numeri 32:1
- Numeri 32:2
- Deuteronom 1:8
- Deuteronom 1:44
- Deuteronom 8:18
- Deuteronom 9:12
- Deuteronom 10:6
- Deuteronom 10:7
- Deuteronom 16:8
- Deuteronom 20:17
- Deuteronom 21:2

# Partea C (retraducere independentă față de Cornilescu)

- Levitic 8:4
- Levitic 19:30
- Levitic 26:2
- Numeri 6:24
- Numeri 11:2
- Numeri 16:25
- Numeri 21:19
- Numeri 22:39
- Numeri 27:5
- Numeri 32:34
- Numeri 32:35
- Numeri 33:11
- Deuteronom 4:4
- Deuteronom 4:24
- Deuteronom 5:6
- Deuteronom 5:20
- Deuteronom 6:13
- Deuteronom 6:16
- Deuteronom 7:18
- Deuteronom 8:6
- Deuteronom 10:19
- Deuteronom 10:20
- Deuteronom 18:19
- Deuteronom 20:13
- Deuteronom 21:19
- Deuteronom 22:5
- Deuteronom 24:19
- Deuteronom 25:10
- Deuteronom 25:16
- Deuteronom 25:17
- Deuteronom 26:3
- Deuteronom 26:4
- Deuteronom 26:6
- Deuteronom 26:9
- Deuteronom 26:15
- Deuteronom 27:12
- Deuteronom 27:13
- Deuteronom 28:3
- Deuteronom 28:23
- Deuteronom 30:17
- Deuteronom 31:6
- Deuteronom 31:15
- Deuteronom 31:25
- Deuteronom 31:26
- Deuteronom 32:1
- Deuteronom 32:3
- Deuteronom 32:4
- Deuteronom 32:10
- Deuteronom 32:11
- Deuteronom 32:12
- Deuteronom 32:38
- Deuteronom 32:40
- Deuteronom 32:44
- Deuteronom 32:47
- Deuteronom 32:48
- Deuteronom 32:49
- Deuteronom 34:5

- Numeri 10:15
- Numeri 10:16
- Numeri 10:19
- Numeri 10:20
- Numeri 10:27

# Audit Partea B (tur complet, diferențe de conținut)

- Levitic: 32 versete corectate după coloana samariteană
- Numeri: 30 versete corectate după coloana samariteană
- Deuteronom: 21 versete corectate după coloana samariteană

Nu s-a modificat samaritan_hebrew. Numerotarea versetelor neschimbată.
