# Corecții Exod — audit A/B/C (text samaritean)

Ebraica `samaritan_hebrew` nu a fost modificată. 1203 versete, 40 capitole. Structura cu `english` păstrată (modelul Exodului).

## Partea A — adaosuri SP retraduse integral

- Exod 7:18 — vestirea lui Moise și Aaron înaintea lovirii apelor
- Exod 7:29 — vestirea înaintea urgiei broaștelor
- Exod 8:1 — porunca lui Moise către Aaron (adaos)
- Exod 8:19 — vestirea roiurilor + deosebirea Goșen
- Exod 9:5 — vestirea urgiei vitelor
- Exod 9:19 — vestirea grindinei (text lung SP)
- Exod 10:2 — vestirea lăcustelor
- Exod 11:3 — miezul nopții, întâiul născut, cuvântul către Faraon
- Exod 18:24 — cuvântarea lui Moise către popor (paralel Deut. 1)
- Exod 18:25 — numirea judecătorilor + poruncile de judecată
- Exod 20:17 — Decalog + altarul de pe Garizim (retradus; „soarelui-apune”, nu răsărit)
- Exod 26:35 — așezarea mesei/sfeșnicului + tot altarul tămâiei (MT 30:1–10, mutat aici în SP)

## Partea B — aliniere de conținut

- Exod 30:11–38 — româna era decalată cu un verset (pentru că MT 30:1–10 stă în SP la 26:35). Fiecare verset are acum româna propriului ebraic. 30:38 avea textul lui 30:37; a primit traducerea lui 30:38.
- Exod 20:17 — `מבוא השמש` = drumul soarelui-apune (apus), nu răsărit; Sihem / Garizim păstrate.

## Partea C

Notele HTML din 20:17 au fost scoase la retraducere. Restul fișierului păstrează registrul Exodului existent (inclusiv notele acolo unde erau).

## Neschimbat

- `samaritan_hebrew`
- numerotarea samariteană (cap. 30 începe la v. 11; cap. 20 are 26 versete)
- câmpurile `english` / `english_alignment_status`
