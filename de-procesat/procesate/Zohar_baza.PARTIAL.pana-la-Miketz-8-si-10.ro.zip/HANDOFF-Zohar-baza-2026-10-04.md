# HANDOFF — Zohar de bază, română literală
Data: 2026-10-04. Conversația veche e prea lungă. Lucrul continuă într-o conversație nouă din același proiect.

## Ce să faci la primul mesaj
1. Citește acest fișier.
2. Nu retraduce ce e deja în zip.
3. Continuă de la **Zohar, Miketz cap. 9** (Sefaria). Cap. 10 e deja scris. După 9 urmează 11, apoi până la 17. Cap. 18 pe Sefaria sare la Vayigaș.
4. Nu pune JSON-ul în chat. Salvează fișierul în `artifacts/`. Zip nou abia când se închide o pericopă, sau când utilizatorul cere explicit.
5. Nu întreba „vrei să continui?”. Un mesaj = un lot scris pe disc. Conversația nu poate rula singură după ce răspunsul s-a închis. Nu programa din oră în oră.

## Unde s-a oprit
- Închise: Introducere, Bereșit, Noaḥ, Lekh Lekha, Vayera, Ḥayei Sarah, Toldot, Vayețe, Vayișlaḥ, Vayeșev.
- Miqeț în curs: cap. 1–8 și 10 scrise (133 unități). **Lipsește cap. 9 (31 unități pe Sefaria), apoi 11–17.**
- Următoarea pericopă după Miqeț: `Zohar,_Vayigash`.
- Zip de bază, starea de acum: `zips/Zohar_baza.PARTIAL.pana-la-Miketz-8-si-10.ro.zip` (64 JSON, 4146 unități). Nu e închiderea Zoharului.

## Numere audit (2026-10-04)
| Pericopă | Unități | Stare |
|---|---|---|
| Introduction | 260 | închis |
| Bereșit | 930 | închis |
| Noaḥ | 388 | închis |
| Lekh Lekha | 476 | închis |
| Vayera | 513 | închis |
| Ḥayei Sarah | 270 | închis |
| Toldot | 208 | închis |
| Vayețe | 401 | închis |
| Vayișlaḥ | 282 | închis |
| Vayeșev | 285 | închis (cap. 1–25; cap. 26 sare la Miqeț) |
| Miqeț | 133 | deschis: 1–8 și 10. Lipsește 9, apoi 11–17 |

Toldot cap. 19 e spart în două fișiere (`sec19.p1-35` și `sec19.p36-70`). Versetele din al doilea încep la 36. Nu e gol.

## Standard (obligatoriu)
- Sursă: textul aramaic/ebraic de pe Sefaria, Zohar de bază, nu Sulam, nu comentariu. Public Domain (Mantua 1558 / Vilna).
- Link tip: `https://www.sefaria.org/Zohar,_Miketz.9.1?lang=he`
- Traducere directă. Fără parafrază, fără adaos, fără propoziții despre proces în textul tradus. 100% text confirmat din sursă.
- O unitate Sefaria = o intrare `verse`. Nu grupa. Nu renumerota. Nu umple goluri.
- Dacă un capitol lipsește real (redirect la pericoapa următoare), scrie-l în `notes`.
- Parantezele din ediție (נ״א, ד״א, ס״א, ז״ח, ע״כ) se traduc și se marchează ca din sursă.
- Termeni stabili: YHVH, Elohim, Șekhinah, ṭadiq, yeṭer ha-ra, ghehinom, Mițrayim, Yosef, Iaakov, Shimʿon, Binyamin, Parʿoh.
- Înainte de salvare: audit JSON (numere succesive 1…n în interiorul capitolului, fără text gol).

## Schema fișier
Nume: `Zohar.Miketz.sec9.ro.json` sau `Zohar.Miketz.sec11-12.ro.json`.

```json
{
  "translation": "Zohar — Miqeț, secțiunea Sefaria 9 (N unități)",
  "source": "https://www.sefaria.org/Zohar,_Miketz.9.1?lang=he",
  "source_status": "Public Domain (text aramaic clasic; paginare Vilna; Mantua 1558 / Vilna. Nu Sulam)",
  "modernization": "Traducere directă din aramaică/ebraică, textul Zohar de pe Sefaria (vocalizat pe baza ediției clasice)",
  "book": "ספר הזהר",
  "chapters": [
    {
      "chapter": 9,
      "title": "titlu scurt din primul verset",
      "verses": [
        {"verse": 1, "text": "textul tradus, întreg"}
      ]
    }
  ],
  "notes": ["goluri reale, versiuni din ediție"]
}
```

## Cum se ia textul
API-ul Sefaria dă 403. Deschide pagina `?lang=he` și ia paragrafele marcate cu litere ebraice (א, ב, …). Nu traduce din engleză.

## Ce nu se atinge
- Zohar Ḥadash: închis, zip separat. Nu se reface.
- Maamar Zohar HaRakia: nu se atinge.
- Sulam și orice traducere cu copyright: interzis.

## Livrare
- În chat: o propoziție (interval, unități, următorul capitol). Fără JSON.
- Zip de pericopă când Miqeț 1–17 e complet și auditat, apoi la fel pentru Vayigaș și restul.
- Zip-mamă al Zoharului de bază abia când tot nodul de bază e gata, sau dacă utilizatorul cere explicit.
