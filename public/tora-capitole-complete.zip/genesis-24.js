window.CHAPTER_DATA = [
  {
    "num": 1,
    "tokens": [
      {
        "t": "Iar "
      },
      {
        "t": "Avraham",
        "w": "Avraham",
        "heb": "וְאַבְרָהָם",
        "translit": "ve'Avraham",
        "strong": "H85",
        "pos": "nume propriu",
        "greek": "Αβρααμ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Avraham."
      },
      {
        "t": " era "
      },
      {
        "t": "bătrân",
        "w": "bătrân",
        "heb": "זָקֵן",
        "translit": "zaken",
        "strong": "H2205",
        "pos": "adjectiv",
        "greek": "πρεσβύτερος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "bătrân."
      },
      {
        "t": ", "
      },
      {
        "t": "înaintat",
        "w": "înaintat",
        "heb": "בָּא",
        "translit": "ba",
        "strong": "H935",
        "pos": "verb, participiu",
        "greek": "προβεβηκὼς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "înaintat."
      },
      {
        "t": " în "
      },
      {
        "t": "zile",
        "w": "zile",
        "heb": "בַּיָּמִים",
        "translit": "bayamim",
        "strong": "H3117",
        "pos": "substantiv, cu articol",
        "greek": "ἡμερῶν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "zile."
      },
      {
        "t": ", și "
      },
      {
        "t": "DOMNUL",
        "w": "DOMNUL",
        "heb": "וַיהוָה",
        "translit": "vaYHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "ὁ δὲ Κύριος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNUL."
      },
      {
        "t": " îl "
      },
      {
        "t": "binecuvântase",
        "w": "binecuvântase",
        "heb": "בֵּרַךְ",
        "translit": "berakh",
        "strong": "H1288",
        "pos": "verb",
        "greek": "εὐλόγησεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "îl binecuvântase."
      },
      {
        "t": " pe "
      },
      {
        "t": "Avraham",
        "w": "Avraham",
        "heb": "אֶת־אַבְרָהָם",
        "translit": "et Avraham",
        "strong": "H85",
        "pos": "nume propriu",
        "greek": "τὸν Αβρααμ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "pe Avraham."
      },
      {
        "t": " în "
      },
      {
        "t": "toate",
        "w": "toate",
        "heb": "בַּכֹּל",
        "translit": "bakol",
        "strong": "H3605",
        "pos": "substantiv, cu prefix",
        "greek": "κατὰ πάντα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "toate."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וְאַבְרָהָם זָקֵן בָּא בַּיָּמִים וַיהוָה בֵּרַךְ אֶת־אַבְרָהָם בַּכֹּל",
        "translation": "„Iar Avraham era bătrân, înaintat în zile, și DOMNUL îl binecuvântase pe Avraham în toate.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "Καὶ Αβρααμ ἦν πρεσβύτερος προβεβηκὼς ἡμερῶν, καὶ Κύριος εὐλόγησεν τὸν Αβρααμ κατὰ πάντα.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ואברהם זקן בא בימים ויהוה ברך את אברהם בכל",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 22:17",
      "Geneza 12:2"
    ],
    "commentaries": [
      {
        "author": "Ramban / Nahmanide (1194–1270)",
        "text": "Discută de ce Tora repetă vârsta înaintată a lui Avraham: temerea că ar putea muri înainte de întoarcerea unui mesager l-a determinat să pună jurământul chiar pe slujitorul administrator al averii sale, nu să aștepte. Citează o dezbatere din Midrașul Bereșit Rabba despre expresia „binecuvântat în toate” — Rabi Meir susține că Avraham nu a avut o fiică (o binecuvântare, căci ar fi trebuit să o mărite cu un canaanit blestemat), Rabi Iuda susține că a avut, iar „alții” spun că fiica se numea chiar „Bakol” — o dezbatere pe care Ramban o numește „un mister adânc al Torei”, fără să-l dezlege complet."
      },
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Notează două lucruri: (1) „înaintat în zile” înseamnă că sosise timpul să-și însoare fiul cât Avraham mai trăia; (2) menționarea binecuvântării depline a lui Avraham explică de ce slujitorul a fost trimis după o rudă anume, nu din lipsă de femei sau pretendenți în Canaan — dimpotrivă, toată lumea ar fi vrut o alianță cu Isaac, tocmai de aceea Avraham a insistat pe familia proprie."
      }
    ]
  },
  {
    "num": 2,
    "tokens": [
      {
        "t": "Avraham",
        "w": "Avraham",
        "heb": "אַבְרָהָם",
        "translit": "Avraham",
        "strong": "H85",
        "pos": "nume propriu",
        "greek": "Αβρααμ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Avraham."
      },
      {
        "t": " i-a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמֶר",
        "translit": "vayomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-a spus."
      },
      {
        "t": " "
      },
      {
        "t": "slujitorului",
        "w": "slujitorului",
        "heb": "עַבְדּוֹ",
        "translit": "avdo",
        "strong": "H5650",
        "pos": "substantiv cu sufix",
        "greek": "τῷ παιδὶ αὐτοῦ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "slujitorului lui."
      },
      {
        "t": " său, "
      },
      {
        "t": "bătrânul",
        "w": "bătrânul",
        "heb": "זְקַן",
        "translit": "zekan",
        "strong": "H2205",
        "pos": "adjectiv, stare construită",
        "greek": "τῷ πρεσβυτέρῳ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "bătrânul."
      },
      {
        "t": " "
      },
      {
        "t": "casei",
        "w": "casei",
        "heb": "בֵיתוֹ",
        "translit": "beito",
        "strong": "H1004",
        "pos": "substantiv cu sufix",
        "greek": "τῆς οἰκίας αὐτοῦ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "casei lui."
      },
      {
        "t": " sale, care "
      },
      {
        "t": "controla",
        "w": "controla",
        "heb": "הַמֹּשֵׁל",
        "translit": "hamoshel",
        "strong": "H4910",
        "pos": "verb, participiu, cu articol",
        "greek": "τῷ ἄρχοντι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "controla."
      },
      {
        "t": " tot ceea ce "
      },
      {
        "t": "avea",
        "w": "avea",
        "heb": "לוֹ",
        "translit": "lo",
        "strong": "H0",
        "pos": "prepoziție cu sufix",
        "greek": "αὐτοῦ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "avea."
      },
      {
        "t": ": „"
      },
      {
        "t": "Pune-ți",
        "w": "Pune-ți",
        "heb": "שִׂים־נָא",
        "translit": "sim na",
        "strong": "H7760",
        "pos": "verb, imperativ",
        "greek": "θὲς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Pune-ți."
      },
      {
        "t": ", te rog, "
      },
      {
        "t": "mâna",
        "w": "mâna",
        "heb": "יָדְךָ",
        "translit": "yadkha",
        "strong": "H3027",
        "pos": "substantiv cu sufix",
        "greek": "τὴν χεῖρά σου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mâna ta."
      },
      {
        "t": " sub "
      },
      {
        "t": "coapsa",
        "w": "coapsa",
        "heb": "יְרֵכִי",
        "translit": "yerekhi",
        "strong": "H3409",
        "pos": "substantiv cu sufix",
        "greek": "τὸν μηρόν μου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "coapsa mea."
      },
      {
        "t": " mea."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיֹּאמֶר אַבְרָהָם אֶל־עַבְדּוֹ זְקַן בֵּיתוֹ הַמֹּשֵׁל בְּכָל־אֲשֶׁר־לוֹ שִׂים־נָא יָדְךָ תַּחַת יְרֵכִי",
        "translation": "„Avraham i-a spus slujitorului său, bătrânul casei sale, care controla tot ceea ce avea: „Pune-ți, te rog, mâna sub coapsa mea.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ εἶπεν Αβρααμ τῷ παιδὶ αὐτοῦ τῷ πρεσβυτέρῳ τῆς οἰκίας αὐτοῦ τῷ ἄρχοντι πάντων τῶν αὐτοῦ Θὲς τὴν χεῖρά σου ὑπὸ τὸν μηρόν μου,",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויאמר אברהם אל עבדו זקן ביתו המשל בכל אשר לו שים נא ידך תחת ירכי",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 47:29"
    ],
    "commentaries": [
      {
        "author": "Ibn Ezra (1089–1167)",
        "text": "Discută gestul jurământului „sub coapsă”: unii îl leagă de circumcizie, dar Ibn Ezra observă că, dacă așa ar fi fost, Avraham l-ar fi pus să jure pe semnul legământului, nu pe Numele lui Dumnezeu. Explicația pe care o consideră cea mai aproape de adevăr: era un obicei al vremii ca un supus aflat în slujba cuiva să-și pună mâna sub coapsa stăpânului, ca gest de subordonare — obicei păstrat, spune el, până în vremea lui în „Țara lui Hodu” (India)."
      },
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Compară gestul cu jurământul similar al lui Iosif față de Iacov mai târziu — un legământ sau jurământ al unui fiu sau al unui slujitor față de stăpân se făcea prin acest gest de subjugare simbolică, spre deosebire de strângerea mâinii sau tăierea unui animal în două, folosite între persoane egale."
      }
    ]
  },
  {
    "num": 3,
    "tokens": [
      {
        "t": "Și eu te voi "
      },
      {
        "t": "pune",
        "w": "pune",
        "heb": "וְאַשְׁבִּיעֲךָ",
        "translit": "ve'ashbi'akha",
        "strong": "H7650",
        "pos": "verb, cu sufix",
        "greek": "ὁρκιῶ σε",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "te voi pune."
      },
      {
        "t": " să "
      },
      {
        "t": "juri",
        "w": "juri",
        "heb": "",
        "translit": "",
        "strong": "",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să juri."
      },
      {
        "t": " pe "
      },
      {
        "t": "DOMNUL",
        "w": "DOMNUL",
        "heb": "יְהוָה",
        "translit": "YHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κύριον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNUL."
      },
      {
        "t": ", "
      },
      {
        "t": "Dumnezeul",
        "w": "Dumnezeul",
        "heb": "אֱלֹהֵי",
        "translit": "Elohei",
        "strong": "H430",
        "pos": "substantiv, stare construită",
        "greek": "τὸν Θεὸν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Dumnezeul."
      },
      {
        "t": " "
      },
      {
        "t": "cerurilor",
        "w": "cerurilor",
        "heb": "הַשָּׁמַיִם",
        "translit": "hashamayim",
        "strong": "H8064",
        "pos": "substantiv, cu articol",
        "greek": "τοῦ οὐρανοῦ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cerurilor."
      },
      {
        "t": " și "
      },
      {
        "t": "Dumnezeul",
        "w": "Dumnezeul",
        "heb": "וֵאלֹהֵי",
        "translit": "ve'Elohei",
        "strong": "H430",
        "pos": "substantiv, stare construită",
        "greek": "τὸν Θεὸν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Dumnezeul."
      },
      {
        "t": " "
      },
      {
        "t": "pământului",
        "w": "pământului",
        "heb": "הָאָרֶץ",
        "translit": "ha'arets",
        "strong": "H776",
        "pos": "substantiv, cu articol",
        "greek": "τῆς γῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "pământului."
      },
      {
        "t": ", că nu vei "
      },
      {
        "t": "lua",
        "w": "lua",
        "heb": "תִּקַּח",
        "translit": "tikach",
        "strong": "H3947",
        "pos": "verb",
        "greek": "λήμψῃ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "vei lua."
      },
      {
        "t": " o "
      },
      {
        "t": "soție",
        "w": "soție",
        "heb": "אִשָּׁה",
        "translit": "ishah",
        "strong": "H802",
        "pos": "substantiv",
        "greek": "γυναῖκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "soție."
      },
      {
        "t": " pentru fiul meu dintre "
      },
      {
        "t": "fiicele",
        "w": "fiicele",
        "heb": "מִבְּנוֹת",
        "translit": "mibenot",
        "strong": "H1323",
        "pos": "substantiv, stare construită",
        "greek": "ἀπὸ τῶν θυγατέρων",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "fiicele."
      },
      {
        "t": " "
      },
      {
        "t": "canaaniților",
        "w": "canaaniților",
        "heb": "הַכְּנַעֲנִי",
        "translit": "hakena'ani",
        "strong": "H3669",
        "pos": "nume propriu, popor, cu articol",
        "greek": "τῶν Χαναναίων",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "canaaniților."
      },
      {
        "t": " în mijlocul cărora "
      },
      {
        "t": "locuiesc",
        "w": "locuiesc",
        "heb": "יוֹשֵׁב",
        "translit": "yoshev",
        "strong": "H3427",
        "pos": "verb, participiu",
        "greek": "οἰκῶ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "locuiesc."
      },
      {
        "t": " eu."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וְאַשְׁבִּיעֲךָ בַּיהוָה אֱלֹהֵי הַשָּׁמַיִם וֵאלֹהֵי הָאָרֶץ אֲשֶׁר לֹא־תִקַּח אִשָּׁה לִבְנִי מִבְּנוֹת הַכְּנַעֲנִי אֲשֶׁר אָנֹכִי יוֹשֵׁב בְּקִרְבּוֹ",
        "translation": "„Și eu te voi pune să juri pe DOMNUL, Dumnezeul cerurilor și Dumnezeul pământului, că nu vei lua o soție pentru fiul meu dintre fiicele canaaniților în mijlocul cărora locuiesc eu.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἐξορκιῶ σε Κύριον τὸν θεὸν τοῦ οὐρανοῦ καὶ τὸν θεὸν τῆς γῆς, ἵνα μὴ λάβῃς γυναῖκα τῷ υἱῷ μου Ισαακ ἀπὸ τῶν θυγατέρων τῶν Χαναναίων, μεθ᾿ ὧν ἐγὼ οἰκῶ ἐν αὐτοῖς,",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ואשביעך ביהוה אלהי השמים ואלהי הארץ אשר לא תקח אשה לבני מבנות הכנעני אשר אנכי ישב בקרבו",
        "translation": "Diferență reală, confirmată: ואשביעך ביהוה אלהי השמים ואלהי הארץ אשר לא תקח אשה לבני מבנות הכנעני אשר אנכי ישב בקרבו — „And I will make thee swear by the LORD, the God of heaven, and the God of the earth, that thou shalt not take a wife unto my son of the daughters of the Canaanites, among whom I dwell:”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Deuteronom 7:3",
      "Geneza 28:1-2"
    ],
    "commentaries": [
      {
        "author": "Ibn Ezra (1089–1167)",
        "text": "Discută formula „Dumnezeul cerurilor și Dumnezeul pământului”: în locul acela, când o fiică era logodită cu cineva, potrivirea venea cu adevărat din Cer — „și aceasta e o taină”, spune Ibn Ezra, fără a o dezvolta mai mult."
      },
      {
        "author": "Ramban / Nahmanide (1194–1270)",
        "text": "Discută titlul dublu al lui Dumnezeu în jurământ. Ar fi fost firesc ca Avraham să-i poruncească direct lui Isaac, dar dorința lui de a trimite un mesager încă din timpul vieții l-a determinat să-l pună pe slujitor sub jurământ. Ramban notează și o zicere rabinică: „cine locuiește în afara Țării lui Israel e ca și cum nu ar avea Dumnezeu” — context pentru insistența asupra întoarcerii în Canaan."
      }
    ]
  },
  {
    "num": 4,
    "tokens": [
      {
        "t": "Ci înspre "
      },
      {
        "t": "țara",
        "w": "țara",
        "heb": "אַרְצִי",
        "translit": "artsi",
        "strong": "H776",
        "pos": "substantiv cu sufix",
        "greek": "τὴν γῆν μου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "țara mea."
      },
      {
        "t": " mea și înspre "
      },
      {
        "t": "locul",
        "w": "locul",
        "heb": "מוֹלַדְתִּי",
        "translit": "moladeti",
        "strong": "H4138",
        "pos": "substantiv cu sufix",
        "greek": "τὴν φυλήν μου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "locul meu."
      },
      {
        "t": " meu "
      },
      {
        "t": "natal",
        "w": "natal",
        "heb": "",
        "translit": "",
        "strong": "",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "natal."
      },
      {
        "t": " să "
      },
      {
        "t": "mergi",
        "w": "mergi",
        "heb": "תֵּלֵךְ",
        "translit": "teilekh",
        "strong": "H1980",
        "pos": "verb",
        "greek": "πορεύσῃ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să mergi."
      },
      {
        "t": " și vei "
      },
      {
        "t": "lua",
        "w": "lua",
        "heb": "וְלָקַחְתָּ",
        "translit": "velakachta",
        "strong": "H3947",
        "pos": "verb",
        "greek": "λήμψῃ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "vei lua."
      },
      {
        "t": " [de acolo] o "
      },
      {
        "t": "soție",
        "w": "soție",
        "heb": "אִשָּׁה",
        "translit": "ishah",
        "strong": "H802",
        "pos": "substantiv",
        "greek": "γυναῖκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "soție."
      },
      {
        "t": " pentru fiul meu, pentru "
      },
      {
        "t": "Isaac",
        "w": "Isaac",
        "heb": "לְיִצְחָק",
        "translit": "leYitschak",
        "strong": "H3327",
        "pos": "nume propriu",
        "greek": "τῷ Ισαακ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Isaac."
      },
      {
        "t": ".”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "כִּי אֶל־אַרְצִי וְאֶל־מוֹלַדְתִּי תֵּלֵךְ וְלָקַחְתָּ אִשָּׁה לִבְנִי לְיִצְחָק",
        "translation": "„Ci înspre țara mea și înspre locul meu natal să mergi și vei lua [de acolo] o soție pentru fiul meu, pentru Isaac.”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "ἀλλὰ εἰς τὴν γῆν μου, οὗ ἐγενόμην, πορεύσῃ καὶ εἰς τὴν φυλήν μου καὶ λήμψῃ γυναῖκα τῷ υἱῷ μου Ισαακ ἐκεῖθεν.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "כי אם אל ארצי ואל מולדתי תלך ולקחת אשה לבני ליצחק",
        "translation": "Diferență reală, confirmată: כי אם אל ארצי ואל מולדתי תלך ולקחת אשה לבני ליצחק — „But thou shalt go unto my country, and to my kindred, and take a wife unto my son Isaac.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 12:1",
      "Geneza 11:31"
    ],
    "commentaries": [
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Subliniază contrastul: „ci la țara mea” înseamnă nu la oricine, ci în mod specific la rudele sale — „la neamul meu”, cei aflați în țara sa natală."
      }
    ]
  },
  {
    "num": 5,
    "tokens": [
      {
        "t": "Și "
      },
      {
        "t": "slujitorul",
        "w": "slujitorul",
        "heb": "הָעֶבֶד",
        "translit": "ha'eved",
        "strong": "H5650",
        "pos": "substantiv, cu articol",
        "greek": "ὁ παῖς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "slujitorul."
      },
      {
        "t": " i-a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמֶר",
        "translit": "vayomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-a spus."
      },
      {
        "t": ": „Poate "
      },
      {
        "t": "femeia",
        "w": "femeia",
        "heb": "הָאִשָּׁה",
        "translit": "ha'ishah",
        "strong": "H802",
        "pos": "substantiv, cu articol",
        "greek": "ἡ γυνή",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "femeia."
      },
      {
        "t": " nu va "
      },
      {
        "t": "dori",
        "w": "dori",
        "heb": "תֹאבֶה",
        "translit": "tovveh",
        "strong": "H14",
        "pos": "verb",
        "greek": "βουλήσεται",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "va dori."
      },
      {
        "t": " să "
      },
      {
        "t": "vină",
        "w": "vină",
        "heb": "לָלֶכֶת",
        "translit": "lalekhet",
        "strong": "H1980",
        "pos": "verb (infinitiv)",
        "greek": "πορευθῆναι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să vină."
      },
      {
        "t": " după mine în "
      },
      {
        "t": "țara",
        "w": "țara",
        "heb": "הָאָרֶץ",
        "translit": "ha'arets",
        "strong": "H776",
        "pos": "substantiv, cu articol",
        "greek": "τὴν γῆν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "țara."
      },
      {
        "t": " aceasta; să îl "
      },
      {
        "t": "întorc",
        "w": "întorc",
        "heb": "הָשֵׁב אָשִׁיב",
        "translit": "hashev ashiv",
        "strong": "H7725",
        "pos": "verb (infinitiv absolut + verb)",
        "greek": "ἀποστρέψω",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să îl întorc."
      },
      {
        "t": " oare pe fiul tău în "
      },
      {
        "t": "țara",
        "w": "țara",
        "heb": "הָאָרֶץ",
        "translit": "ha'arets",
        "strong": "H776",
        "pos": "substantiv, cu articol",
        "greek": "τὴν γῆν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "țara."
      },
      {
        "t": " din care ai "
      },
      {
        "t": "ieșit",
        "w": "ieșit",
        "heb": "יָצָאתָ",
        "translit": "yatsata",
        "strong": "H3318",
        "pos": "verb",
        "greek": "ἐξῆλθες",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ai ieșit."
      },
      {
        "t": " tu?”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיֹּאמֶר אֵלָיו הָעֶבֶד אוּלַי לֹא־תֹאבֶה הָאִשָּׁה לָלֶכֶת אַחֲרַי אֶל־הָאָרֶץ הַזֹּאת הֶהָשֵׁב אָשִׁיב אֶת־בִּנְךָ אֶל־הָאָרֶץ אֲשֶׁר־יָצָאתָ מִשָּׁם",
        "translation": "„Și slujitorul i-a spus: „Poate femeia nu va dori să vină după mine în țara aceasta; să îl întorc oare pe fiul tău în țara din care ai ieșit tu?”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "εἶπεν δὲ πρὸς αὐτὸν ὁ παῖς Μήποτε οὐ βούλεται ἡ γυνὴ πορευθῆναι μετ᾿ ἐμοῦ ὀπίσω εἰς τὴν γῆν ταύτην· ἀποστρέψω τὸν υἱόν σου εἰς τὴν γῆν, ὅθεν ἐξῆλθες ἐκεῖθεν;",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויאמר אליו העבד אולי לא תאבה האשה ללכת אחרי אל הארץ הזאת ההשב אשיב את בנך אל הארץ אשר יצאת משם",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:8"
    ],
    "commentaries": [
      {
        "author": "Ramban / Nahmanide (1194–1270)",
        "text": "Interpretează întrebarea slujitorului: „poate femeia” înseamnă femeia anume căreia îi voi vorbi dintre toate cele de acolo, sau cea care se va dovedi potrivită pentru Isaac — nu o îndoială generală, ci o clarificare de procedură."
      },
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Interpretează similar întrebarea ca pe o clarificare procedurală necesară înainte de plecare, nu ca pe o ezitare a slujitorului."
      }
    ]
  },
  {
    "num": 6,
    "tokens": [
      {
        "t": "Și "
      },
      {
        "t": "Avraham",
        "w": "Avraham",
        "heb": "אַבְרָהָם",
        "translit": "Avraham",
        "strong": "H85",
        "pos": "nume propriu",
        "greek": "Αβρααμ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Avraham."
      },
      {
        "t": " i-a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמֶר",
        "translit": "vayomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-a spus."
      },
      {
        "t": ": „"
      },
      {
        "t": "Ferește-te",
        "w": "Ferește-te",
        "heb": "הִשָּׁמֶר",
        "translit": "hishamer",
        "strong": "H8104",
        "pos": "verb, imperativ",
        "greek": "πρόσεχε",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Ferește-te."
      },
      {
        "t": ", să nu cumva să-l "
      },
      {
        "t": "întorci",
        "w": "întorci",
        "heb": "תָּשֵׁב",
        "translit": "tashev",
        "strong": "H7725",
        "pos": "verb",
        "greek": "ἀποστρέψῃς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să-l întorci."
      },
      {
        "t": " pe fiul meu acolo!"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיֹּאמֶר אֵלָיו אַבְרָהָם הִשָּׁמֶר לְךָ פֶּן־תָּשִׁיב אֶת־בְּנִי שָׁמָּה",
        "translation": "„Și Avraham i-a spus: „Ferește-te, să nu cumva să-l întorci pe fiul meu acolo!” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "εἶπεν δὲ πρὸς αὐτὸν Αβρααμ Πρόσεχε σεαυτῷ, μὴ ἀποστρέψῃς τὸν υἱόν μου ἐκεῖ.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויאמר אליו אברהם השמר לך פן תשיב את בני שמה",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:5"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Insistența dublă a lui Avraham („ferește-te să nu întorci pe fiul meu acolo”) contrastează cu tonul mai calm al restului instrucțiunilor — semnalează miza majoră a promisiunii legate de rămânerea în Canaan."
      }
    ]
  },
  {
    "num": 7,
    "tokens": [
      {
        "t": "DOMNUL",
        "w": "DOMNUL",
        "heb": "יְהוָה",
        "translit": "YHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κύριος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNUL."
      },
      {
        "t": ", "
      },
      {
        "t": "Dumnezeul",
        "w": "Dumnezeul",
        "heb": "אֱלֹהֵי",
        "translit": "Elohei",
        "strong": "H430",
        "pos": "substantiv, stare construită",
        "greek": "ὁ Θεὸς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Dumnezeul."
      },
      {
        "t": " "
      },
      {
        "t": "cerurilor",
        "w": "cerurilor",
        "heb": "הַשָּׁמַיִם",
        "translit": "hashamayim",
        "strong": "H8064",
        "pos": "substantiv, cu articol",
        "greek": "τοῦ οὐρανοῦ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cerurilor."
      },
      {
        "t": ", care m-a "
      },
      {
        "t": "luat",
        "w": "luat",
        "heb": "אֲשֶׁר לְקָחַנִי",
        "translit": "asher lekachani",
        "strong": "H3947",
        "pos": "verb, cu sufix",
        "greek": "ὃς ἔλαβέν με",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "m-a luat."
      },
      {
        "t": " din "
      },
      {
        "t": "casa",
        "w": "casa",
        "heb": "מִבֵּית",
        "translit": "mibeit",
        "strong": "H1004",
        "pos": "substantiv, stare construită",
        "greek": "ἐκ τοῦ οἴκου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "casa."
      },
      {
        "t": " tatălui meu și din "
      },
      {
        "t": "țara",
        "w": "țara",
        "heb": "וּמֵאֶרֶץ",
        "translit": "ume'erets",
        "strong": "H776",
        "pos": "substantiv",
        "greek": "ἐκ τῆς γῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "țara."
      },
      {
        "t": " mea "
      },
      {
        "t": "natală",
        "w": "natală",
        "heb": "מוֹלַדְתִּי",
        "translit": "moladeti",
        "strong": "H4138",
        "pos": "substantiv cu sufix",
        "greek": "ἧς ἐγεννήθην",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "natală."
      },
      {
        "t": ", și care mi-a "
      },
      {
        "t": "vorbit",
        "w": "vorbit",
        "heb": "דִּבֶּר",
        "translit": "diber",
        "strong": "H1696",
        "pos": "verb",
        "greek": "ἐλάλησέν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mi-a vorbit."
      },
      {
        "t": " și care mi-a "
      },
      {
        "t": "jurat",
        "w": "jurat",
        "heb": "נִשְׁבַּע",
        "translit": "nishba",
        "strong": "H7650",
        "pos": "verb",
        "greek": "ὤμοσέν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mi-a jurat."
      },
      {
        "t": " spunând: «"
      },
      {
        "t": "Seminției",
        "w": "Seminției",
        "heb": "לְזַרְעֲךָ",
        "translit": "lezar'akha",
        "strong": "H2233",
        "pos": "substantiv cu sufix",
        "greek": "τῷ σπέρματί σου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Seminției tale."
      },
      {
        "t": " tale voi "
      },
      {
        "t": "da",
        "w": "da",
        "heb": "אֶתֵּן",
        "translit": "eten",
        "strong": "H5414",
        "pos": "verb",
        "greek": "δώσω",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "voi da."
      },
      {
        "t": " "
      },
      {
        "t": "țara",
        "w": "țara",
        "heb": "הָאָרֶץ",
        "translit": "ha'arets",
        "strong": "H776",
        "pos": "substantiv, cu articol",
        "greek": "τὴν γῆν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "țara."
      },
      {
        "t": " aceasta» – El va "
      },
      {
        "t": "trimite",
        "w": "trimite",
        "heb": "יִשְׁלַח",
        "translit": "yishlach",
        "strong": "H7971",
        "pos": "verb",
        "greek": "ἀποστελεῖ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "va trimite."
      },
      {
        "t": " pe "
      },
      {
        "t": "îngerul",
        "w": "îngerul",
        "heb": "מַלְאָכוֹ",
        "translit": "mal'akho",
        "strong": "H4397",
        "pos": "substantiv cu sufix",
        "greek": "τὸν ἄγγελον αὐτοῦ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "îngerul lui."
      },
      {
        "t": " Său înaintea ta și vei "
      },
      {
        "t": "lua",
        "w": "lua",
        "heb": "וְלָקַחְתָּ",
        "translit": "velakachta",
        "strong": "H3947",
        "pos": "verb",
        "greek": "λήμψῃ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "vei lua."
      },
      {
        "t": " o "
      },
      {
        "t": "soție",
        "w": "soție",
        "heb": "אִשָּׁה",
        "translit": "ishah",
        "strong": "H802",
        "pos": "substantiv",
        "greek": "γυναῖκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "soție."
      },
      {
        "t": " pentru fiul meu de acolo."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "יְהוָה אֱלֹהֵי הַשָּׁמַיִם אֲשֶׁר לְקָחַנִי מִבֵּית אָבִי וּמֵאֶרֶץ מוֹלַדְתִּי וַאֲשֶׁר דִּבֶּר־לִי וַאֲשֶׁר נִשְׁבַּע־לִי לֵאמֹר לְזַרְעֲךָ אֶתֵּן אֶת־הָאָרֶץ הַזֹּאת הוּא יִשְׁלַח מַלְאָכוֹ לְפָנֶיךָ וְלָקַחְתָּ אִשָּׁה לִבְנִי מִשָּׁם",
        "translation": "„DOMNUL, Dumnezeul cerurilor, care m-a luat din casa tatălui meu și din țara mea natală, și care mi-a vorbit și care mi-a jurat spunând: «Seminției tale voi da țara aceasta» – El va trimite pe îngerul Său înaintea ta și vei lua o soție pentru fiul meu de acolo.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "Κύριος ὁ θεὸς τοῦ οὐρανοῦ καὶ ὁ θεὸς τῆς γῆς, ὃς ἔλαβέν με ἐκ τοῦ οἴκου τοῦ πατρός μου καὶ ἐκ τῆς γῆς, ἧς ἐγενήθην, ὃς ἐλάλησέν μοι καὶ ὤμοσέν μοι λέγων Σοὶ δώσω τὴν γῆν ταύτην καὶ τῷ σπέρματί σου, αὐτὸς ἀποστελεῖ τὸν ἄγγελον αὐτοῦ ἔμπροσθέν σου, καὶ λήμψῃ γυναῖκα τῷ υἱῷ μου Ισαακ ἐκεῖθεν.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "יהוה אלהי השמים אשר לקחני מבית אבי ומארץ מולדתי ואשר דבר לי ואשר נשבע לי לאמר לזרעך אתן את הארץ הזאת הוא ישלח מלאכו לפניך ולקחת אשה לבני משם",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Exod 23:20",
      "Geneza 12:1,7",
      "Geneza 15:18",
      "Evrei 1:14"
    ],
    "commentaries": [
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Explică logica răspunsului lui Avraham: Dumnezeul care l-a adus pe Avraham în țara aceasta și i-a promis-o urmașilor nu ar vrea să-i despartă de ea — de aceea Avraham e sigur că îngerul Său va merge înaintea slujitorului, ca împlinire firească a promisiunii deja făcute."
      }
    ]
  },
  {
    "num": 8,
    "tokens": [
      {
        "t": "Iar dacă "
      },
      {
        "t": "femeia",
        "w": "femeia",
        "heb": "הָאִשָּׁה",
        "translit": "ha'ishah",
        "strong": "H802",
        "pos": "substantiv, cu articol",
        "greek": "ἡ γυνή",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "femeia."
      },
      {
        "t": " nu va "
      },
      {
        "t": "dori",
        "w": "dori",
        "heb": "תֹאבֶה",
        "translit": "tovveh",
        "strong": "H14",
        "pos": "verb",
        "greek": "θέλῃ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "va dori."
      },
      {
        "t": " să "
      },
      {
        "t": "meargă",
        "w": "meargă",
        "heb": "לָלֶכֶת",
        "translit": "lalekhet",
        "strong": "H1980",
        "pos": "verb (infinitiv)",
        "greek": "πορευθῆναι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să meargă."
      },
      {
        "t": " după tine, vei fi "
      },
      {
        "t": "absolvit",
        "w": "absolvit",
        "heb": "וְנִקִּיתָ",
        "translit": "veniykita",
        "strong": "H5352",
        "pos": "verb",
        "greek": "καθαρὸς ἔσῃ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "vei fi absolvit."
      },
      {
        "t": " de "
      },
      {
        "t": "jurământul",
        "w": "jurământul",
        "heb": "מִשְּׁבֻעָתִי",
        "translit": "mishvu'ati",
        "strong": "H7621",
        "pos": "substantiv cu sufix",
        "greek": "τοῦ ὅρκου μου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "jurământul meu."
      },
      {
        "t": " acesta al meu. Însă pe fiul meu să nu cumva să-l "
      },
      {
        "t": "întorci",
        "w": "întorci",
        "heb": "תָשֵׁב",
        "translit": "tashev",
        "strong": "H7725",
        "pos": "verb",
        "greek": "ἀποστρέψῃς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să-l întorci."
      },
      {
        "t": " acolo!”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וְאִם־לֹא תֹאבֶה הָאִשָּׁה לָלֶכֶת אַחֲרֶיךָ וְנִקִּיתָ מִשְּׁבֻעָתִי זֹאת רַק אֶת־בְּנִי לֹא תָשֵׁב שָׁמָּה",
        "translation": "„Iar dacă femeia nu va dori să meargă după tine, vei fi absolvit de jurământul acesta al meu. Însă pe fiul meu să nu cumva să-l întorci acolo!”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "ἐὰν δὲ μὴ θέλῃ ἡ γυνὴ πορευθῆναι μετὰ σοῦ εἰς τὴν γῆν ταύτην, καθαρὸς ἔσῃ ἀπὸ τοῦ ὅρκου τούτου· μόνον τὸν υἱόν μου μὴ ἀποστρέψῃς ἐκεῖ.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ואם לא תאבה האשה ללכת אחריך ונקית משבועתי זאת רק את בני לא תשיב שמה",
        "translation": "Diferență reală, confirmată: ואם לא תאבה האשה ללכת אחריך ונקית משבועתי זאת רק את בני לא תשיב שמה — „And if the woman will not be willing to follow thee, then thou shalt be clear from this my oath: only bring not my son thither again.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:41"
    ],
    "commentaries": [
      {
        "author": "Ibn Ezra (1089–1167)",
        "text": "Explică interdicția „să nu întorci pe fiul meu acolo”: Isaac trebuia să rămână în Țara lui Israel, pentru că Avraham însuși era „rădăcina” — punctul de plecare al promisiunii legate de acel loc."
      },
      {
        "author": "Ramban / Nahmanide (1194–1270)",
        "text": "Precizează sensul eliberării de jurământ: Avraham nu-i permitea slujitorului să ia o soție dintre canaaniți dacă familia refuza, ci îl elibera complet de misiune, lăsând rezultatul în seama lui Dumnezeu. Citează și o interpretare din Bereșit Rabba: interdicția vizată explicit era împotriva aliaților apropiați ai lui Avraham (Aner, Eșcol, Mamre), ei înșiși de origine canaanită."
      }
    ]
  },
  {
    "num": 9,
    "tokens": [
      {
        "t": "Și "
      },
      {
        "t": "slujitorul",
        "w": "slujitorul",
        "heb": "הָעֶבֶד",
        "translit": "ha'eved",
        "strong": "H5650",
        "pos": "substantiv, cu articol",
        "greek": "ὁ παῖς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "slujitorul."
      },
      {
        "t": " și-a "
      },
      {
        "t": "pus",
        "w": "pus",
        "heb": "וַיָּשֶׂם",
        "translit": "vayasem",
        "strong": "H7760",
        "pos": "verb",
        "greek": "ἔθηκεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "și-a pus."
      },
      {
        "t": " "
      },
      {
        "t": "mâna",
        "w": "mâna",
        "heb": "יָדוֹ",
        "translit": "yado",
        "strong": "H3027",
        "pos": "substantiv cu sufix",
        "greek": "τὴν χεῖρα αὐτοῦ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mâna lui."
      },
      {
        "t": " sub "
      },
      {
        "t": "coapsa",
        "w": "coapsa",
        "heb": "יֶרֶךְ",
        "translit": "yerekh",
        "strong": "H3409",
        "pos": "substantiv, stare construită",
        "greek": "τὸν μηρὸν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "coapsa."
      },
      {
        "t": " stăpânului său "
      },
      {
        "t": "Avraham",
        "w": "Avraham",
        "heb": "אַבְרָהָם",
        "translit": "Avraham",
        "strong": "H85",
        "pos": "nume propriu",
        "greek": "Αβρααμ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Avraham."
      },
      {
        "t": " și i-a "
      },
      {
        "t": "jurat",
        "w": "jurat",
        "heb": "וַיִּשָּׁבַע",
        "translit": "vayishava",
        "strong": "H7650",
        "pos": "verb",
        "greek": "ὤμοσεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-a jurat."
      },
      {
        "t": " în legătură cu acest "
      },
      {
        "t": "lucru",
        "w": "lucru",
        "heb": "הַדָּבָר",
        "translit": "hadavar",
        "strong": "H1697",
        "pos": "substantiv, cu articol",
        "greek": "τοῦ ῥήματος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "lucru."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיָּשֶׂם הָעֶבֶד אֶת־יָדוֹ תַּחַת יֶרֶךְ אַבְרָהָם אֲדֹנָיו וַיִּשָּׁבַע לוֹ עַל־הַדָּבָר הַזֶּה",
        "translation": "„Și slujitorul și-a pus mâna sub coapsa stăpânului său Avraham și i-a jurat în legătură cu acest lucru.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἔθηκεν ὁ παῖς τὴν χεῖρα αὐτοῦ ὑπὸ τὸν μηρὸν Αβρααμ τοῦ κυρίου αὐτοῦ καὶ ὤμοσεν αὐτῷ περὶ τοῦ ῥήματος τούτου.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "וישם העבד את ידו תחת ירך אברהם אדניו וישבע לו על הדבר הזה",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:2"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Supunerea slujitorului e imediată, fără replică — jurământul complet e depus exact cum a fost cerut, fără nicio condiție suplimentară din partea lui."
      }
    ]
  },
  {
    "num": 10,
    "tokens": [
      {
        "t": "Și "
      },
      {
        "t": "slujitorul",
        "w": "slujitorul",
        "heb": "הָעֶבֶד",
        "translit": "ha'eved",
        "strong": "H5650",
        "pos": "substantiv, cu articol",
        "greek": "ὁ παῖς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "slujitorul."
      },
      {
        "t": " a "
      },
      {
        "t": "luat",
        "w": "luat",
        "heb": "וַיִּקַּח",
        "translit": "vayikach",
        "strong": "H3947",
        "pos": "verb",
        "greek": "ἔλαβεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a luat."
      },
      {
        "t": " "
      },
      {
        "t": "zece",
        "w": "zece",
        "heb": "עֲשָׂרָה",
        "translit": "asarah",
        "strong": "H6235",
        "pos": "numeral",
        "greek": "δέκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "zece."
      },
      {
        "t": " "
      },
      {
        "t": "cămile",
        "w": "cămile",
        "heb": "גְמַלִּים",
        "translit": "gemalim",
        "strong": "H1581",
        "pos": "substantiv",
        "greek": "καμήλους",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămile."
      },
      {
        "t": " dintre "
      },
      {
        "t": "cămilele",
        "w": "cămilele",
        "heb": "מִגְּמַלֵּי",
        "translit": "migemalei",
        "strong": "H1581",
        "pos": "substantiv, stare construită",
        "greek": "τῶν καμήλων",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămilele."
      },
      {
        "t": " stăpânului său și a "
      },
      {
        "t": "plecat",
        "w": "plecat",
        "heb": "וַיֵּלֶךְ",
        "translit": "vayelekh",
        "strong": "H1980",
        "pos": "verb",
        "greek": "ἐπορεύθη",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a plecat."
      },
      {
        "t": " cu toată "
      },
      {
        "t": "bogăția",
        "w": "bogăția",
        "heb": "וְכָל־טוּב",
        "translit": "vekhol tuv",
        "strong": "H2898",
        "pos": "substantiv",
        "greek": "ἀπὸ πάντων τῶν ἀγαθῶν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "bogăția."
      },
      {
        "t": " stăpânului său în "
      },
      {
        "t": "mâna",
        "w": "mâna",
        "heb": "בְיָדוֹ",
        "translit": "veyado",
        "strong": "H3027",
        "pos": "substantiv cu sufix",
        "greek": "ταῖς χερσίν αὐτοῦ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mâna lui."
      },
      {
        "t": " lui; s-a "
      },
      {
        "t": "ridicat",
        "w": "ridicat",
        "heb": "וַיָּקָם",
        "translit": "vayakam",
        "strong": "H6965",
        "pos": "verb",
        "greek": "ἀναστὰς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "s-a ridicat."
      },
      {
        "t": " și s-a "
      },
      {
        "t": "dus",
        "w": "dus",
        "heb": "וַיֵּלֶךְ",
        "translit": "vayelekh",
        "strong": "H1980",
        "pos": "verb",
        "greek": "ἐπορεύθη",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "s-a dus."
      },
      {
        "t": " la "
      },
      {
        "t": "Aram-Naharaim",
        "w": "Aram-Naharaim",
        "heb": "אֲרַם נַהֲרַיִם",
        "translit": "Aram Naharayim",
        "strong": "H763",
        "pos": "nume propriu",
        "greek": "τὴν Μεσοποταμίαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Aram-Naharaim."
      },
      {
        "t": ", la "
      },
      {
        "t": "orașul",
        "w": "orașul",
        "heb": "עִיר",
        "translit": "ir",
        "strong": "H5892",
        "pos": "substantiv, stare construită",
        "greek": "τὴν πόλιν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "orașul."
      },
      {
        "t": " lui "
      },
      {
        "t": "Nahor",
        "w": "Nahor",
        "heb": "נָחוֹר",
        "translit": "Nachor",
        "strong": "H5152",
        "pos": "nume propriu",
        "greek": "Ναχωρ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Nahor."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיִּקַּח הָעֶבֶד עֲשָׂרָה גְמַלִּים מִגְּמַלֵּי אֲדֹנָיו וַיֵּלֶךְ וְכָל־טוּב אֲדֹנָיו בְּיָדוֹ וַיָּקָם וַיֵּלֶךְ אֶל־אֲרַם נַהֲרַיִם אֶל־עִיר נָחוֹר",
        "translation": "„Și slujitorul a luat zece cămile dintre cămilele stăpânului său și a plecat cu toată bogăția stăpânului său în mâna lui; s-a ridicat și s-a dus la Aram-Naharaim, la orașul lui Nahor.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "Καὶ ἔλαβεν ὁ παῖς δέκα καμήλους ἀπὸ τῶν καμήλων τοῦ κυρίου αὐτοῦ καὶ ἀπὸ πάντων τῶν ἀγαθῶν τοῦ κυρίου αὐτοῦ μεθ᾿ ἑαυτοῦ καὶ ἀναστὰς ἐπορεύθη εἰς τὴν Μεσοποταμίαν εἰς τὴν πόλιν Ναχωρ.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויקח העבד עשרה גמלים מגמלי אדניו וילך וכל טוב אדניו בידו ויקם וילך אל ארם נהרים אל עיר נחור",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 27:43",
      "Geneza 29:4-5"
    ],
    "commentaries": [
      {
        "author": "Ramban / Nahmanide (1194–1270)",
        "text": "Discută expresia „toată bunătatea stăpânului său [era] în mâna lui”: citând o interpretare atribuită lui Rashi și paralela cu Bereșit Rabba, sugerează că slujitorul purta cu el un act de danie prin care Avraham îi transferase deja lui Isaac toată averea — ca argument de credibilitate în fața familiei Rebecăi, nu doar zece cămile încărcate cu bunuri."
      }
    ]
  },
  {
    "num": 11,
    "tokens": [
      {
        "t": "Și a "
      },
      {
        "t": "pus",
        "w": "pus",
        "heb": "וַיַּבְרֵךְ",
        "translit": "vayavrekh",
        "strong": "H1288",
        "pos": "verb",
        "greek": "ἐκοίμισεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a pus."
      },
      {
        "t": " "
      },
      {
        "t": "cămilele",
        "w": "cămilele",
        "heb": "הַגְּמַלִּים",
        "translit": "hagemalim",
        "strong": "H1581",
        "pos": "substantiv, cu articol",
        "greek": "τὰς καμήλους",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămilele."
      },
      {
        "t": " să "
      },
      {
        "t": "îngenuncheze",
        "w": "îngenuncheze",
        "heb": "",
        "translit": "",
        "strong": "",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să îngenuncheze."
      },
      {
        "t": " în afara "
      },
      {
        "t": "orașului",
        "w": "orașului",
        "heb": "לָעִיר",
        "translit": "la'ir",
        "strong": "H5892",
        "pos": "substantiv, cu prefix",
        "greek": "τῆς πόλεως",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "orașului."
      },
      {
        "t": ", lângă o "
      },
      {
        "t": "fântână",
        "w": "fântână",
        "heb": "בְּאֵר",
        "translit": "be'er",
        "strong": "H875",
        "pos": "substantiv, stare construită",
        "greek": "τοῦ φρέατος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "fântână."
      },
      {
        "t": " cu "
      },
      {
        "t": "apă",
        "w": "apă",
        "heb": "הַמָּיִם",
        "translit": "hamayim",
        "strong": "H4325",
        "pos": "substantiv, cu articol",
        "greek": "τοῦ ὕδατος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "apă."
      },
      {
        "t": ", la "
      },
      {
        "t": "vremea",
        "w": "vremea",
        "heb": "לְעֵת",
        "translit": "le'et",
        "strong": "H6256",
        "pos": "substantiv, stare construită",
        "greek": "τὸ πρὸς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "vremea."
      },
      {
        "t": " "
      },
      {
        "t": "serii",
        "w": "serii",
        "heb": "עֶרֶב",
        "translit": "erev",
        "strong": "H6153",
        "pos": "substantiv",
        "greek": "ἑσπέρας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "serii."
      },
      {
        "t": ", la vremea când "
      },
      {
        "t": "vin",
        "w": "vin",
        "heb": "יֵצֵאת",
        "translit": "yetset",
        "strong": "H3318",
        "pos": "verb",
        "greek": "ἐκπορεύονται",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "vin."
      },
      {
        "t": " "
      },
      {
        "t": "femeile",
        "w": "femeile",
        "heb": "הַשֹּׁאֲבֹת",
        "translit": "hasho'avot",
        "strong": "H7579",
        "pos": "verb, participiu, cu articol",
        "greek": "αἱ ὑδρευόμεναι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "femeile."
      },
      {
        "t": " care "
      },
      {
        "t": "scot",
        "w": "scot",
        "heb": "",
        "translit": "",
        "strong": "",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "care scot."
      },
      {
        "t": " apă."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיַּבְרֵךְ הַגְּמַלִּים מִחוּץ לָעִיר אֶל־בְּאֵר הַמָּיִם לְעֵת עֶרֶב לְעֵת צֵאת הַשֹּׁאֲבֹת",
        "translation": "„Și a pus cămilele să îngenuncheze în afara orașului, lângă o fântână cu apă, la vremea serii, la vremea când vin femeile care scot apă.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἐκοίμισεν τὰς καμήλους ἔξω τῆς πόλεως παρὰ τὸ φρέαρ τοῦ ὕδατος τὸ πρὸς ὀψέ, ἡνίκα ἐκπορεύονται αἱ ὑδρευόμεναι.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויברך הגמלים מחוץ לעיר על באר המים לעת ערב לעת צאת השאבות",
        "translation": "Diferență reală, confirmată: ויברך הגמלים מחוץ לעיר על באר המים לעת ערב לעת צאת השאבות — „And he made his camels to kneel down without the city by a well of water at the time of the evening, [even] the time that women go out to draw [water].”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Alegerea locului (lângă fântână) și a orei (spre seară, când ies femeile după apă) arată o strategie chibzuită a slujitorului, nu o întâmplare — un tipar care revine în alte scene biblice de întâlnire la fântână."
      }
    ],
    "refs": [
      "Geneza 29:9-10"
    ]
  },
  {
    "num": 12,
    "tokens": [
      {
        "t": "Și a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמַר",
        "translit": "vayomar",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a spus."
      },
      {
        "t": ": „"
      },
      {
        "t": "DOAMNE",
        "w": "DOAMNE",
        "heb": "יְהוָה",
        "translit": "YHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κύριε",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOAMNE."
      },
      {
        "t": ", "
      },
      {
        "t": "Dumnezeul",
        "w": "Dumnezeul",
        "heb": "אֱלֹהֵי",
        "translit": "Elohei",
        "strong": "H430",
        "pos": "substantiv, stare construită",
        "greek": "ὁ Θεὸς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Dumnezeul."
      },
      {
        "t": " stăpânului meu "
      },
      {
        "t": "Avraham",
        "w": "Avraham",
        "heb": "אֲדֹנִי אַבְרָהָם",
        "translit": "adoni Avraham",
        "strong": "H85",
        "pos": "nume propriu",
        "greek": "τοῦ κυρίου μου Αβρααμ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Avraham."
      },
      {
        "t": ", "
      },
      {
        "t": "aranjează",
        "w": "aranjează",
        "heb": "הַקְרֵה־נָא",
        "translit": "hakreh na",
        "strong": "H7136",
        "pos": "verb, imperativ",
        "greek": "εὐόδωσον ἐναντίον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "aranjează."
      },
      {
        "t": " "
      },
      {
        "t": "ziua",
        "w": "ziua",
        "heb": "לְפָנַי",
        "translit": "lefanai",
        "strong": "H6440",
        "pos": "substantiv cu sufix",
        "greek": "ἐμοῦ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ziua."
      },
      {
        "t": " de azi înaintea mea și fii "
      },
      {
        "t": "binevoitor",
        "w": "binevoitor",
        "heb": "וַעֲשֵׂה־חֶסֶד",
        "translit": "va'aseh chesed",
        "strong": "H2617",
        "pos": "substantiv",
        "greek": "ποίησον ἔλεος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "binevoitor."
      },
      {
        "t": " cu stăpânul meu "
      },
      {
        "t": "Avraham",
        "w": "Avraham",
        "heb": "אַבְרָהָם",
        "translit": "Avraham",
        "strong": "H85",
        "pos": "nume propriu",
        "greek": "Αβρααμ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Avraham."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיֹּאמַר יְהוָה אֱלֹהֵי אֲדֹנִי אַבְרָהָם הַקְרֵה־נָא לְפָנַי הַיּוֹם וַעֲשֵׂה־חֶסֶד עִם אֲדֹנִי אַבְרָהָם",
        "translation": "„Și a spus: „DOAMNE, Dumnezeul stăpânului meu Avraham, aranjează ziua de azi înaintea mea și fii binevoitor cu stăpânul meu Avraham.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ εἶπεν Κύριε ὁ θεὸς τοῦ κυρίου μου Αβρααμ, εὐόδωσον ἐναντίον ἐμοῦ σήμερον καὶ ποίησον ἔλεος μετὰ τοῦ κυρίου μου Αβρααμ.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויאמר יהוה אלהי אדני אברהם הקרא נא לפני היום ועשה חסד עם אדני אברהם",
        "translation": "Diferență reală, confirmată: ויאמר יהוה אלהי אדני אברהם הקרא נא לפני היום ועשה חסד עם אדני אברהם — „And he said, O LORD God of my master Abraham, I pray thee, send me good speed this day, and shew kindness unto my master Abraham.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 32:9"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Aceasta e prima rugăciune personală a unui slujitor înregistrată în Tora, nu a unui patriarh — un moment de inițiativă spirituală individuală, distinctă de rugăciunile lui Avraham."
      }
    ]
  },
  {
    "num": 13,
    "tokens": [
      {
        "t": "Iată, eu "
      },
      {
        "t": "stau",
        "w": "stau",
        "heb": "נִצָּב",
        "translit": "nitsav",
        "strong": "H5324",
        "pos": "verb, participiu",
        "greek": "ἕστηκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "stau."
      },
      {
        "t": " lângă "
      },
      {
        "t": "izvorul",
        "w": "izvorul",
        "heb": "עֵין",
        "translit": "ein",
        "strong": "H5869",
        "pos": "substantiv, stare construită",
        "greek": "τῆς πηγῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "izvorul."
      },
      {
        "t": " de "
      },
      {
        "t": "apă",
        "w": "apă",
        "heb": "הַמָּיִם",
        "translit": "hamayim",
        "strong": "H4325",
        "pos": "substantiv, cu articol",
        "greek": "τοῦ ὕδατος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "apă."
      },
      {
        "t": " și "
      },
      {
        "t": "fiicele",
        "w": "fiicele",
        "heb": "וּבְנוֹת",
        "translit": "uvenot",
        "strong": "H1323",
        "pos": "substantiv",
        "greek": "αἱ θυγατέρες",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "fiicele."
      },
      {
        "t": " "
      },
      {
        "t": "orășenilor",
        "w": "orășenilor",
        "heb": "אַנְשֵׁי הָעִיר",
        "translit": "anshei ha'ir",
        "strong": "H376",
        "pos": "substantiv, stare construită",
        "greek": "τῆς πόλεως",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "orășenilor."
      },
      {
        "t": " "
      },
      {
        "t": "ies",
        "w": "ies",
        "heb": "יֹצְאֹת",
        "translit": "yotse'ot",
        "strong": "H3318",
        "pos": "verb, participiu",
        "greek": "ἐκπορεύονται",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ies."
      },
      {
        "t": " să "
      },
      {
        "t": "scoată",
        "w": "scoată",
        "heb": "לִשְׁאֹב",
        "translit": "lish'ov",
        "strong": "H7579",
        "pos": "verb (infinitiv)",
        "greek": "ὑδρεύσασθαι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să scoată."
      },
      {
        "t": " apă."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "הִנֵּה אָנֹכִי נִצָּב עַל־עֵין הַמָּיִם וּבְנוֹת אַנְשֵׁי הָעִיר יֹצְאֹת לִשְׁאֹב מָיִם",
        "translation": "„Iată, eu stau lângă izvorul de apă și fiicele orășenilor ies să scoată apă.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "ἰδοὺ ἐγὼ ἕστηκα ἐπὶ τῆς πηγῆς τοῦ ὕδατος, αἱ δὲ θυγατέρες τῶν οἰκούντων τὴν πόλιν ἐκπορεύονται ἀντλῆσαι ὕδωρ,",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "הנה אנכי נצב על עין המים ובנות אנשי העיר יצאת לשאב מים",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Poziția aleasă, chiar lângă izvor, garanta practic întâlnirea cu tinerele cetății, izvorul fiind punctul central al vieții sociale zilnice."
      }
    ],
    "refs": [
      "Exod 2:15-16"
    ]
  },
  {
    "num": 14,
    "tokens": [
      {
        "t": "Fie ca "
      },
      {
        "t": "tânăra",
        "w": "tânăra",
        "heb": "הַנַּעֲרָ",
        "translit": "hana'ara",
        "strong": "H5291",
        "pos": "substantiv, cu articol",
        "greek": "ἡ παρθένος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "tânăra."
      },
      {
        "t": " căreia îi voi "
      },
      {
        "t": "spune",
        "w": "spune",
        "heb": "אֹמַר",
        "translit": "omar",
        "strong": "H559",
        "pos": "verb",
        "greek": "ἐρῶ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "voi spune."
      },
      {
        "t": ": «"
      },
      {
        "t": "Apleacă-ți",
        "w": "Apleacă-ți",
        "heb": "הַטִּי־נָא",
        "translit": "hati na",
        "strong": "H5186",
        "pos": "verb, imperativ",
        "greek": "Ἐπίκλινον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Apleacă-ți."
      },
      {
        "t": ", te rog, "
      },
      {
        "t": "ulciorul",
        "w": "ulciorul",
        "heb": "כַדֵּךְ",
        "translit": "kadekh",
        "strong": "H3537",
        "pos": "substantiv cu sufix",
        "greek": "τὴν ὑδρίαν σου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ulciorul tău."
      },
      {
        "t": " ca să "
      },
      {
        "t": "beau",
        "w": "beau",
        "heb": "וְאֶשְׁתֶּה",
        "translit": "ve'eshteh",
        "strong": "H8354",
        "pos": "verb",
        "greek": "πίω",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "beau."
      },
      {
        "t": "» și care va "
      },
      {
        "t": "spune",
        "w": "spune",
        "heb": "וְאָמְרָה",
        "translit": "ve'amerah",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἴπῃ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "va spune."
      },
      {
        "t": ": «"
      },
      {
        "t": "Bea",
        "w": "Bea",
        "heb": "שְׁתֵה",
        "translit": "shteh",
        "strong": "H8354",
        "pos": "verb, imperativ",
        "greek": "Πίε",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Bea."
      },
      {
        "t": " și eu voi "
      },
      {
        "t": "da",
        "w": "da",
        "heb": "אַשְׁקֶה",
        "translit": "ashkeh",
        "strong": "H8248",
        "pos": "verb",
        "greek": "ποτιῶ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "voi da."
      },
      {
        "t": " apă și "
      },
      {
        "t": "cămilelor",
        "w": "cămilelor",
        "heb": "וּלְגְמַלֶּיךָ",
        "translit": "ulegemalekha",
        "strong": "H1581",
        "pos": "substantiv cu sufix",
        "greek": "τὰς καμήλους σου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămilelor tale."
      },
      {
        "t": " tale» – pe ea să o fi "
      },
      {
        "t": "hotărât",
        "w": "hotărât",
        "heb": "הֹכַחְתָּ",
        "translit": "hokhachta",
        "strong": "H3198",
        "pos": "verb",
        "greek": "ἡτοίμασας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "o fi hotărât."
      },
      {
        "t": " Tu pentru "
      },
      {
        "t": "slujitorul",
        "w": "slujitorul",
        "heb": "לְעַבְדְּךָ",
        "translit": "le'avdekha",
        "strong": "H5650",
        "pos": "substantiv cu sufix",
        "greek": "τῷ παιδί σου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "slujitorul tău."
      },
      {
        "t": " tău, pentru "
      },
      {
        "t": "Isaac",
        "w": "Isaac",
        "heb": "לְיִצְחָק",
        "translit": "leYitschak",
        "strong": "H3327",
        "pos": "nume propriu",
        "greek": "τῷ Ισαακ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Isaac."
      },
      {
        "t": ", și prin ea voi "
      },
      {
        "t": "ști",
        "w": "ști",
        "heb": "אֵדַע",
        "translit": "eda",
        "strong": "H3045",
        "pos": "verb",
        "greek": "γνώσομαι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "voi ști."
      },
      {
        "t": " că Ți-ai "
      },
      {
        "t": "făcut",
        "w": "făcut",
        "heb": "עָשִׂיתָ",
        "translit": "asita",
        "strong": "H6213",
        "pos": "verb",
        "greek": "ἐποίησας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Ți-ai făcut."
      },
      {
        "t": " "
      },
      {
        "t": "milă",
        "w": "milă",
        "heb": "חֶסֶד",
        "translit": "chesed",
        "strong": "H2617",
        "pos": "substantiv",
        "greek": "ἔλεος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "milă."
      },
      {
        "t": " de stăpânul meu.”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וְהָיָה הַנַּעֲרָ אֲשֶׁר אֹמַר אֵלֶיהָ הַטִּי־נָא כַדֵּךְ וְאֶשְׁתֶּה וְאָמְרָה שְׁתֵה וְגַם־גְּמַלֶּיךָ אַשְׁקֶה אֹתָהּ הֹכַחְתָּ לְעַבְדְּךָ לְיִצְחָק וּבָהּ אֵדַע כִּי־עָשִׂיתָ חֶסֶד עִם־אֲדֹנִי",
        "translation": "„Fie ca tânăra căreia îi voi spune: «Apleacă-ți, te rog, ulciorul ca să beau» și care va spune: «Bea și eu voi da apă și cămilelor tale» – pe ea să o fi hotărât Tu pentru slujitorul tău, pentru Isaac, și prin ea voi ști că Ți-ai făcut milă de stăpânul meu.”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἔσται ἡ παρθένος, ᾗ ἂν ἐγὼ εἴπω Ἐπίκλινον τὴν ὑδρίαν σου, ἵνα πίω, καὶ εἴπῃ μοι Πίε, καὶ τὰς καμήλους σου ποτιῶ, ἕως ἂν παύσωνται πίνουσαι, ταύτην ἡτοίμασας τῷ παιδί σου Ισαακ, καὶ ἐν τούτῳ γνώσομαι ὅτι ἐποίησας ἔλεος τῷ κυρίῳ μου Αβρααμ.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "והיה הנערה אשר אמר אליה הטני כדך ואשתה ואמרה שתה וגם גמליך אשקה אתה הוכחת לעבדך ליצחק ובה אדע כי עשית חסד עם אדני אברהם",
        "translation": "Diferență reală, confirmată: והיה הנערה אשר אמר אליה הטני כדך ואשתה ואמרה שתה וגם גמליך אשקה אתה הוכחת לעבדך ליצחק ובה אדע כי עשית חסד עם אדני אברהם — „And let it come to pass, that the damsel to whom I shall say, Let down thy pitcher, I pray thee, that I may drink; and she shall say, Drink, and I will give thy camels drink also: [let the same be] she [that] thou hast appointed for thy servant Isaac; and thereby shall I know that thou hast shewed kindness unto my master Abraham.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Judecători 6:17,37",
      "1 Samuel 6:7-9"
    ],
    "commentaries": [
      {
        "author": "Ramban / Nahmanide (1194–1270)",
        "text": "Corectează o lectură atribuită lui Rashi: rugăciunea nu afirmă că slujitorul știe deja cine e aleasă, ci cere ca Dumnezeu să rânduiască exact acest semn ca dovadă — „lasă să fie ca prin ea să cunosc că ai făcut bunătate cu stăpânul meu”."
      },
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Notează precizia formulării: „pe care ai rânduit-o” înseamnă exact fata pe care Dumnezeu a ales-o pentru Isaac, nu o alta — semnul cerut trebuia să elimine orice ambiguitate."
      },
      {
        "author": "Talmud Babilonian, Taanit 4a (verificat direct în arhivă)",
        "text": "Rabi Șmuel bar Nahmani, în numele lui Rabi Ionatan, discută trei oameni care au cerut de la Dumnezeu semne „nerezonabile” — Eliezer, slujitorul lui Avraham; Saul, fiul lui Chiș; și Iefta Ghiladitul. Despre Eliezer: cererea lui era nerezonabilă pentru că semnul ales ar fi putut fi îndeplinit chiar și de o femeie șchioapă sau oarbă, iar el promisese deja s-o ia pentru Isaac — totuși Dumnezeu i-a răspuns cu bunăvoință, trimițându-i chiar pe Rebeca, cea potrivită."
      }
    ]
  },
  {
    "num": 15,
    "tokens": [
      {
        "t": "Și a fost, când nu "
      },
      {
        "t": "terminase",
        "w": "terminase",
        "heb": "כִלָּה",
        "translit": "khilah",
        "strong": "H3615",
        "pos": "verb",
        "greek": "συνετέλεσεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "terminase."
      },
      {
        "t": " încă de "
      },
      {
        "t": "vorbit",
        "w": "vorbit",
        "heb": "לְדַבֵּר",
        "translit": "ledaber",
        "strong": "H1696",
        "pos": "verb (infinitiv)",
        "greek": "λαλῶν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "de vorbit."
      },
      {
        "t": ", că iată, "
      },
      {
        "t": "Rebeca",
        "w": "Rebeca",
        "heb": "רִבְקָה",
        "translit": "Rivkah",
        "strong": "H7259",
        "pos": "nume propriu",
        "greek": "Ρεβεκκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Rebeca."
      },
      {
        "t": ", cea "
      },
      {
        "t": "născută",
        "w": "născută",
        "heb": "יֻלְּדָה",
        "translit": "yuldah",
        "strong": "H3205",
        "pos": "verb (pual)",
        "greek": "ἐτέχθη",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cea născută."
      },
      {
        "t": " lui "
      },
      {
        "t": "Betuel",
        "w": "Betuel",
        "heb": "לִבְתוּאֵל",
        "translit": "liVetu'el",
        "strong": "H1328",
        "pos": "nume propriu",
        "greek": "τῷ Βαθουηλ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Betuel."
      },
      {
        "t": ", fiul "
      },
      {
        "t": "Milcăi",
        "w": "Milcăi",
        "heb": "מִלְכָּה",
        "translit": "Milkah",
        "strong": "H4435",
        "pos": "nume propriu",
        "greek": "Μελχας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Milcăi."
      },
      {
        "t": ", soția lui "
      },
      {
        "t": "Nahor",
        "w": "Nahor",
        "heb": "נָחוֹר",
        "translit": "Nachor",
        "strong": "H5152",
        "pos": "nume propriu",
        "greek": "Ναχωρ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Nahor."
      },
      {
        "t": ", fratele lui "
      },
      {
        "t": "Avraham",
        "w": "Avraham",
        "heb": "אַבְרָהָם",
        "translit": "Avraham",
        "strong": "H85",
        "pos": "nume propriu",
        "greek": "Αβρααμ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Avraham."
      },
      {
        "t": ", "
      },
      {
        "t": "venea",
        "w": "venea",
        "heb": "יֹצֵאת",
        "translit": "yotset",
        "strong": "H3318",
        "pos": "verb, participiu",
        "greek": "ἐξεπορεύετο",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "venea."
      },
      {
        "t": " cu "
      },
      {
        "t": "ulciorul",
        "w": "ulciorul",
        "heb": "וְכַדָּהּ",
        "translit": "vekhadah",
        "strong": "H3537",
        "pos": "substantiv cu sufix",
        "greek": "ἡ ὑδρία",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ulciorul."
      },
      {
        "t": " pe "
      },
      {
        "t": "umăr",
        "w": "umăr",
        "heb": "שִׁכְמָהּ",
        "translit": "shikhmah",
        "strong": "H7926",
        "pos": "substantiv cu sufix",
        "greek": "τὸν ὦμον αὐτῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "umărul ei."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיְהִי־הוּא טֶרֶם כִּלָּה לְדַבֵּר וְהִנֵּה רִבְקָה יֹצֵאת אֲשֶׁר יֻלְּדָה לִבְתוּאֵל בֶּן־מִלְכָּה אֵשֶׁת נָחוֹר אֲחִי אַבְרָהָם וְכַדָּהּ עַל־שִׁכְמָהּ",
        "translation": "„Și a fost, când nu terminase încă de vorbit, că iată, Rebeca, cea născută lui Betuel, fiul Milcăi, soția lui Nahor, fratele lui Avraham, venea cu ulciorul pe umăr.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἐγένετο πρὸ τοῦ συντελέσαι αὐτὸν λαλοῦντα ἐν τῇ διανοίᾳ, καὶ ἰδοὺ Ρεβεκκα ἐξεπορεύετο ἡ τεχθεῖσα Βαθουηλ υἱῷ Μελχας τῆς γυναικὸς Ναχωρ ἀδελφοῦ δὲ Αβρααμ, ἔχουσα τὴν ὑδρίαν ἐπὶ τῶν ὤμων αὐτῆς.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויהי הוא טרם כלה לדבר אל לבו והנה רבקה יצאת אשר ילדה לבתואל בן מלכה אשת נחור אחי אברהם וכדה על שכמה",
        "translation": "Diferență reală, confirmată: ויהי הוא טרם כלה לדבר אל לבו והנה רבקה יצאת אשר ילדה לבתואל בן מלכה אשת נחור אחי אברהם וכדה על שכמה — „And it came to pass, before he had done speaking in heart of him, that, behold, Rebekah came out, who was born to Bethuel, son of Milcah, the wife of Nahor, Abraham's brother, with her pitcher upon her shoulder.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 22:23"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Viteza răspunsului divin — chiar înainte ca slujitorul să termine de rostit rugăciunea — subliniază cât de direct a fost „auzită” cererea lui."
      }
    ]
  },
  {
    "num": 16,
    "tokens": [
      {
        "t": "Și "
      },
      {
        "t": "fata",
        "w": "fata",
        "heb": "וְהַנַּעֲרָ",
        "translit": "vehana'ara",
        "strong": "H5291",
        "pos": "substantiv, cu articol",
        "greek": "ἡ δὲ παρθένος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "fata."
      },
      {
        "t": " era "
      },
      {
        "t": "foarte",
        "w": "foarte",
        "heb": "מְאֹד",
        "translit": "me'od",
        "strong": "H3966",
        "pos": "adverb",
        "greek": "σφόδρα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "foarte."
      },
      {
        "t": " "
      },
      {
        "t": "frumoasă",
        "w": "frumoasă",
        "heb": "טֹבַת",
        "translit": "tovat",
        "strong": "H2896",
        "pos": "adjectiv, stare construită",
        "greek": "καλὴ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "frumoasă."
      },
      {
        "t": " la "
      },
      {
        "t": "înfățișare",
        "w": "înfățișare",
        "heb": "מַרְאֶה",
        "translit": "mar'eh",
        "strong": "H4758",
        "pos": "substantiv",
        "greek": "τῇ ὄψει",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "înfățișare."
      },
      {
        "t": ", "
      },
      {
        "t": "fecioară",
        "w": "fecioară",
        "heb": "בְּתוּלָה",
        "translit": "betulah",
        "strong": "H1330",
        "pos": "substantiv",
        "greek": "παρθένος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "fecioară."
      },
      {
        "t": ", și niciun "
      },
      {
        "t": "bărbat",
        "w": "bărbat",
        "heb": "וְאִישׁ",
        "translit": "ve'ish",
        "strong": "H376",
        "pos": "substantiv",
        "greek": "ἀνὴρ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "bărbat."
      },
      {
        "t": " nu o "
      },
      {
        "t": "cunoscuse",
        "w": "cunoscuse",
        "heb": "יְדָעָהּ",
        "translit": "yeda'ah",
        "strong": "H3045",
        "pos": "verb, cu sufix",
        "greek": "ἔγνω αὐτήν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "o cunoscuse."
      },
      {
        "t": "; a "
      },
      {
        "t": "coborât",
        "w": "coborât",
        "heb": "וַתֵּרֶד",
        "translit": "vatered",
        "strong": "H3381",
        "pos": "verb",
        "greek": "κατέβη",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a coborât."
      },
      {
        "t": " spre "
      },
      {
        "t": "izvor",
        "w": "izvor",
        "heb": "הָעַיְנָה",
        "translit": "ha'aynah",
        "strong": "H5869",
        "pos": "substantiv, cu articol",
        "greek": "τὴν πηγὴν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "izvor."
      },
      {
        "t": ", și-a "
      },
      {
        "t": "umplut",
        "w": "umplut",
        "heb": "וַתְּמַלֵּא",
        "translit": "vatemale",
        "strong": "H4390",
        "pos": "verb",
        "greek": "ἔπλησεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "și-a umplut."
      },
      {
        "t": " "
      },
      {
        "t": "ulciorul",
        "w": "ulciorul",
        "heb": "כַדָּהּ",
        "translit": "khadah",
        "strong": "H3537",
        "pos": "substantiv cu sufix",
        "greek": "τὴν ὑδρίαν αὐτῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ulciorul ei."
      },
      {
        "t": " și a "
      },
      {
        "t": "urcat",
        "w": "urcat",
        "heb": "וַתָּעַל",
        "translit": "vata'al",
        "strong": "H5927",
        "pos": "verb",
        "greek": "ἀνέβη",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a urcat."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וְהַנַּעֲרָ טֹבַת מַרְאֶה מְאֹד בְּתוּלָה וְאִישׁ לֹא יְדָעָהּ וַתֵּרֶד הָעַיְנָה וַתְּמַלֵּא כַדָּהּ וַתָּעַל",
        "translation": "„Și fata era foarte frumoasă la înfățișare, fecioară, și niciun bărbat nu o cunoscuse; a coborât spre izvor, și-a umplut ulciorul și a urcat.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "ἡ δὲ παρθένος ἦν καλὴ τῇ ὄψει σφόδρα· παρθένος ἦν, ἀνὴρ οὐκ ἔγνω αὐτήν· καταβᾶσα δὲ ἐπὶ τὴν πηγὴν ἔπλησεν τὴν ὑδρίαν καὶ ἀνέβη.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "והנערה טובת מראה מאד בתולה ואיש לא ידעה ותרד העין ותמלא כדה ותעל",
        "translation": "Diferență reală, confirmată: והנערה טובת מראה מאד בתולה ואיש לא ידעה ותרד העין ותמלא כדה ותעל — „And the damsel [was] very fair to look upon, a virgin, neither had any man known her: and she went down to the well, and filled her pitcher, and came up.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 26:7"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Tripla descriere a Rebecăi (frumoasă, fecioară, necunoscută de bărbat) insistă asupra purității ei complete, o calitate relevantă pentru statutul ei viitor de matriarhă."
      }
    ]
  },
  {
    "num": 17,
    "tokens": [
      {
        "t": "Slujitorul",
        "w": "Slujitorul",
        "heb": "הָעֶבֶד",
        "translit": "ha'eved",
        "strong": "H5650",
        "pos": "substantiv, cu articol",
        "greek": "ὁ παῖς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Slujitorul."
      },
      {
        "t": " a "
      },
      {
        "t": "alergat",
        "w": "alergat",
        "heb": "וַיָּרָץ",
        "translit": "vayarats",
        "strong": "H7323",
        "pos": "verb",
        "greek": "συνέδραμεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a alergat."
      },
      {
        "t": " în "
      },
      {
        "t": "întâmpinarea",
        "w": "întâmpinarea",
        "heb": "לִקְרָאתָהּ",
        "translit": "likratah",
        "strong": "H7125",
        "pos": "substantiv cu sufix",
        "greek": "εἰς συνάντησιν αὐτῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "întâmpinarea ei."
      },
      {
        "t": " ei și a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמֶר",
        "translit": "vayomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a spus."
      },
      {
        "t": ": „"
      },
      {
        "t": "Dă-mi",
        "w": "Dă-mi",
        "heb": "הַגְמִיאִינִי",
        "translit": "hagmi'ini",
        "strong": "H1572",
        "pos": "verb, imperativ, cu sufix",
        "greek": "Πότισόν με",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Dă-mi."
      },
      {
        "t": ", rogu-te, să "
      },
      {
        "t": "sorb",
        "w": "sorb",
        "heb": "נָא",
        "translit": "na",
        "strong": "H4994",
        "pos": "particulă",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să sorb."
      },
      {
        "t": " puțină "
      },
      {
        "t": "apă",
        "w": "apă",
        "heb": "מַיִם",
        "translit": "mayim",
        "strong": "H4325",
        "pos": "substantiv",
        "greek": "ὕδωρ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "apă."
      },
      {
        "t": " din "
      },
      {
        "t": "ulciorul",
        "w": "ulciorul",
        "heb": "מִכַּדֵּךְ",
        "translit": "mikadekh",
        "strong": "H3537",
        "pos": "substantiv cu sufix",
        "greek": "ἐκ τῆς ὑδρίας σου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ulciorul tău."
      },
      {
        "t": " tău.”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיָּרָץ הָעֶבֶד לִקְרָאתָהּ וַיֹּאמֶר הַגְמִיאִינִי נָא מְעַט־מַיִם מִכַּדֵּךְ",
        "translation": "„Slujitorul a alergat în întâmpinarea ei și a spus: „Dă-mi, rogu-te, să sorb puțină apă din ulciorul tău.”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "ἐπέδραμεν δὲ ὁ παῖς εἰς συνάντησιν αὐτῆς καὶ εἶπεν Πότισόν με μικρὸν ὕδωρ ἐκ τῆς ὑδρίας σου.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "וירץ העבד לקראתה ויאמר הגמיני נא מעט מים מכדך",
        "translation": "Diferență reală, confirmată: וירץ העבד לקראתה ויאמר הגמיני נא מעט מים מכדך — „And the servant ran to meet her, and said, Let me, I pray thee, drink a little water of thy pitcher.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:43"
    ],
    "commentaries": [
      {
        "author": "Rashi (1040–1105)",
        "text": "Explică graba slujitorului de a alerga spre ea: pentru că a văzut apa ridicându-se să o întâmpine — un semn deja miraculos, înainte chiar ca ea să răspundă la test."
      },
      {
        "author": "Ramban / Nahmanide (1194–1270)",
        "text": "Dezvoltă nota lui Rashi citând Bereșit Rabba: toate celelalte femei coborau la izvor să-și umple ulcioarele, dar apa s-a ridicat singură spre Rebeca de îndată ce s-a apropiat — semn citit ca prevestire a binecuvântării urmașilor ei. Ramban observă că minunea s-a petrecut o singură dată, la prima ei coborâre; ulterior textul revine la limbajul obișnuit „a scos apă”."
      }
    ]
  },
  {
    "num": 18,
    "tokens": [
      {
        "t": "Ea a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַתֹּאמֶר",
        "translit": "vatomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a spus."
      },
      {
        "t": ": „"
      },
      {
        "t": "Bea",
        "w": "Bea",
        "heb": "שְׁתֵה",
        "translit": "shteh",
        "strong": "H8354",
        "pos": "verb, imperativ",
        "greek": "Πίε",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Bea."
      },
      {
        "t": ", domnul meu!”, și s-a "
      },
      {
        "t": "grăbit",
        "w": "grăbit",
        "heb": "וַתְּמַהֵר",
        "translit": "vatemaher",
        "strong": "H4116",
        "pos": "verb",
        "greek": "ἔσπευσεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "s-a grăbit."
      },
      {
        "t": " și și-a "
      },
      {
        "t": "coborât",
        "w": "coborât",
        "heb": "וַתֹּרֶד",
        "translit": "vatored",
        "strong": "H3381",
        "pos": "verb",
        "greek": "καθεῖλεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "și-a coborât."
      },
      {
        "t": " "
      },
      {
        "t": "ulciorul",
        "w": "ulciorul",
        "heb": "כַדָּהּ",
        "translit": "khadah",
        "strong": "H3537",
        "pos": "substantiv cu sufix",
        "greek": "τὴν ὑδρίαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ulciorul."
      },
      {
        "t": " în "
      },
      {
        "t": "mână",
        "w": "mână",
        "heb": "יָדָהּ",
        "translit": "yadah",
        "strong": "H3027",
        "pos": "substantiv cu sufix",
        "greek": "ἐπὶ τὸν βραχίονα αὐτῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mâna ei."
      },
      {
        "t": " și i-a "
      },
      {
        "t": "dat",
        "w": "dat",
        "heb": "וַתַּשְׁקֵהוּ",
        "translit": "vatashkehu",
        "strong": "H8248",
        "pos": "verb, cu sufix",
        "greek": "ἐπότισεν αὐτόν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-a dat."
      },
      {
        "t": " să bea."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַתֹּאמֶר שְׁתֵה אֲדֹנִי וַתְּמַהֵר וַתֹּרֶד כַּדָּהּ עַל־יָדָהּ וַתַּשְׁקֵהוּ",
        "translation": "„Ea a spus: „Bea, domnul meu!”, și s-a grăbit și și-a coborât ulciorul în mână și i-a dat să bea.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "ἡ δὲ εἶπεν Πίε, κύριε. καὶ ἔσπευσεν καὶ καθεῖλεν τὴν ὑδρίαν ἐπὶ τὸν βραχίονα αὐτῆς καὶ ἐπότισεν αὐτόν,",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ותאמר שתה אדני ותמהר ותורד כדה על ידה ותשקהו",
        "translation": "Diferență reală, confirmată: ותאמר שתה אדני ותמהר ותורד כדה על ידה ותשקהו — „And she said, Drink, my lord: and she hasted, and let down her pitcher upon her hand, and gave him drink.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Răspunsul prompt și respectuos, „domnul meu”, arată o politețe firească față de un străin, înainte ca ea să știe cine este el sau ce reprezintă."
      }
    ],
    "refs": [
      "Geneza 18:4-8"
    ]
  },
  {
    "num": 19,
    "tokens": [
      {
        "t": "A "
      },
      {
        "t": "terminat",
        "w": "terminat",
        "heb": "וַתְּכַל",
        "translit": "vatekhal",
        "strong": "H3615",
        "pos": "verb",
        "greek": "συνετέλεσεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "A terminat."
      },
      {
        "t": " să-i "
      },
      {
        "t": "dea",
        "w": "dea",
        "heb": "לְהַשְׁקֹתוֹ",
        "translit": "lehashkoto",
        "strong": "H8248",
        "pos": "verb (infinitiv), cu sufix",
        "greek": "ποτίζουσα αὐτόν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să-i dea."
      },
      {
        "t": " de "
      },
      {
        "t": "băut",
        "w": "băut",
        "heb": "",
        "translit": "",
        "strong": "",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "de băut."
      },
      {
        "t": " și a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַתֹּאמֶר",
        "translit": "vatomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a spus."
      },
      {
        "t": ": „Voi "
      },
      {
        "t": "scoate",
        "w": "scoate",
        "heb": "אֶשְׁאָב",
        "translit": "esh'av",
        "strong": "H7579",
        "pos": "verb",
        "greek": "ἀντλήσω",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "voi scoate."
      },
      {
        "t": " apă și pentru "
      },
      {
        "t": "cămilele",
        "w": "cămilele",
        "heb": "לִגְמַלֶּיךָ",
        "translit": "ligemalekha",
        "strong": "H1581",
        "pos": "substantiv cu sufix",
        "greek": "ταῖς καμήλοις σου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămilele tale."
      },
      {
        "t": " tale, până când vor "
      },
      {
        "t": "termina",
        "w": "termina",
        "heb": "כִּלּוּ",
        "translit": "kilu",
        "strong": "H3615",
        "pos": "verb",
        "greek": "πίωσιν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "vor termina."
      },
      {
        "t": " de "
      },
      {
        "t": "băut",
        "w": "băut",
        "heb": "לִשְׁתֹּת",
        "translit": "lishtot",
        "strong": "H8354",
        "pos": "verb (infinitiv)",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "de băut."
      },
      {
        "t": ".”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַתְּכַל לְהַשְׁקֹתוֹ וַתֹּאמֶר גַּם לִגְמַלֶּיךָ אֶשְׁאָב עַד אִם־כִּלּוּ לִשְׁתֹּת",
        "translation": "„A terminat să-i dea de băut și a spus: „Voi scoate apă și pentru cămilele tale, până când vor termina de băut.”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "ἕως ἐπαύσατο πίνων. καὶ εἶπεν Καὶ ταῖς καμήλοις σου ὑδρεύσομαι, ἕως ἂν πᾶσαι πίωσιν.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ותכל להשקותו ותאמר גם לגמליך אשאב עד אם כלו לשתות",
        "translation": "Diferență reală, confirmată: ותכל להשקותו ותאמר גם לגמליך אשאב עד אם כלו לשתות — „And when she had done giving him drink, she said, I will draw [water] for thy camels also, until they have done drinking.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:14"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Oferta de a adăpa și cămilele vine din proprie inițiativă, nu la cerere — exact semnul specific cerut de slujitor în rugăciune (v.14), dar oferit fără să știe de test."
      }
    ]
  },
  {
    "num": 20,
    "tokens": [
      {
        "t": "S-a "
      },
      {
        "t": "grăbit",
        "w": "grăbit",
        "heb": "וַתְּמַהֵר",
        "translit": "vatemaher",
        "strong": "H4116",
        "pos": "verb",
        "greek": "ἔσπευσεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "S-a grăbit."
      },
      {
        "t": " și și-a "
      },
      {
        "t": "deșertat",
        "w": "deșertat",
        "heb": "וַתְּעַר",
        "translit": "vate'ar",
        "strong": "H6168",
        "pos": "verb",
        "greek": "ἐξεκένωσεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "și-a deșertat."
      },
      {
        "t": " "
      },
      {
        "t": "ulciorul",
        "w": "ulciorul",
        "heb": "כַּדָּהּ",
        "translit": "khadah",
        "strong": "H3537",
        "pos": "substantiv cu sufix",
        "greek": "τὴν ὑδρίαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ulciorul."
      },
      {
        "t": " în "
      },
      {
        "t": "jgheab",
        "w": "jgheab",
        "heb": "הַשֹּׁקֶת",
        "translit": "hashoket",
        "strong": "H8268",
        "pos": "substantiv, cu articol",
        "greek": "τὸ ποτιστήριον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "jgheab."
      },
      {
        "t": " și a "
      },
      {
        "t": "alergat",
        "w": "alergat",
        "heb": "וַתָּרָץ",
        "translit": "vatarats",
        "strong": "H7323",
        "pos": "verb",
        "greek": "ἔδραμεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a alergat."
      },
      {
        "t": " din nou la "
      },
      {
        "t": "fântână",
        "w": "fântână",
        "heb": "הַבְּאֵר",
        "translit": "habe'er",
        "strong": "H875",
        "pos": "substantiv, cu articol",
        "greek": "τὸ φρέαρ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "fântână."
      },
      {
        "t": " să "
      },
      {
        "t": "scoată",
        "w": "scoată",
        "heb": "לִשְׁאֹב",
        "translit": "lish'ov",
        "strong": "H7579",
        "pos": "verb (infinitiv)",
        "greek": "ἀντλῆσαι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să scoată."
      },
      {
        "t": " [apă] și a "
      },
      {
        "t": "scos",
        "w": "scos",
        "heb": "וַתִּשְׁאַב",
        "translit": "vatish'av",
        "strong": "H7579",
        "pos": "verb",
        "greek": "ὕδρευσεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a scos."
      },
      {
        "t": " pentru toate "
      },
      {
        "t": "cămilele",
        "w": "cămilele",
        "heb": "לְכָל־גְּמַלָּיו",
        "translit": "lekhol gemalav",
        "strong": "H1581",
        "pos": "substantiv cu sufix",
        "greek": "πάσαις ταῖς καμήλοις",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămilele."
      },
      {
        "t": " lui."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַתְּמַהֵר וַתְּעַר כַּדָּהּ אֶל־הַשֹּׁקֶת וַתָּרָץ עוֹד אֶל־הַבְּאֵר לִשְׁאֹב וַתִּשְׁאַב לְכָל־גְּמַלָּיו",
        "translation": "„S-a grăbit și și-a deșertat ulciorul în jgheab și a alergat din nou la fântână să scoată [apă] și a scos pentru toate cămilele lui.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἔσπευσεν καὶ ἐξεκένωσεν τὴν ὑδρίαν εἰς τὸ ποτιστήριον καὶ ἔδραμεν ἔτι ἐπὶ τὸ φρέαρ ἀντλῆσαι καὶ ὑδρεύσατο πάσαις ταῖς καμήλοις.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ותמהר ותורד כדה על השקות ותרץ עוד אל הבאר לשאב ותשאב לכל גמליו",
        "translation": "Diferență reală, confirmată: ותמהר ותורד כדה על השקות ותרץ עוד אל הבאר לשאב ותשאב לכל גמליו — „And she hasted, and let down her pitcher into the trough, and ran again unto the well to draw [water], and drew for all his camels.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Efortul fizic real — zece cămile pot bea cantități mari de apă — arată amploarea generozității Rebecăi, dincolo de un gest minor de curtoazie."
      }
    ],
    "refs": [
      "Geneza 29:10"
    ]
  },
  {
    "num": 21,
    "tokens": [
      {
        "t": "Iar "
      },
      {
        "t": "omul",
        "w": "omul",
        "heb": "וְהָאִישׁ",
        "translit": "veha'ish",
        "strong": "H376",
        "pos": "substantiv, cu articol",
        "greek": "ὁ δὲ ἄνθρωπος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "omul."
      },
      {
        "t": " era "
      },
      {
        "t": "uimit",
        "w": "uimit",
        "heb": "מִשְׁתָּאֵה",
        "translit": "mishta'eh",
        "strong": "H8104",
        "pos": "verb, participiu",
        "greek": "κατεμάνθανεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "uimit."
      },
      {
        "t": " de ea, "
      },
      {
        "t": "gândindu-se",
        "w": "gândindu-se",
        "heb": "",
        "translit": "",
        "strong": "",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "gândindu-se."
      },
      {
        "t": " în "
      },
      {
        "t": "tăcere",
        "w": "tăcere",
        "heb": "מַחֲרִישׁ",
        "translit": "macharish",
        "strong": "H2790",
        "pos": "verb, participiu",
        "greek": "σιωπῶν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "tăcere."
      },
      {
        "t": " dacă "
      },
      {
        "t": "DOMNUL",
        "w": "DOMNUL",
        "heb": "יְהוָה",
        "translit": "YHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κύριος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNUL."
      },
      {
        "t": " i-a "
      },
      {
        "t": "făcut",
        "w": "făcut",
        "heb": "הַהִצְלִיחַ",
        "translit": "hahitsliach",
        "strong": "H6743",
        "pos": "verb",
        "greek": "εὐόδωκεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-a făcut."
      },
      {
        "t": " "
      },
      {
        "t": "reușită",
        "w": "reușită",
        "heb": "",
        "translit": "",
        "strong": "",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "reușită."
      },
      {
        "t": " "
      },
      {
        "t": "călătoria",
        "w": "călătoria",
        "heb": "דַּרְכּוֹ",
        "translit": "darko",
        "strong": "H1870",
        "pos": "substantiv cu sufix",
        "greek": "τὴν ὁδὸν αὐτοῦ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "călătoria lui."
      },
      {
        "t": " sau nu."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וְהָאִישׁ מִשְׁתָּאֵה לָהּ מַחֲרִישׁ לָדַעַת הַהִצְלִיחַ יְהוָה דַּרְכּוֹ אִם־לֹא",
        "translation": "„Iar omul era uimit de ea, gândindu-se în tăcere dacă DOMNUL i-a făcut reușită călătoria sau nu.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "ὁ δὲ ἄνθρωπος κατεμάνθανεν αὐτὴν καὶ παρεσιώπα τοῦ γνῶναι εἰ εὐόδωκεν Κύριος τὴν ὁδὸν αὐτοῦ ἢ οὔ.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "והאיש משתה לה ומחריש לדעת הצליח יהוה דרכו אם לא",
        "translation": "Diferență reală, confirmată: והאיש משתה לה ומחריש לדעת הצליח יהוה דרכו אם לא — „And the man wondering at her held his peace, to wit whether the LORD had made his journey prosperous or not.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Tăcerea observatoare a slujitorului sugerează prudență: aștepta confirmarea completă (inclusiv identitatea familiei) înainte de a considera rugăciunea împlinită."
      }
    ],
    "refs": [
      "Geneza 24:12"
    ]
  },
  {
    "num": 22,
    "tokens": [
      {
        "t": "Și a fost, atunci când "
      },
      {
        "t": "cămilele",
        "w": "cămilele",
        "heb": "הַגְּמַלִּים",
        "translit": "hagemalim",
        "strong": "H1581",
        "pos": "substantiv, cu articol",
        "greek": "αἱ κάμηλοι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămilele."
      },
      {
        "t": " au "
      },
      {
        "t": "terminat",
        "w": "terminat",
        "heb": "כִלּוּ",
        "translit": "khilu",
        "strong": "H3615",
        "pos": "verb",
        "greek": "ἐπαύσαντο",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "au terminat."
      },
      {
        "t": " de "
      },
      {
        "t": "băut",
        "w": "băut",
        "heb": "לִשְׁתּוֹת",
        "translit": "lishtot",
        "strong": "H8354",
        "pos": "verb (infinitiv)",
        "greek": "πίνουσαι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "de băut."
      },
      {
        "t": ", că "
      },
      {
        "t": "omul",
        "w": "omul",
        "heb": "הָאִישׁ",
        "translit": "ha'ish",
        "strong": "H376",
        "pos": "substantiv, cu articol",
        "greek": "ὁ ἄνθρωπος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "omul."
      },
      {
        "t": " a "
      },
      {
        "t": "luat",
        "w": "luat",
        "heb": "וַיִּקַּח",
        "translit": "vayikach",
        "strong": "H3947",
        "pos": "verb",
        "greek": "ἔλαβεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a luat."
      },
      {
        "t": " un "
      },
      {
        "t": "inel",
        "w": "inel",
        "heb": "נֶזֶם",
        "translit": "nezem",
        "strong": "H5141",
        "pos": "substantiv",
        "greek": "ἐνώτια",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "inel."
      },
      {
        "t": " de "
      },
      {
        "t": "aur",
        "w": "aur",
        "heb": "זָהָב",
        "translit": "zahav",
        "strong": "H2091",
        "pos": "substantiv",
        "greek": "χρυσᾶ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "aur."
      },
      {
        "t": " pentru "
      },
      {
        "t": "nas",
        "w": "nas",
        "heb": "",
        "translit": "",
        "strong": "",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "nas."
      },
      {
        "t": " în "
      },
      {
        "t": "greutate",
        "w": "greutate",
        "heb": "מִשְׁקָלוֹ",
        "translit": "mishkalo",
        "strong": "H4948",
        "pos": "substantiv cu sufix",
        "greek": "τὸν σταθμὸν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "greutate."
      },
      {
        "t": " de o "
      },
      {
        "t": "beka",
        "w": "beka",
        "heb": "בֶּקַע",
        "translit": "beka",
        "strong": "H1235",
        "pos": "substantiv",
        "greek": "δραχμῆς χρυσᾶς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "beka."
      },
      {
        "t": " și "
      },
      {
        "t": "două",
        "w": "două",
        "heb": "שְׁנֵי",
        "translit": "shnei",
        "strong": "H8147",
        "pos": "numeral",
        "greek": "δύο",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "două."
      },
      {
        "t": " "
      },
      {
        "t": "brățări",
        "w": "brățări",
        "heb": "צְמִידִים",
        "translit": "tsemidim",
        "strong": "H6781",
        "pos": "substantiv",
        "greek": "ψέλια",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "brățări."
      },
      {
        "t": " pentru "
      },
      {
        "t": "mâinile",
        "w": "mâinile",
        "heb": "יָדֶיהָ",
        "translit": "yadeiha",
        "strong": "H3027",
        "pos": "substantiv cu sufix",
        "greek": "τὰς χεῖρας αὐτῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mâinile ei."
      },
      {
        "t": " ei, cu "
      },
      {
        "t": "greutatea",
        "w": "greutatea",
        "heb": "מִשְׁקָלָם",
        "translit": "mishkalam",
        "strong": "H4948",
        "pos": "substantiv cu sufix",
        "greek": "τὸν σταθμὸν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "greutatea."
      },
      {
        "t": " de "
      },
      {
        "t": "zece",
        "w": "zece",
        "heb": "עֲשָׂרָה",
        "translit": "asarah",
        "strong": "H6235",
        "pos": "numeral",
        "greek": "δέκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "zece."
      },
      {
        "t": " "
      },
      {
        "t": "sicli",
        "w": "sicli",
        "heb": "זָהָב",
        "translit": "zahav",
        "strong": "H2091",
        "pos": "substantiv",
        "greek": "χρυσίου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "sicli."
      },
      {
        "t": " de "
      },
      {
        "t": "aur",
        "w": "aur",
        "heb": "",
        "translit": "",
        "strong": "",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "aur."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיְהִי כַּאֲשֶׁר כִּלּוּ הַגְּמַלִּים לִשְׁתּוֹת וַיִּקַּח הָאִישׁ נֶזֶם זָהָב בֶּקַע מִשְׁקָלוֹ וּשְׁנֵי צְמִידִים עַל־יָדֶיהָ עֲשָׂרָה זָהָב מִשְׁקָלָם",
        "translation": "„Și a fost, atunci când cămilele au terminat de băut, că omul a luat un inel de aur pentru nas în greutate de o beka și două brățări pentru mâinile ei, cu greutatea de zece sicli de aur.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "ἐγένετο δὲ ἡνίκα ἐπαύσαντο πᾶσαι αἱ κάμηλοι πίνουσαι, ἔλαβεν ὁ ἄνθρωπος ἐνώτια χρυσᾶ ἀνὰ δραχμὴν ὁλκῆς καὶ δύο ψέλια ἐπὶ τὰς χεῖρας αὐτῆς, δέκα χρυσῶν ὁλκὴ αὐτῶν.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויהי כאשר כלו הגמלים לשתות ויקח האיש נזם זהב בקע משקלו וישם על אפה ושני צמידים על ידיה עשרה זהב משקלם",
        "translation": "Diferență reală, confirmată: ויהי כאשר כלו הגמלים לשתות ויקח האיש נזם זהב בקע משקלו וישם על אפה ושני צמידים על ידיה עשרה זהב משקלם — „And it came to pass, as the camels had done drinking, that the man took a golden earring of half a shekel weight and placed on nose of her, and two bracelets for her hands of ten [shekels] weight of gold;”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:47",
      "Exod 32:2-3"
    ],
    "commentaries": [
      {
        "author": "Ramban / Nahmanide (1194–1270)",
        "text": "Observă o elipsă textuală: versetul spune că bărbatul „a luat” inelul și brățările, dar nu spune explicit că i le-a pus atunci. Ramban propune ordinea corectă: el le-a luat pregătit să i le dea, a întrebat-o mai întâi a cui fiică este, și abia după răspunsul ei i le-a pus — ordine confirmată de felul în care slujitorul povestește ulterior scena (v.47)."
      }
    ]
  },
  {
    "num": 23,
    "tokens": [
      {
        "t": "Și a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמֶר",
        "translit": "vayomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a spus."
      },
      {
        "t": ": „A cui "
      },
      {
        "t": "fiică",
        "w": "fiică",
        "heb": "בַת",
        "translit": "vat",
        "strong": "H1323",
        "pos": "substantiv",
        "greek": "θυγάτηρ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "fiică."
      },
      {
        "t": " ești tu? "
      },
      {
        "t": "Spune-mi",
        "w": "Spune-mi",
        "heb": "הַגִּידִי",
        "translit": "hagidi",
        "strong": "H5046",
        "pos": "verb, imperativ",
        "greek": "ἀνάγγειλόν μοι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Spune-mi."
      },
      {
        "t": ", te rog! Este oare "
      },
      {
        "t": "loc",
        "w": "loc",
        "heb": "מָקוֹם",
        "translit": "makom",
        "strong": "H4725",
        "pos": "substantiv",
        "greek": "τόπος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "loc."
      },
      {
        "t": " pentru noi să "
      },
      {
        "t": "înnoptăm",
        "w": "înnoptăm",
        "heb": "לָלִין",
        "translit": "lalin",
        "strong": "H3885",
        "pos": "verb (infinitiv)",
        "greek": "καταλῦσαι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să înnoptăm."
      },
      {
        "t": " în "
      },
      {
        "t": "casa",
        "w": "casa",
        "heb": "בֵית",
        "translit": "veit",
        "strong": "H1004",
        "pos": "substantiv, stare construită",
        "greek": "τῷ οἴκῳ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "casa."
      },
      {
        "t": " tatălui tău?”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיֹּאמֶר בַּת־מִי אַתְּ הַגִּידִי נָא לִי הֲיֵשׁ בֵּית־אָבִיךְ מָקוֹם לָנוּ לָלִין",
        "translation": "„Și a spus: „A cui fiică ești tu? Spune-mi, te rog! Este oare loc pentru noi să înnoptăm în casa tatălui tău?”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἐπηρώτησεν αὐτὴν καὶ εἶπεν Θυγάτηρ τίνος εἶ; ἀνάγγειλόν μοι· εἰ ἔστιν παρὰ τῷ πατρί σου τόπος ἡμῖν καταλῦσαι;",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויאמר בת מי אתי הגידי נא לי היש בבית אביך מקום לנו ללין",
        "translation": "Diferență reală, confirmată: ויאמר בת מי אתי הגידי נא לי היש בבית אביך מקום לנו ללין — „And said, Whose daughter [art] thou? tell me, I pray thee: is there room in thy father's house for us to lodge in?”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:47"
    ],
    "commentaries": [
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Notă gramaticală: distinge între forma „lalin” (folosită de slujitor, referindu-se la un loc pentru persoane) și „lalun” (folosită mai târziu de Rebeca, referitoare la găzduirea propriu-zisă a trupurilor) — o nuanță de limbă ebraică fină între cele două formulări aparent similare."
      }
    ]
  },
  {
    "num": 24,
    "tokens": [
      {
        "t": "Ea i-a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַתֹּאמֶר",
        "translit": "vatomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-a spus."
      },
      {
        "t": ": „Sunt "
      },
      {
        "t": "fiica",
        "w": "fiica",
        "heb": "בַת",
        "translit": "vat",
        "strong": "H1323",
        "pos": "substantiv, stare construită",
        "greek": "θυγάτηρ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "fiica."
      },
      {
        "t": " lui "
      },
      {
        "t": "Betuel",
        "w": "Betuel",
        "heb": "בְתוּאֵל",
        "translit": "Vetu'el",
        "strong": "H1328",
        "pos": "nume propriu",
        "greek": "Βαθουηλ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Betuel."
      },
      {
        "t": ", fiul lui "
      },
      {
        "t": "Milca",
        "w": "Milca",
        "heb": "מִלְכָּה",
        "translit": "Milkah",
        "strong": "H4435",
        "pos": "nume propriu",
        "greek": "Μελχας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Milca."
      },
      {
        "t": ", pe care i l-a "
      },
      {
        "t": "născut",
        "w": "născut",
        "heb": "יָלְדָה",
        "translit": "yaldah",
        "strong": "H3205",
        "pos": "verb",
        "greek": "ἔτεκεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i l-a născut."
      },
      {
        "t": " lui "
      },
      {
        "t": "Nahor",
        "w": "Nahor",
        "heb": "לְנָחוֹר",
        "translit": "leNachor",
        "strong": "H5152",
        "pos": "nume propriu",
        "greek": "τῷ Ναχωρ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Nahor."
      },
      {
        "t": ".”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַתֹּאמֶר אֵלָיו בַּת־בְּתוּאֵל אָנֹכִי בֶּן־מִלְכָּה אֲשֶׁר יָלְדָה לְנָחוֹר",
        "translation": "„Ea i-a spus: „Sunt fiica lui Betuel, fiul lui Milca, pe care i l-a născut lui Nahor.”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "ἡ δὲ εἶπεν αὐτῷ Θυγάτηρ Βαθουηλ εἰμὶ τοῦ Μελχας, ὃν ἔτεκεν τῷ Ναχωρ.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ותאמר אליו בת בתואל אנכי בן מלכה אשר ילדה לנחור",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Răspunsul vine abia acum, după testul comportamental deja trecut — genealogia (relevantă pentru validarea misiunii) e verificată după caracter, nu înainte."
      }
    ],
    "refs": [
      "Geneza 22:20-23"
    ]
  },
  {
    "num": 25,
    "tokens": [
      {
        "t": "Și i-a [mai] "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַתֹּאמֶר",
        "translit": "vatomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a spus."
      },
      {
        "t": ": „Avem la noi nu doar "
      },
      {
        "t": "fân",
        "w": "fân",
        "heb": "תֶּבֶן",
        "translit": "teven",
        "strong": "H8401",
        "pos": "substantiv",
        "greek": "ἄχυρα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "fân."
      },
      {
        "t": " și "
      },
      {
        "t": "nutreț",
        "w": "nutreț",
        "heb": "מִסְפּוֹא",
        "translit": "mispo",
        "strong": "H4554",
        "pos": "substantiv",
        "greek": "χορτάσματα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "nutreț."
      },
      {
        "t": " din "
      },
      {
        "t": "belșug",
        "w": "belșug",
        "heb": "רַב",
        "translit": "rav",
        "strong": "H7227",
        "pos": "adjectiv",
        "greek": "πολλὰ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "belșug."
      },
      {
        "t": ", ci și "
      },
      {
        "t": "loc",
        "w": "loc",
        "heb": "מָקוֹם",
        "translit": "makom",
        "strong": "H4725",
        "pos": "substantiv",
        "greek": "τόπος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "loc."
      },
      {
        "t": " de "
      },
      {
        "t": "înnoptat",
        "w": "înnoptat",
        "heb": "לָלוּן",
        "translit": "lalun",
        "strong": "H3885",
        "pos": "verb (infinitiv)",
        "greek": "καταλῦσαι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "de înnoptat."
      },
      {
        "t": ".”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַתֹּאמֶר אֵלָיו גַּם־תֶּבֶן גַּם־מִסְפּוֹא רַב עִמָּנוּ גַּם־מָקוֹם לָלוּן",
        "translation": "„Și i-a [mai] spus: „Avem la noi nu doar fân și nutreț din belșug, ci și loc de înnoptat.”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ εἶπεν αὐτῷ Καὶ ἄχυρα καὶ χορτάσματα πολλὰ παρ᾿ ἡμῖν καὶ τόπος τοῦ καταλῦσαι.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ותאמר אליו גם תבן גם מספה רב עמנו וגם מקום ללין",
        "translation": "Diferență reală, confirmată: ותאמר אליו גם תבן גם מספה רב עמנו וגם מקום ללין — „She said moreover unto him, We have both straw and provender enough, and room to lodge in.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Oferta de nutreț și găzduire vine spontan, adăugată la răspunsul despre identitate, confirmând generozitatea deja arătată la fântână."
      }
    ],
    "refs": [
      "Judecători 19:20"
    ]
  },
  {
    "num": 26,
    "tokens": [
      {
        "t": "Iar "
      },
      {
        "t": "omul",
        "w": "omul",
        "heb": "הָאִישׁ",
        "translit": "ha'ish",
        "strong": "H376",
        "pos": "substantiv, cu articol",
        "greek": "ὁ ἄνθρωπος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "omul."
      },
      {
        "t": " s-a "
      },
      {
        "t": "înclinat",
        "w": "înclinat",
        "heb": "וַיִּקֹּד",
        "translit": "vayikod",
        "strong": "H6915",
        "pos": "verb",
        "greek": "εὐδοκήσας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "s-a înclinat."
      },
      {
        "t": " și s-a "
      },
      {
        "t": "prosternat",
        "w": "prosternat",
        "heb": "וַיִּשְׁתַּחוּ",
        "translit": "vayishtachu",
        "strong": "H7812",
        "pos": "verb",
        "greek": "προσεκύνησεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "s-a prosternat."
      },
      {
        "t": " "
      },
      {
        "t": "DOMNULUI",
        "w": "DOMNULUI",
        "heb": "לַיהוָה",
        "translit": "laYHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κυρίῳ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNULUI."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיִּקֹּד הָאִישׁ וַיִּשְׁתַּחוּ לַיהוָה",
        "translation": "„Iar omul s-a înclinat și s-a prosternat DOMNULUI.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ εὐδοκήσας ὁ ἄνθρωπος προσεκύνησεν Κυρίῳ",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויקד האיש וישתחוי ליהוה",
        "translation": "Diferență reală, confirmată: ויקד האיש וישתחוי ליהוה — „And the man bowed down his head, and worshipped the LORD.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:48,52"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Recunoștința slujitorului, exprimată prin închinare înainte chiar de a intra în casă, arată prioritatea pe care o acordă mulțumirii aduse lui Dumnezeu, înaintea oricărei formalități sociale."
      }
    ]
  },
  {
    "num": 27,
    "tokens": [
      {
        "t": "Și a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמֶר",
        "translit": "vayomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a spus."
      },
      {
        "t": ": „"
      },
      {
        "t": "Binecuvântat",
        "w": "Binecuvântat",
        "heb": "בָּרוּךְ",
        "translit": "barukh",
        "strong": "H1288",
        "pos": "adjectiv",
        "greek": "εὐλογητὸς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Binecuvântat."
      },
      {
        "t": " este "
      },
      {
        "t": "DOMNUL",
        "w": "DOMNUL",
        "heb": "יְהוָה",
        "translit": "YHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κύριος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNUL."
      },
      {
        "t": ", "
      },
      {
        "t": "Dumnezeul",
        "w": "Dumnezeul",
        "heb": "אֱלֹהֵי",
        "translit": "Elohei",
        "strong": "H430",
        "pos": "substantiv, stare construită",
        "greek": "ὁ Θεὸς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Dumnezeul."
      },
      {
        "t": " stăpânului meu "
      },
      {
        "t": "Avraham",
        "w": "Avraham",
        "heb": "אֲדֹנִי אַבְרָהָם",
        "translit": "adoni Avraham",
        "strong": "H85",
        "pos": "nume propriu",
        "greek": "τοῦ κυρίου μου Αβρααμ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Avraham."
      },
      {
        "t": ", care nu Și-a "
      },
      {
        "t": "reținut",
        "w": "reținut",
        "heb": "עָזַב",
        "translit": "azav",
        "strong": "H5800",
        "pos": "verb",
        "greek": "ἐγκατέλιπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Și-a reținut."
      },
      {
        "t": " "
      },
      {
        "t": "bunăvoința",
        "w": "bunăvoința",
        "heb": "חַסְדּוֹ",
        "translit": "chasdo",
        "strong": "H2617",
        "pos": "substantiv cu sufix",
        "greek": "τὴν δικαιοσύνην αὐτοῦ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "bunăvoința lui."
      },
      {
        "t": " și "
      },
      {
        "t": "adevărul",
        "w": "adevărul",
        "heb": "וַאֲמִתּוֹ",
        "translit": "va'amito",
        "strong": "H571",
        "pos": "substantiv cu sufix",
        "greek": "τὴν ἀλήθειαν αὐτοῦ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "adevărul lui."
      },
      {
        "t": " de la stăpânul meu. Iar pe mine, "
      },
      {
        "t": "DOMNUL",
        "w": "DOMNUL",
        "heb": "יְהוָה",
        "translit": "YHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κύριος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNUL."
      },
      {
        "t": " m-a "
      },
      {
        "t": "călăuzit",
        "w": "călăuzit",
        "heb": "נָחַנִי",
        "translit": "nachani",
        "strong": "H5148",
        "pos": "verb, cu sufix",
        "greek": "εὐόδωκέν με",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "m-a călăuzit."
      },
      {
        "t": " pe "
      },
      {
        "t": "drum",
        "w": "drum",
        "heb": "בַדֶּרֶךְ",
        "translit": "badarekh",
        "strong": "H1870",
        "pos": "substantiv, cu prefix",
        "greek": "εἰς τὸν οἶκον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "drum."
      },
      {
        "t": " spre "
      },
      {
        "t": "casa",
        "w": "casa",
        "heb": "בֵּית",
        "translit": "beit",
        "strong": "H1004",
        "pos": "substantiv, stare construită",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "casa."
      },
      {
        "t": " fraților stăpânului meu.”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיֹּאמֶר בָּרוּךְ יְהוָה אֱלֹהֵי אֲדֹנִי אַבְרָהָם אֲשֶׁר לֹא־עָזַב חַסְדּוֹ וַאֲמִתּוֹ מֵעִם אֲדֹנִי אָנֹכִי בַּדֶּרֶךְ נָחַנִי יְהוָה בֵּית אֲחֵי אֲדֹנִי",
        "translation": "„Și a spus: „Binecuvântat este DOMNUL, Dumnezeul stăpânului meu Avraham, care nu Și-a reținut bunăvoința și adevărul de la stăpânul meu. Iar pe mine, DOMNUL m-a călăuzit pe drum spre casa fraților stăpânului meu.”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ εἶπεν Εὐλογητὸς Κύριος ὁ θεὸς τοῦ κυρίου μου Αβρααμ, ὃς οὐκ ἐγκατέλιπεν τὴν δικαιοσύνην αὐτοῦ καὶ τὴν ἀλήθειαν ἀπὸ τοῦ κυρίου μου· ἐμὲ εὐόδωκεν Κύριος εἰς οἶκον τοῦ ἀδελφοῦ τοῦ κυρίου μου.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויאמר ברוך יהוה אלהי אדני אברהם אשר לא עזב חסדו ואמתו מעם אדני אברהם אנכי בדרך נחני יהוה בית אחי אדני",
        "translation": "Diferență reală, confirmată: ויאמר ברוך יהוה אלהי אדני אברהם אשר לא עזב חסדו ואמתו מעם אדני אברהם אנכי בדרך נחני יהוה בית אחי אדני — „And he said, Blessed [be] the LORD God of my master Abraham, who hath not left destitute my master Abraham of his mercy and his truth: I [being] in the way, the LORD led me to the house of my master's brethren.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Rut 2:20",
      "Geneza 32:10"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Formula „m-a călăuzit pe drum” e o mărturisire publică a providenței divine, nu o exprimare de noroc întâmplător."
      }
    ]
  },
  {
    "num": 28,
    "tokens": [
      {
        "t": "Fata",
        "w": "Fata",
        "heb": "הַנַּעֲרָ",
        "translit": "hana'ara",
        "strong": "H5291",
        "pos": "substantiv, cu articol",
        "greek": "ἡ παῖς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Fata."
      },
      {
        "t": " a "
      },
      {
        "t": "alergat",
        "w": "alergat",
        "heb": "וַתָּרָץ",
        "translit": "vatarats",
        "strong": "H7323",
        "pos": "verb",
        "greek": "δραμοῦσα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a alergat."
      },
      {
        "t": " și a "
      },
      {
        "t": "povestit",
        "w": "povestit",
        "heb": "וַתַּגֵּד",
        "translit": "vataged",
        "strong": "H5046",
        "pos": "verb",
        "greek": "ἀπήγγειλεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a povestit."
      },
      {
        "t": " [celor din] "
      },
      {
        "t": "casa",
        "w": "casa",
        "heb": "לְבֵית",
        "translit": "leveit",
        "strong": "H1004",
        "pos": "substantiv, stare construită",
        "greek": "εἰς τὸν οἶκον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "casa."
      },
      {
        "t": " mamei sale despre aceste "
      },
      {
        "t": "lucruri",
        "w": "lucruri",
        "heb": "כַּדְּבָרִים",
        "translit": "kadevarim",
        "strong": "H1697",
        "pos": "substantiv, cu prefix",
        "greek": "τὰ ῥήματα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "lucruri."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַתָּרָץ הַנַּעֲרָ וַתַּגֵּד לְבֵית אִמָּהּ כַּדְּבָרִים הָאֵלֶּה",
        "translation": "„Fata a alergat și a povestit [celor din] casa mamei sale despre aceste lucruri.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "Καὶ δραμοῦσα ἡ παῖς ἀπήγγειλεν εἰς τὸν οἶκον τῆς μητρὸς αὐτῆς κατὰ τὰ ῥήματα ταῦτα.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ותרץ הנערה ותגד לבית אמה כדברים האלה",
        "translation": "Diferență reală, confirmată: ותרץ הנערה ותגד לבית אמה כדברים האלה — „And the damsel ran, and told [them of] her mother's house these things.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:15"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Graba Rebecăi de a povesti acasă reflectă un entuziasm firesc după o întâlnire neobișnuită — cămile străine, daruri neașteptate, un om necunoscut."
      }
    ]
  },
  {
    "num": 29,
    "tokens": [
      {
        "t": "Iar "
      },
      {
        "t": "Rebeca",
        "w": "Rebeca",
        "heb": "וּלְרִבְקָה",
        "translit": "ulRivkah",
        "strong": "H7259",
        "pos": "nume propriu",
        "greek": "τῇ δὲ Ρεβεκκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Rebeca."
      },
      {
        "t": " avea un "
      },
      {
        "t": "frate",
        "w": "frate",
        "heb": "אָח",
        "translit": "ach",
        "strong": "H251",
        "pos": "substantiv",
        "greek": "ἀδελφὸς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "frate."
      },
      {
        "t": " al cărui "
      },
      {
        "t": "nume",
        "w": "nume",
        "heb": "וּשְׁמוֹ",
        "translit": "ushmo",
        "strong": "H8034",
        "pos": "substantiv cu sufix",
        "greek": "ᾧ ὄνομα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "numele."
      },
      {
        "t": " era "
      },
      {
        "t": "Lavan",
        "w": "Lavan",
        "heb": "לָבָן",
        "translit": "Lavan",
        "strong": "H3837",
        "pos": "nume propriu",
        "greek": "Λαβαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Lavan."
      },
      {
        "t": "; și "
      },
      {
        "t": "Lavan",
        "w": "Lavan",
        "heb": "לָבָן",
        "translit": "Lavan",
        "strong": "H3837",
        "pos": "nume propriu",
        "greek": "Λαβαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Lavan."
      },
      {
        "t": " a "
      },
      {
        "t": "alergat",
        "w": "alergat",
        "heb": "וַיָּרָץ",
        "translit": "vayarats",
        "strong": "H7323",
        "pos": "verb",
        "greek": "ἔδραμεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a alergat."
      },
      {
        "t": " la "
      },
      {
        "t": "om",
        "w": "om",
        "heb": "הָאִישׁ",
        "translit": "ha'ish",
        "strong": "H376",
        "pos": "substantiv, cu articol",
        "greek": "τὸν ἄνθρωπον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "om."
      },
      {
        "t": " afară, la "
      },
      {
        "t": "izvor",
        "w": "izvor",
        "heb": "הָעָיְנָה",
        "translit": "ha'aynah",
        "strong": "H5869",
        "pos": "substantiv, cu articol",
        "greek": "τὴν πηγήν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "izvor."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וּלְרִבְקָה אָח וּשְׁמוֹ לָבָן וַיָּרָץ לָבָן אֶל־הָאִישׁ הַחוּצָה אֶל־הָעָיִן",
        "translation": "„Iar Rebeca avea un frate al cărui nume era Lavan; și Lavan a alergat la om afară, la izvor.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "τῇ δὲ Ρεβεκκα ἀδελφὸς ἦν, ᾧ ὄνομα Λαβαν· καὶ ἔδραμεν Λαβαν πρὸς τὸν ἄνθρωπον ἔξω ἐπὶ τὴν πηγήν.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ולרבקה אח ושמו לבן וירץ לבן אל האיש החוצה אל העין",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 29:5",
      "Geneza 25:20"
    ],
    "commentaries": [
      {
        "author": "Rashi (1040–1105)",
        "text": "Întreabă retoric de ce a alergat Laban și pentru ce: „când a văzut inelul” — Laban și-a spus „omul acesta e bogat” și ochii i s-au aținit la avere, nu la ospitalitate dezinteresată."
      }
    ]
  },
  {
    "num": 30,
    "tokens": [
      {
        "t": "Și a fost, când a "
      },
      {
        "t": "văzut",
        "w": "văzut",
        "heb": "כִּרְאֹת",
        "translit": "kirot",
        "strong": "H7200",
        "pos": "verb (infinitiv)",
        "greek": "ἡνίκα εἶδεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a văzut."
      },
      {
        "t": " "
      },
      {
        "t": "inelul",
        "w": "inelul",
        "heb": "הַנֶּזֶם",
        "translit": "hanezem",
        "strong": "H5141",
        "pos": "substantiv, cu articol",
        "greek": "τὰ ἐνώτια",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "inelul."
      },
      {
        "t": " pentru "
      },
      {
        "t": "nas",
        "w": "nas",
        "heb": "",
        "translit": "",
        "strong": "",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "nas."
      },
      {
        "t": " și "
      },
      {
        "t": "brățările",
        "w": "brățările",
        "heb": "וְאֶת־הַצְּמִדִים",
        "translit": "ve'et hatsemidim",
        "strong": "H6781",
        "pos": "substantiv, cu articol",
        "greek": "τὰ ψέλια",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "brățările."
      },
      {
        "t": " pe "
      },
      {
        "t": "mâinile",
        "w": "mâinile",
        "heb": "יְדֵי",
        "translit": "yedei",
        "strong": "H3027",
        "pos": "substantiv, stare construită",
        "greek": "ταῖς χερσὶν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mâinile."
      },
      {
        "t": " surorii sale și când a "
      },
      {
        "t": "auzit",
        "w": "auzit",
        "heb": "וּכְשָׁמְעוֹ",
        "translit": "ukhesham'o",
        "strong": "H8085",
        "pos": "verb (infinitiv), cu sufix",
        "greek": "καὶ ὡς ἤκουσεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a auzit."
      },
      {
        "t": " "
      },
      {
        "t": "cuvintele",
        "w": "cuvintele",
        "heb": "דִּבְרֵי",
        "translit": "divrei",
        "strong": "H1697",
        "pos": "substantiv, stare construită",
        "greek": "τὰ ῥήματα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cuvintele."
      },
      {
        "t": " surorii sale "
      },
      {
        "t": "Rebeca",
        "w": "Rebeca",
        "heb": "רִבְקָה",
        "translit": "Rivkah",
        "strong": "H7259",
        "pos": "nume propriu",
        "greek": "Ρεβεκκας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Rebeca."
      },
      {
        "t": " spunând: „Așa mi-a "
      },
      {
        "t": "vorbit",
        "w": "vorbit",
        "heb": "דִּבֶּר",
        "translit": "diber",
        "strong": "H1696",
        "pos": "verb",
        "greek": "ἐλάλησεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mi-a vorbit."
      },
      {
        "t": " omul”, [Lavan] s-a "
      },
      {
        "t": "dus",
        "w": "dus",
        "heb": "וַיָּבֹא",
        "translit": "vayavo",
        "strong": "H935",
        "pos": "verb",
        "greek": "ἦλθεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "s-a dus."
      },
      {
        "t": " la "
      },
      {
        "t": "om",
        "w": "om",
        "heb": "הָאִישׁ",
        "translit": "ha'ish",
        "strong": "H376",
        "pos": "substantiv, cu articol",
        "greek": "τὸν ἄνθρωπον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "om."
      },
      {
        "t": " și iată, el "
      },
      {
        "t": "stătea",
        "w": "stătea",
        "heb": "עֹמֵד",
        "translit": "omed",
        "strong": "H5975",
        "pos": "verb, participiu",
        "greek": "εἱστήκει",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "stătea."
      },
      {
        "t": " lângă "
      },
      {
        "t": "cămile",
        "w": "cămile",
        "heb": "הַגְּמַלִּים",
        "translit": "hagemalim",
        "strong": "H1581",
        "pos": "substantiv, cu articol",
        "greek": "τῶν καμήλων",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămile."
      },
      {
        "t": ", lângă "
      },
      {
        "t": "izvor",
        "w": "izvor",
        "heb": "הָעָיִן",
        "translit": "ha'ayin",
        "strong": "H5869",
        "pos": "substantiv, cu articol",
        "greek": "τῆς πηγῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "izvor."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיְהִי כִּרְאֹת אֶת־הַנֶּזֶם וְאֶת־הַצְּמִדִים עַל־יְדֵי אֲחֹתוֹ וּכְשָׁמְעוֹ אֶת־דִּבְרֵי רִבְקָה אֲחֹתוֹ לֵאמֹר כֹּה־דִבֶּר אֵלַי הָאִישׁ וַיָּבֹא אֶל־הָאִישׁ וְהִנֵּה עֹמֵד עַל־הַגְּמַלִּים עַל־הָעָיִן",
        "translation": "„Și a fost, când a văzut inelul pentru nas și brățările pe mâinile surorii sale și când a auzit cuvintele surorii sale Rebeca spunând: „Așa mi-a vorbit omul”, [Lavan] s-a dus la om și iată, el stătea lângă cămile, lângă izvor.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἐγένετο ἡνίκα εἶδεν τὰ ἐνώτια καὶ τὰ ψέλια ἐπὶ τὰς χεῖρας τῆς ἀδελφῆς αὐτοῦ καὶ ὅτε ἤκουσεν τὰ ῥήματα Ρεβεκκας τῆς ἀδελφῆς αὐτοῦ λεγούσης Οὕτως λελάληκέν μοι ὁ ἄνθρωπος, καὶ ἦλθεν πρὸς τὸν ἄνθρωπον ἑστηκότος αὐτοῦ ἐπὶ τῶν καμήλων ἐπὶ τῆς πηγῆς",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויהי כראותו את הנזם ואת הצמידים על ידי אחותו וכשמעו את דברי רבקה אחותו לאמר כה דבר אלי האיש ויבא אל האיש והנה עמד על הגמלים על העין",
        "translation": "Diferență reală, confirmată: ויהי כראותו את הנזם ואת הצמידים על ידי אחותו וכשמעו את דברי רבקה אחותו לאמר כה דבר אלי האיש ויבא אל האיש והנה עמד על הגמלים על העין — „And it came to pass, when he saw the earring and bracelets upon his sister's hands, and when he heard the words of Rebekah his sister, saying, Thus spake the man unto me; that he came unto the man; and, behold, he stood by the camels at the well.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:22"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Motivația reală a grabei lui Laban — vederea bijuteriilor de aur — anticipează portretul său ulterior, constant marcat de interes material (vezi și v.29)."
      }
    ]
  },
  {
    "num": 31,
    "tokens": [
      {
        "t": "Și a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמֶר",
        "translit": "vayomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a spus."
      },
      {
        "t": ": „"
      },
      {
        "t": "Vino",
        "w": "Vino",
        "heb": "בּוֹא",
        "translit": "bo",
        "strong": "H935",
        "pos": "verb, imperativ",
        "greek": "Δεῦρο",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Vino."
      },
      {
        "t": ", "
      },
      {
        "t": "binecuvântatul",
        "w": "binecuvântatul",
        "heb": "בְּרוּךְ",
        "translit": "barukh",
        "strong": "H1288",
        "pos": "adjectiv, stare construită",
        "greek": "εὐλογητὸς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "binecuvântatul."
      },
      {
        "t": " "
      },
      {
        "t": "DOMNULUI",
        "w": "DOMNULUI",
        "heb": "יְהוָה",
        "translit": "YHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κυρίου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNULUI."
      },
      {
        "t": "! De ce să "
      },
      {
        "t": "stai",
        "w": "stai",
        "heb": "תַעֲמֹד",
        "translit": "ta'amod",
        "strong": "H5975",
        "pos": "verb",
        "greek": "ἕστηκας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să stai."
      },
      {
        "t": " afară, când eu am "
      },
      {
        "t": "pregătit",
        "w": "pregătit",
        "heb": "פִּנִּיתִי",
        "translit": "piniti",
        "strong": "H6437",
        "pos": "verb",
        "greek": "ἡτοίμασα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "am pregătit."
      },
      {
        "t": " "
      },
      {
        "t": "casa",
        "w": "casa",
        "heb": "הַבַּיִת",
        "translit": "habayit",
        "strong": "H1004",
        "pos": "substantiv, cu articol",
        "greek": "τὴν οἰκίαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "casa."
      },
      {
        "t": " și "
      },
      {
        "t": "loc",
        "w": "loc",
        "heb": "וּמָקוֹם",
        "translit": "umakom",
        "strong": "H4725",
        "pos": "substantiv",
        "greek": "τόπον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "loc."
      },
      {
        "t": " pentru "
      },
      {
        "t": "cămile",
        "w": "cămile",
        "heb": "לַגְּמַלִּים",
        "translit": "lagemalim",
        "strong": "H1581",
        "pos": "substantiv, cu prefix",
        "greek": "ταῖς καμήλοις",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămile."
      },
      {
        "t": "?”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיֹּאמֶר בּוֹא בְּרוּךְ יְהוָה לָמָּה תַעֲמֹד בַּחוּץ וְאָנֹכִי פִּנִּיתִי הַבַּיִת וּמָקוֹם לַגְּמַלִּים",
        "translation": "„Și a spus: „Vino, binecuvântatul DOMNULUI! De ce să stai afară, când eu am pregătit casa și loc pentru cămile?”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ εἶπεν αὐτῷ Δεῦρο εἴσελθε· εὐλογητὸς Κυρίου· ἵνα τί ἕστηκας ἔξω; ἐγὼ δὲ ἡτοίμακα τὴν οἰκίαν καὶ τόπον ταῖς καμήλοις.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויאמר בא ברוך יהוה למה תעמד בחוץ ואנכי פניתי הבית ומקום לגמלים",
        "translation": "Diferență reală, confirmată: ויאמר בא ברוך יהוה למה תעמד בחוץ ואנכי פניתי הבית ומקום לגמלים — „And he said, Come in, thou blessed of the LORD; wherefore standest thou without? for I have prepared the house, and room for the camels.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Formula „binecuvântatul DOMNULUI”, folosită de Laban, e teologic corectă chiar dacă motivația reală a ospitalității lui rămâne discutabilă."
      }
    ],
    "refs": [
      "Geneza 26:29"
    ]
  },
  {
    "num": 32,
    "tokens": [
      {
        "t": "Omul",
        "w": "Omul",
        "heb": "הָאִישׁ",
        "translit": "ha'ish",
        "strong": "H376",
        "pos": "substantiv, cu articol",
        "greek": "ὁ ἄνθρωπος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Omul."
      },
      {
        "t": " a "
      },
      {
        "t": "venit",
        "w": "venit",
        "heb": "וַיָּבֹא",
        "translit": "vayavo",
        "strong": "H935",
        "pos": "verb",
        "greek": "εἰσῆλθεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a venit."
      },
      {
        "t": " în "
      },
      {
        "t": "casă",
        "w": "casă",
        "heb": "הַבַּיְתָה",
        "translit": "habaytah",
        "strong": "H1004",
        "pos": "substantiv, cu articol",
        "greek": "τὴν οἰκίαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "casă."
      },
      {
        "t": " și a "
      },
      {
        "t": "deshămat",
        "w": "deshămat",
        "heb": "וַיְפַתַּח",
        "translit": "vayefatach",
        "strong": "H6605",
        "pos": "verb",
        "greek": "ἔλυσεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a deshămat."
      },
      {
        "t": " "
      },
      {
        "t": "cămilele",
        "w": "cămilele",
        "heb": "הַגְּמַלִּים",
        "translit": "hagemalim",
        "strong": "H1581",
        "pos": "substantiv, cu articol",
        "greek": "τὰς καμήλους",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămilele."
      },
      {
        "t": ", a "
      },
      {
        "t": "dat",
        "w": "dat",
        "heb": "וַיִּתֵּן",
        "translit": "vayiten",
        "strong": "H5414",
        "pos": "verb",
        "greek": "ἔδωκεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a dat."
      },
      {
        "t": " "
      },
      {
        "t": "fân",
        "w": "fân",
        "heb": "תֶּבֶן",
        "translit": "teven",
        "strong": "H8401",
        "pos": "substantiv",
        "greek": "ἄχυρα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "fân."
      },
      {
        "t": " și "
      },
      {
        "t": "nutreț",
        "w": "nutreț",
        "heb": "וּמִסְפּוֹא",
        "translit": "umispo",
        "strong": "H4554",
        "pos": "substantiv",
        "greek": "χορτάσματα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "nutreț."
      },
      {
        "t": " "
      },
      {
        "t": "cămilelor",
        "w": "cămilelor",
        "heb": "לַגְּמַלִּים",
        "translit": "lagemalim",
        "strong": "H1581",
        "pos": "substantiv, cu prefix",
        "greek": "ταῖς καμήλοις",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămilelor."
      },
      {
        "t": " și "
      },
      {
        "t": "apă",
        "w": "apă",
        "heb": "וּמַיִם",
        "translit": "umayim",
        "strong": "H4325",
        "pos": "substantiv",
        "greek": "ὕδωρ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "apă."
      },
      {
        "t": " să-și "
      },
      {
        "t": "spele",
        "w": "spele",
        "heb": "לִרְחֹץ",
        "translit": "lirchots",
        "strong": "H7364",
        "pos": "verb (infinitiv)",
        "greek": "νίψασθαι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să-și spele."
      },
      {
        "t": " "
      },
      {
        "t": "picioarele",
        "w": "picioarele",
        "heb": "רַגְלָיו",
        "translit": "raglav",
        "strong": "H7272",
        "pos": "substantiv cu sufix",
        "greek": "τοὺς πόδας αὐτοῦ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "picioarele lui."
      },
      {
        "t": " și "
      },
      {
        "t": "picioarele",
        "w": "picioarele",
        "heb": "רַגְלֵי",
        "translit": "raglei",
        "strong": "H7272",
        "pos": "substantiv, stare construită",
        "greek": "τοὺς πόδας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "picioarele."
      },
      {
        "t": " oamenilor care erau cu el."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיָּבֹא הָאִישׁ הַבַּיְתָה וַיְפַתַּח הַגְּמַלִּים וַיִּתֵּן תֶּבֶן וּמִסְפּוֹא לַגְּמַלִּים וּמַיִם לִרְחֹץ רַגְלָיו וְרַגְלֵי הָאֲנָשִׁים אֲשֶׁר אִתּוֹ",
        "translation": "„Omul a venit în casă și a deshămat cămilele, a dat fân și nutreț cămilelor și apă să-și spele picioarele și picioarele oamenilor care erau cu el.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "εἰσῆλθεν δὲ ὁ ἄνθρωπος εἰς τὴν οἰκίαν καὶ ἀπέσαξεν τὰς καμήλους καὶ ἔδωκεν ἄχυρα καὶ χορτάσματα ταῖς καμήλοις καὶ ὕδωρ νίψασθαι τοῖς ποσὶν αὐτοῦ καὶ τοῖς ποσὶν τῶν ἀνδρῶν τῶν μετ᾿ αὐτοῦ.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויבא האיש הביתה ויפתח הגמלים ויתן תבן ומספה לגמלים ומים לרחץ רגליו ורגלי האנשים אשר אתו",
        "translation": "Diferență reală, confirmată: ויבא האיש הביתה ויפתח הגמלים ויתן תבן ומספה לגמלים ומים לרחץ רגליו ורגלי האנשים אשר אתו — „And the man came into the house: and he ungirded his camels, and gave straw and provender for the camels, and water to wash his feet, and the men's feet that [were] with him.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "commentaries": [
      {
        "author": "Ramban / Nahmanide (1194–1270)",
        "text": "Clarifică cine face acțiunile din verset: subiectul se schimbă de la Eliezer la Laban — Laban e cel care deshamă cămilele și le dă apă, pentru că n-ar avea sens ca musafirul Eliezer să facă singur toată munca gazdei; Tora schimbă frecvent subiectul fără a-l repeta explicit, ca și în povestea vânzării lui Iosif. Notează și o interpretare alternativă a lui Rashi despre deshămare ca desfacere a botnițelor cămilelor."
      },
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Explică termenul „deshămate” prin paralelă cu 1 Regi 20:11 („cel ce-și încinge sabia să nu se laude ca cel ce-l dezleagă”) — cămilele purtau șei prinse cu curele, iar gestul descris e desfacerea acestor legături, nu neapărat a botnițelor."
      }
    ],
    "refs": [
      "Geneza 18:4"
    ]
  },
  {
    "num": 33,
    "tokens": [
      {
        "t": "I s-a "
      },
      {
        "t": "pus",
        "w": "pus",
        "heb": "וַיִּישֶׂם",
        "translit": "vayisem",
        "strong": "H7760",
        "pos": "verb (pasiv)",
        "greek": "παρέθηκεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i s-a pus."
      },
      {
        "t": " "
      },
      {
        "t": "mâncare",
        "w": "mâncare",
        "heb": "לֶאֱכֹל",
        "translit": "le'ekhol",
        "strong": "H398",
        "pos": "verb (infinitiv)",
        "greek": "φαγεῖν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mâncare."
      },
      {
        "t": " înainte, dar el a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמֶר",
        "translit": "vayomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a spus."
      },
      {
        "t": ": „Nu voi "
      },
      {
        "t": "mânca",
        "w": "mânca",
        "heb": "אֹכַל",
        "translit": "okhal",
        "strong": "H398",
        "pos": "verb",
        "greek": "φάγω",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "voi mânca."
      },
      {
        "t": " până ce nu-mi voi "
      },
      {
        "t": "vorbi",
        "w": "vorbi",
        "heb": "דִּבַּרְתִּי",
        "translit": "dibarti",
        "strong": "H1696",
        "pos": "verb",
        "greek": "λαλήσω",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "voi vorbi."
      },
      {
        "t": " "
      },
      {
        "t": "vorba",
        "w": "vorba",
        "heb": "דְּבָרַי",
        "translit": "devarai",
        "strong": "H1697",
        "pos": "substantiv cu sufix",
        "greek": "τὰ ῥήματά μου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "vorba mea."
      },
      {
        "t": ".” Și el i-a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמֶר",
        "translit": "vayomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-a spus."
      },
      {
        "t": ": „"
      },
      {
        "t": "Vorbește",
        "w": "Vorbește",
        "heb": "דַּבֵּר",
        "translit": "daber",
        "strong": "H1696",
        "pos": "verb, imperativ",
        "greek": "Λάλησον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Vorbește."
      },
      {
        "t": "!”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיִּישֶׂם לְפָנָיו לֶאֱכֹל וַיֹּאמֶר לֹא אֹכַל עַד אִם־דִּבַּרְתִּי דְּבָרָי וַיֹּאמֶר דַּבֵּר",
        "translation": "„I s-a pus mâncare înainte, dar el a spus: „Nu voi mânca până ce nu-mi voi vorbi vorba.” Și el i-a spus: „Vorbește!”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ παρέθηκεν αὐτοῖς ἄρτους φαγεῖν. καὶ εἶπεν Οὐ μὴ φάγω, ἕως τοῦ λαλῆσαί με τὰ ῥήματά μου. καὶ εἶπαν Λάλησον.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויושם לפניו לאכל ויאמר לא אכל עד אם דברתי דברי ויאמרו דבר",
        "translation": "Diferență reală, confirmată: ויושם לפניו לאכל ויאמר לא אכל עד אם דברתי דברי ויאמרו דבר — „And there was set [meat] before him to eat: but he said, I will not eat, until I have told mine errand. And they said, Speak on.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Ioan 4:34",
      "Iov 23:12"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Refuzul slujitorului de a mânca înainte de a-și termina misiunea arată o disciplină care pune sarcina înaintea nevoilor personale."
      }
    ]
  },
  {
    "num": 34,
    "tokens": [
      {
        "t": "Și a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמַר",
        "translit": "vayomar",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a spus."
      },
      {
        "t": ": „Sunt "
      },
      {
        "t": "slujitorul",
        "w": "slujitorul",
        "heb": "עֶבֶד",
        "translit": "eved",
        "strong": "H5650",
        "pos": "substantiv",
        "greek": "παῖς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "slujitorul."
      },
      {
        "t": " lui "
      },
      {
        "t": "Avraham",
        "w": "Avraham",
        "heb": "אַבְרָהָם",
        "translit": "Avraham",
        "strong": "H85",
        "pos": "nume propriu",
        "greek": "Αβρααμ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Avraham."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיֹּאמַר עֶבֶד אַבְרָהָם אָנֹכִי",
        "translation": "„Și a spus: „Sunt slujitorul lui Avraham.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "Καὶ εἶπεν Παῖς Αβρααμ ἐγώ εἰμι.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויאמר עבד אברהם אנכי",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Identificarea simplă — „sunt slujitorul lui Avraham” — fără menționarea propriului nume, subliniază rolul său de reprezentant, nu de persoană privată. [Notă: numele „Eliezer” nu apare nicăieri explicit în acest capitol; identificarea lui cu slujitorul din Geneza 15:2 e o tradiție interpretativă ulterioară, nu un fapt textual din capitolul 24 însuși.]"
      }
    ],
    "refs": [
      "Geneza 24:2"
    ]
  },
  {
    "num": 35,
    "tokens": [
      {
        "t": "DOMNUL",
        "w": "DOMNUL",
        "heb": "וַיהוָה",
        "translit": "vaYHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "ὁ δὲ Κύριος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNUL."
      },
      {
        "t": " l-a "
      },
      {
        "t": "binecuvântat",
        "w": "binecuvântat",
        "heb": "בֵּרַךְ",
        "translit": "berakh",
        "strong": "H1288",
        "pos": "verb",
        "greek": "εὐλόγησεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "l-a binecuvântat."
      },
      {
        "t": " mult pe stăpânul meu și el a "
      },
      {
        "t": "prosperat",
        "w": "prosperat",
        "heb": "וַיִּגְדָּל",
        "translit": "vayigdal",
        "strong": "H1431",
        "pos": "verb",
        "greek": "ηὐξήθη",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a prosperat."
      },
      {
        "t": "; i-a "
      },
      {
        "t": "dat",
        "w": "dat",
        "heb": "וַיִּתֶּן",
        "translit": "vayiten",
        "strong": "H5414",
        "pos": "verb",
        "greek": "ἔδωκεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-a dat."
      },
      {
        "t": " "
      },
      {
        "t": "turme",
        "w": "turme",
        "heb": "צֹאן",
        "translit": "tson",
        "strong": "H6629",
        "pos": "substantiv",
        "greek": "πρόβατα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "turme."
      },
      {
        "t": " și "
      },
      {
        "t": "cirezi",
        "w": "cirezi",
        "heb": "וּבָקָר",
        "translit": "uvakar",
        "strong": "H1241",
        "pos": "substantiv",
        "greek": "μόσχους",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cirezi."
      },
      {
        "t": ", "
      },
      {
        "t": "argint",
        "w": "argint",
        "heb": "וְכֶסֶף",
        "translit": "vekhesef",
        "strong": "H3701",
        "pos": "substantiv",
        "greek": "ἀργύριον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "argint."
      },
      {
        "t": " și "
      },
      {
        "t": "aur",
        "w": "aur",
        "heb": "וְזָהָב",
        "translit": "vezahav",
        "strong": "H2091",
        "pos": "substantiv",
        "greek": "χρυσίον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "aur."
      },
      {
        "t": ", "
      },
      {
        "t": "sclavi",
        "w": "sclavi",
        "heb": "וַעֲבָדִם",
        "translit": "va'avadim",
        "strong": "H5650",
        "pos": "substantiv",
        "greek": "παῖδας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "sclavi."
      },
      {
        "t": " și "
      },
      {
        "t": "slujnice",
        "w": "slujnice",
        "heb": "וּשְׁפָחֹת",
        "translit": "ushfachot",
        "strong": "H8198",
        "pos": "substantiv",
        "greek": "παιδίσκας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "slujnice."
      },
      {
        "t": ", "
      },
      {
        "t": "cămile",
        "w": "cămile",
        "heb": "וּגְמַלִּים",
        "translit": "ugemalim",
        "strong": "H1581",
        "pos": "substantiv",
        "greek": "καμήλους",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămile."
      },
      {
        "t": " și "
      },
      {
        "t": "măgari",
        "w": "măgari",
        "heb": "וַחֲמֹרִים",
        "translit": "vachamorim",
        "strong": "H2543",
        "pos": "substantiv",
        "greek": "ὄνους",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "măgari."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיהוָה בֵּרַךְ אֶת־אֲדֹנִי מְאֹד וַיִּגְדָּל וַיִּתֶּן־לוֹ צֹאן וּבָקָר וְכֶסֶף וְזָהָב וַעֲבָדִם וּשְׁפָחֹת וּגְמַלִּים וַחֲמֹרִים",
        "translation": "„DOMNUL l-a binecuvântat mult pe stăpânul meu și el a prosperat; i-a dat turme și cirezi, argint și aur, sclavi și slujnice, cămile și măgari.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "Κύριος δὲ εὐλόγησεν τὸν κύριόν μου σφόδρα, καὶ ὑψώθη· καὶ ἔδωκεν αὐτῷ πρόβατα καὶ μόσχους, ἀργύριον καὶ χρυσίον, παῖδας καὶ παιδίσκας, καμήλους καὶ ὄνους.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויהוה ברך את אדני מאד ויגדל ויתן לו צאן ובקר כסף וזהב עבדים ושפחות וגמלים וחמרים",
        "translation": "Diferență reală, confirmată: ויהוה ברך את אדני מאד ויגדל ויתן לו צאן ובקר כסף וזהב עבדים ושפחות וגמלים וחמרים — „And the LORD hath blessed my master greatly; and he is become great: and he hath given him flocks, and herds, and silver, and gold, and menservants, and maidservants, and camels, and asses.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 13:2"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Enumerarea completă a bogăției lui Avraham funcționează ca argument de credibilitate — o familie deja prosperă, nu una care caută avantaj material prin această alianță."
      }
    ]
  },
  {
    "num": 36,
    "tokens": [
      {
        "t": "Sara",
        "w": "Sara",
        "heb": "וַתֵּלֶד שָׂרָה",
        "translit": "vateled Sarah",
        "strong": "H8283",
        "pos": "nume propriu",
        "greek": "Σαρρα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Sara."
      },
      {
        "t": ", soția stăpânului meu, i-a "
      },
      {
        "t": "născut",
        "w": "născut",
        "heb": "",
        "translit": "",
        "strong": "",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-a născut."
      },
      {
        "t": " stăpânului meu un "
      },
      {
        "t": "fiu",
        "w": "fiu",
        "heb": "בֵּן",
        "translit": "ben",
        "strong": "H1121",
        "pos": "substantiv",
        "greek": "υἱὸν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "fiu."
      },
      {
        "t": " după ce a "
      },
      {
        "t": "îmbătrânit",
        "w": "îmbătrânit",
        "heb": "אַחֲרֵי זִקְנָתָהּ",
        "translit": "acharei ziknatah",
        "strong": "H2209",
        "pos": "substantiv cu sufix",
        "greek": "μετὰ τὸ γηρᾶσαι αὐτήν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a îmbătrânit."
      },
      {
        "t": " și el i-a "
      },
      {
        "t": "dat",
        "w": "dat",
        "heb": "וַיִּתֶּן",
        "translit": "vayiten",
        "strong": "H5414",
        "pos": "verb",
        "greek": "ἔδωκεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-a dat."
      },
      {
        "t": " tot ceea ce are."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַתֵּלֶד שָׂרָה אֵשֶׁת אֲדֹנִי בֵן לַאדֹנִי אַחֲרֵי זִקְנָתָהּ וַיִּתֶּן־לוֹ אֶת־כָּל־אֲשֶׁר־לוֹ",
        "translation": "„Sara, soția stăpânului meu, i-a născut stăpânului meu un fiu după ce a îmbătrânit și el i-a dat tot ceea ce are.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἔτεκεν Σαρρα ἡ γυνὴ τοῦ κυρίου μου υἱὸν ἕνα τῷ κυρίῳ μου μετὰ τὸ γηρᾶσαι αὐτόν, καὶ ἔδωκεν αὐτῷ ὅσα ἦν αὐτῷ.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ותלד שרה אשת אדני בן לאדני אחרי זקנתו ויתן לו את כל אשר לו",
        "translation": "Diferență reală, confirmată: ותלד שרה אשת אדני בן לאדני אחרי זקנתו ויתן לו את כל אשר לו — „And Sarah my master's wife bare a son to my master when she was old: and unto him hath he given all that he hath.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 21:2-3"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Menționarea nașterii miraculoase a lui Isaac (la bătrânețea părinților) e parte esențială a argumentului: nu un fiu oarecare, ci moștenitorul unic al unei promisiuni."
      }
    ]
  },
  {
    "num": 37,
    "tokens": [
      {
        "t": "Stăpânul",
        "w": "Stăpânul",
        "heb": "אֲדֹנִי",
        "translit": "adoni",
        "strong": "H113",
        "pos": "substantiv cu sufix",
        "greek": "ὁ κύριός μου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Stăpânul."
      },
      {
        "t": " meu m-a "
      },
      {
        "t": "pus",
        "w": "pus",
        "heb": "וַיַּשְׁבִּעֵנִי",
        "translit": "vayashbi'eni",
        "strong": "H7650",
        "pos": "verb, cu sufix",
        "greek": "ὥρκισέν με",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "m-a pus."
      },
      {
        "t": " să "
      },
      {
        "t": "jur",
        "w": "jur",
        "heb": "",
        "translit": "",
        "strong": "",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să jur."
      },
      {
        "t": ", spunând: «Să nu "
      },
      {
        "t": "iei",
        "w": "iei",
        "heb": "תִּקַּח",
        "translit": "tikach",
        "strong": "H3947",
        "pos": "verb",
        "greek": "λήμψῃ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să iei."
      },
      {
        "t": " "
      },
      {
        "t": "soție",
        "w": "soție",
        "heb": "אִשָּׁה",
        "translit": "ishah",
        "strong": "H802",
        "pos": "substantiv",
        "greek": "γυναῖκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "soție."
      },
      {
        "t": " pentru fiul meu din "
      },
      {
        "t": "fiicele",
        "w": "fiicele",
        "heb": "מִבְּנוֹת",
        "translit": "mibenot",
        "strong": "H1323",
        "pos": "substantiv, stare construită",
        "greek": "ἀπὸ τῶν θυγατέρων",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "fiicele."
      },
      {
        "t": " "
      },
      {
        "t": "canaaniților",
        "w": "canaaniților",
        "heb": "הַכְּנַעֲנִי",
        "translit": "hakena'ani",
        "strong": "H3669",
        "pos": "nume propriu, popor, cu articol",
        "greek": "τῶν Χαναναίων",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "canaaniților."
      },
      {
        "t": ", în "
      },
      {
        "t": "țara",
        "w": "țara",
        "heb": "אַרְצוֹ",
        "translit": "artso",
        "strong": "H776",
        "pos": "substantiv cu sufix",
        "greek": "τῇ γῇ αὐτῶν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "țara."
      },
      {
        "t": " cărora "
      },
      {
        "t": "locuiesc",
        "w": "locuiesc",
        "heb": "יֹשֵׁב",
        "translit": "yoshev",
        "strong": "H3427",
        "pos": "verb, participiu",
        "greek": "κατοικῶ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "locuiesc."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיַּשְׁבִּעֵנִי אֲדֹנִי לֵאמֹר לֹא־תִקַּח אִשָּׁה לִבְנִי מִבְּנוֹת הַכְּנַעֲנִי אֲשֶׁר אָנֹכִי יֹשֵׁב בְּאַרְצוֹ",
        "translation": "„Stăpânul meu m-a pus să jur, spunând: «Să nu iei soție pentru fiul meu din fiicele canaaniților, în țara cărora locuiesc.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ὥρκισέν με ὁ κύριός μου λέγων Οὐ λήμψῃ γυναῖκα τῷ υἱῷ μου ἀπὸ τῶν θυγατέρων τῶν Χαναναίων, ἐν οἷς ἐγὼ παροικῶ ἐν τῇ γῇ αὐτῶν,",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "וישבעני אדני לאמר לא תקח אשה לבני מבנות הכנעני אשר אנכי ישב בארצו",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:3"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Repetarea aproape identică a jurământului inițial arată acuratețea cu care slujitorul transmite cuvintele exacte ale lui Avraham."
      }
    ]
  },
  {
    "num": 38,
    "tokens": [
      {
        "t": "Ci să "
      },
      {
        "t": "mergi",
        "w": "mergi",
        "heb": "תֵּלֵךְ",
        "translit": "teilekh",
        "strong": "H1980",
        "pos": "verb",
        "greek": "πορεύσῃ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să mergi."
      },
      {
        "t": " la "
      },
      {
        "t": "casa",
        "w": "casa",
        "heb": "בֵית",
        "translit": "veit",
        "strong": "H1004",
        "pos": "substantiv, stare construită",
        "greek": "τὸν οἶκον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "casa."
      },
      {
        "t": " tatălui meu și la "
      },
      {
        "t": "familia",
        "w": "familia",
        "heb": "מִשְׁפַּחְתִּי",
        "translit": "mishpachti",
        "strong": "H4940",
        "pos": "substantiv cu sufix",
        "greek": "τὴν φυλήν μου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "familia mea."
      },
      {
        "t": " mea și să "
      },
      {
        "t": "iei",
        "w": "iei",
        "heb": "וְלָקַחְתָּ",
        "translit": "velakachta",
        "strong": "H3947",
        "pos": "verb",
        "greek": "λήμψῃ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să iei."
      },
      {
        "t": " o "
      },
      {
        "t": "soție",
        "w": "soție",
        "heb": "אִשָּׁה",
        "translit": "ishah",
        "strong": "H802",
        "pos": "substantiv",
        "greek": "γυναῖκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "soție."
      },
      {
        "t": " pentru fiul meu.»"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "אִם־לֹא אֶל־בֵּית־אָבִי תֵּלֵךְ וְאֶל־מִשְׁפַּחְתִּי וְלָקַחְתָּ אִשָּׁה לִבְנִי",
        "translation": "„Ci să mergi la casa tatălui meu și la familia mea și să iei o soție pentru fiul meu.»” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "ἀλλ᾿ ἢ εἰς τὸν οἶκον τοῦ πατρός μου πορεύσῃ καὶ εἰς τὴν φυλήν μου καὶ λήμψῃ γυναῖκα τῷ υἱῷ μου ἐκεῖθεν.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "כי אם אל בית אבי תלך ואל משפחתי ולקחת אשה לבני",
        "translation": "Diferență reală, confirmată: כי אם אל בית אבי תלך ואל משפחתי ולקחת אשה לבני — „But thou shalt go unto my father's house, and to my kindred, and take a wife unto my son.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:4"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Precizia repetării — familia și casa tatălui, exact ca în porunca originală — nu lasă loc de abatere de la instrucțiuni."
      }
    ]
  },
  {
    "num": 39,
    "tokens": [
      {
        "t": "Eu i-am "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וָאֹמַר",
        "translit": "va'omar",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-am spus."
      },
      {
        "t": " stăpânului meu: «Poate "
      },
      {
        "t": "femeia",
        "w": "femeia",
        "heb": "הָאִשָּׁה",
        "translit": "ha'ishah",
        "strong": "H802",
        "pos": "substantiv, cu articol",
        "greek": "ἡ γυνή",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "femeia."
      },
      {
        "t": " nu va "
      },
      {
        "t": "merge",
        "w": "merge",
        "heb": "תֵלֵךְ",
        "translit": "telekh",
        "strong": "H1980",
        "pos": "verb",
        "greek": "πορεύσεται",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "va merge."
      },
      {
        "t": " după mine.»"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וָאֹמַר אֶל־אֲדֹנִי אֻלַי לֹא־תֵלֵךְ הָאִשָּׁה אַחֲרָי",
        "translation": "„Eu i-am spus stăpânului meu: «Poate femeia nu va merge după mine.»” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "εἶπα δὲ τῷ κυρίῳ μου Μήποτε οὐ πορεύσεται ἡ γυνὴ μετ᾿ ἐμοῦ.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ואמר אל אדני אולי לא תלך האשה אחרי",
        "translation": "Diferență reală, confirmată: ואמר אל אדני אולי לא תלך האשה אחרי — „And I said unto my master, Peradventure the woman will not follow me.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:5"
    ],
    "commentaries": [
      {
        "author": "Rashi (1040–1105)",
        "text": "Discută grafia cuvântului „poate” (אֻלַי), care poate fi citită și „la mine” (אֵלַי): Rashi relatează o tradiție conform căreia Eliezer avea o fiică proprie și căuta un pretext ca Avraham să-i sugereze lui să i-o dea de soție lui Isaac. Răspunsul lui Avraham a fost tranșant: „fiul meu e binecuvântat, iar tu ești blestemat” (Eliezer fiind urmaș al lui Canaan, cel blestemat de Noe) — „iar cel blestemat nu se poate uni cu cel binecuvântat”."
      }
    ]
  },
  {
    "num": 40,
    "tokens": [
      {
        "t": "El mi-a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמֶר",
        "translit": "vayomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mi-a spus."
      },
      {
        "t": ": «"
      },
      {
        "t": "DOMNUL",
        "w": "DOMNUL",
        "heb": "יְהוָה",
        "translit": "YHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κύριος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNUL."
      },
      {
        "t": ", înaintea Căruia am "
      },
      {
        "t": "mers",
        "w": "mers",
        "heb": "הִתְהַלַּכְתִּי",
        "translit": "hithalakhti",
        "strong": "H1980",
        "pos": "verb",
        "greek": "εὐηρέστησα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "am mers."
      },
      {
        "t": ", va "
      },
      {
        "t": "trimite",
        "w": "trimite",
        "heb": "יִשְׁלַח",
        "translit": "yishlach",
        "strong": "H7971",
        "pos": "verb",
        "greek": "ἀποστελεῖ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "va trimite."
      },
      {
        "t": " pe "
      },
      {
        "t": "îngerul",
        "w": "îngerul",
        "heb": "מַלְאָכוֹ",
        "translit": "mal'akho",
        "strong": "H4397",
        "pos": "substantiv cu sufix",
        "greek": "τὸν ἄγγελον αὐτοῦ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "îngerul lui."
      },
      {
        "t": " Său cu tine și te va face să "
      },
      {
        "t": "reușești",
        "w": "reușești",
        "heb": "וְהִצְלִיחַ",
        "translit": "vehitsliach",
        "strong": "H6743",
        "pos": "verb",
        "greek": "εὐοδώσει",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să reușești."
      },
      {
        "t": " pe "
      },
      {
        "t": "drumul",
        "w": "drumul",
        "heb": "דַּרְכֶּךָ",
        "translit": "darkekha",
        "strong": "H1870",
        "pos": "substantiv cu sufix",
        "greek": "τὴν ὁδόν σου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "drumul tău."
      },
      {
        "t": " tău și vei "
      },
      {
        "t": "lua",
        "w": "lua",
        "heb": "וְלָקַחְתָּ",
        "translit": "velakachta",
        "strong": "H3947",
        "pos": "verb",
        "greek": "λήμψῃ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "vei lua."
      },
      {
        "t": " "
      },
      {
        "t": "soție",
        "w": "soție",
        "heb": "אִשָּׁה",
        "translit": "ishah",
        "strong": "H802",
        "pos": "substantiv",
        "greek": "γυναῖκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "soție."
      },
      {
        "t": " pentru fiul meu din "
      },
      {
        "t": "familia",
        "w": "familia",
        "heb": "מִמִּשְׁפַּחְתִּי",
        "translit": "mimishpachti",
        "strong": "H4940",
        "pos": "substantiv cu sufix",
        "greek": "ἐκ τῆς φυλῆς μου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "familia mea."
      },
      {
        "t": " mea și din "
      },
      {
        "t": "casa",
        "w": "casa",
        "heb": "וּמִבֵּית",
        "translit": "umibeit",
        "strong": "H1004",
        "pos": "substantiv, stare construită",
        "greek": "ἐκ τοῦ οἴκου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "casa."
      },
      {
        "t": " tatălui meu."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיֹּאמֶר אֵלָי יְהוָה אֲשֶׁר־הִתְהַלַּכְתִּי לְפָנָיו יִשְׁלַח מַלְאָכוֹ אִתָּךְ וְהִצְלִיחַ דַּרְכֶּךָ וְלָקַחְתָּ אִשָּׁה לִבְנִי מִמִּשְׁפַּחְתִּי וּמִבֵּית אָבִי",
        "translation": "„El mi-a spus: «DOMNUL, înaintea Căruia am mers, va trimite pe îngerul Său cu tine și te va face să reușești pe drumul tău și vei lua soție pentru fiul meu din familia mea și din casa tatălui meu.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ εἶπέν μοι Κύριος, ᾧ εὐηρέστησα ἐναντίον αὐτοῦ, αὐτὸς ἀποστελεῖ τὸν ἄγγελον αὐτοῦ μετὰ σοῦ καὶ εὐοδώσει τὴν ὁδόν σου, καὶ λήμψῃ γυναῖκα τῷ υἱῷ μου ἐκ τῆς φυλῆς μου καὶ ἐκ τοῦ οἴκου τοῦ πατρός μου.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויאמר אלי יהוה אשר התהלכתי לפניו ישלח מלאכו אתך והצליח דרכך ולקחת אשה לבני ממשפחתי ומבית אבי",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:7",
      "Geneza 17:1"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Repetarea promisiunii îngerului confirmă narativ împlinirea exactă a ceea ce fusese promis, verificabilă acum de toți ascultătorii."
      }
    ]
  },
  {
    "num": 41,
    "tokens": [
      {
        "t": "Atunci vei fi "
      },
      {
        "t": "dezlegat",
        "w": "dezlegat",
        "heb": "תִּנָּקֶה",
        "translit": "tinakeh",
        "strong": "H5352",
        "pos": "verb",
        "greek": "ἀθῷος ἔσῃ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "vei fi dezlegat."
      },
      {
        "t": " de "
      },
      {
        "t": "imprecația",
        "w": "imprecația",
        "heb": "מֵאָלָתִי",
        "translit": "me'alati",
        "strong": "H423",
        "pos": "substantiv cu sufix",
        "greek": "τῆς ἀρᾶς μου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "imprecația mea."
      },
      {
        "t": " mea, când vei "
      },
      {
        "t": "ajunge",
        "w": "ajunge",
        "heb": "תָבוֹא",
        "translit": "tavo",
        "strong": "H935",
        "pos": "verb",
        "greek": "ἔλθῃς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "vei ajunge."
      },
      {
        "t": " la "
      },
      {
        "t": "familia",
        "w": "familia",
        "heb": "מִשְׁפַּחְתִּי",
        "translit": "mishpachti",
        "strong": "H4940",
        "pos": "substantiv cu sufix",
        "greek": "τὴν φυλήν μου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "familia mea."
      },
      {
        "t": " mea; iar dacă nu ți-o vor "
      },
      {
        "t": "da",
        "w": "da",
        "heb": "יִתְּנוּ",
        "translit": "yitnu",
        "strong": "H5414",
        "pos": "verb",
        "greek": "δῶσίν σοι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "vor da."
      },
      {
        "t": ", vei fi "
      },
      {
        "t": "dezlegat",
        "w": "dezlegat",
        "heb": "וְהָיִיתָ נָקִי",
        "translit": "vehayita naki",
        "strong": "H5355",
        "pos": "adjectiv",
        "greek": "ἀθῷος ἔσῃ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "vei fi dezlegat."
      },
      {
        "t": " de "
      },
      {
        "t": "imprecația",
        "w": "imprecația",
        "heb": "מֵאָלָתִי",
        "translit": "me'alati",
        "strong": "H423",
        "pos": "substantiv cu sufix",
        "greek": "τοῦ ὁρκισμοῦ μου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "imprecația mea."
      },
      {
        "t": " mea.»"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "אָז תִּנָּקֶה מֵאָלָתִי כִּי תָבוֹא אֶל־מִשְׁפַּחְתִּי וְאִם־לֹא יִתְּנוּ לָךְ וְהָיִיתָ נָקִי מֵאָלָתִי",
        "translation": "„Atunci vei fi dezlegat de imprecația mea, când vei ajunge la familia mea; iar dacă nu ți-o vor da, vei fi dezlegat de imprecația mea.»” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "τότε ἀθῷος ἔσῃ ἀπὸ τῆς ἀρᾶς μου· ἡνίκα γὰρ ἐὰν ἔλθῃς εἰς τὴν ἐμὴν φυλὴν καὶ μή σοι δῶσιν, καὶ ἔσῃ ἀθῷος ἀπὸ τοῦ ὁρκισμοῦ μου.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "אז תנקיא מאלתי כי תבוא אל משפחתי ואם לא יתנו לך והיית נקיא מאלתי",
        "translation": "Diferență reală, confirmată: אז תנקיא מאלתי כי תבוא אל משפחתי ואם לא יתנו לך והיית נקיא מאלתי — „Then shalt thou be clear from [this] my oath, when thou comest to my kindred; and if they give not thee [one], thou shalt be clear from my oath.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:8"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Clauza de eliberare de jurământ e repetată integral — transparență completă asupra condițiilor față de familia Rebecăi, fără nimic ascuns."
      }
    ]
  },
  {
    "num": 42,
    "tokens": [
      {
        "t": "Am "
      },
      {
        "t": "venit",
        "w": "venit",
        "heb": "וָאָבֹא",
        "translit": "va'avo",
        "strong": "H935",
        "pos": "verb",
        "greek": "παραγενόμενος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Am venit."
      },
      {
        "t": " astăzi la "
      },
      {
        "t": "izvor",
        "w": "izvor",
        "heb": "הָעַיִן",
        "translit": "ha'ayin",
        "strong": "H5869",
        "pos": "substantiv, cu articol",
        "greek": "τὴν πηγήν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "izvor."
      },
      {
        "t": " și am "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וָאֹמַר",
        "translit": "va'omar",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "am spus."
      },
      {
        "t": ": «"
      },
      {
        "t": "DOAMNE",
        "w": "DOAMNE",
        "heb": "יְהוָה",
        "translit": "YHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κύριε",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOAMNE."
      },
      {
        "t": ", "
      },
      {
        "t": "Dumnezeul",
        "w": "Dumnezeul",
        "heb": "אֱלֹהֵי",
        "translit": "Elohei",
        "strong": "H430",
        "pos": "substantiv, stare construită",
        "greek": "ὁ Θεὸς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Dumnezeul."
      },
      {
        "t": " stăpânului meu "
      },
      {
        "t": "Avraham",
        "w": "Avraham",
        "heb": "אֲדֹנִי אַבְרָהָם",
        "translit": "adoni Avraham",
        "strong": "H85",
        "pos": "nume propriu",
        "greek": "τοῦ κυρίου μου Αβρααμ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Avraham."
      },
      {
        "t": ", dacă vei [binevoi] să-mi "
      },
      {
        "t": "dai",
        "w": "dai",
        "heb": "מַצְלִיחַ",
        "translit": "matsliach",
        "strong": "H6743",
        "pos": "verb, participiu",
        "greek": "εὐοδοῖς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "dai."
      },
      {
        "t": " "
      },
      {
        "t": "izbândă",
        "w": "izbândă",
        "heb": "",
        "translit": "",
        "strong": "",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "izbândă."
      },
      {
        "t": " pe "
      },
      {
        "t": "drumul",
        "w": "drumul",
        "heb": "דַּרְכִּי",
        "translit": "darki",
        "strong": "H1870",
        "pos": "substantiv cu sufix",
        "greek": "τὴν ὁδόν μου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "drumul meu."
      },
      {
        "t": " pe care merg:"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וָאָבֹא הַיּוֹם אֶל־הָעָיִן וָאֹמַר יְהוָה אֱלֹהֵי אֲדֹנִי אַבְרָהָם אִם־יֶשְׁךָ־נָּא מַצְלִיחַ דַּרְכִּי אֲשֶׁר אָנֹכִי הֹלֵךְ עָלֶיהָ",
        "translation": "„Am venit astăzi la izvor și am spus: «DOAMNE, Dumnezeul stăpânului meu Avraham, dacă vei [binevoi] să-mi dai izbândă pe drumul pe care merg:” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἐλθὼν σήμερον ἐπὶ τὴν πηγὴν εἶπα Κύριε ὁ θεὸς τοῦ κυρίου μου Αβρααμ, εἰ σὺ εὐοδοῖς τὴν ὁδόν μου, ἣν νῦν ἐγὼ πορεύομαι ἐπ᾿ αὐτήν,",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ואבוא היום אל העין ואמר יהוה אלהי אדני אברהם אם ישך נא מצליח דרכי אשר אני הלך עליה",
        "translation": "Diferență reală, confirmată: ואבוא היום אל העין ואמר יהוה אלהי אדני אברהם אם ישך נא מצליח דרכי אשר אני הלך עליה — „And I came this day unto the well, and said, O LORD God of my master Abraham, if now thou do prosper my way which I go:”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:12"
    ],
    "commentaries": [
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Observă că întreaga expunere amănunțită a slujitorului în fața familiei avea un scop precis: să-i convingă că „lucrul a fost hotărât de Domnul” (v.50), nu doar să povestească întâmplarea."
      }
    ]
  },
  {
    "num": 43,
    "tokens": [
      {
        "t": "iată, eu "
      },
      {
        "t": "stau",
        "w": "stau",
        "heb": "נִצָּב",
        "translit": "nitsav",
        "strong": "H5324",
        "pos": "verb, participiu",
        "greek": "ἕστηκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "stau."
      },
      {
        "t": " lângă "
      },
      {
        "t": "izvorul",
        "w": "izvorul",
        "heb": "עֵין",
        "translit": "ein",
        "strong": "H5869",
        "pos": "substantiv, stare construită",
        "greek": "τῆς πηγῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "izvorul."
      },
      {
        "t": " de "
      },
      {
        "t": "apă",
        "w": "apă",
        "heb": "הַמָּיִם",
        "translit": "hamayim",
        "strong": "H4325",
        "pos": "substantiv, cu articol",
        "greek": "τοῦ ὕδατος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "apă."
      },
      {
        "t": "; fie ca "
      },
      {
        "t": "tânăra",
        "w": "tânăra",
        "heb": "הָעַלְמָה",
        "translit": "ha'almah",
        "strong": "H5959",
        "pos": "substantiv, cu articol",
        "greek": "ἡ παρθένος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "tânăra."
      },
      {
        "t": " care va "
      },
      {
        "t": "ieși",
        "w": "ieși",
        "heb": "הַיֹּצֵאת",
        "translit": "hayotset",
        "strong": "H3318",
        "pos": "verb, participiu, cu articol",
        "greek": "ἐκπορευομένη",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "va ieși."
      },
      {
        "t": " să "
      },
      {
        "t": "scoată",
        "w": "scoată",
        "heb": "לִשְׁאֹב",
        "translit": "lish'ov",
        "strong": "H7579",
        "pos": "verb (infinitiv)",
        "greek": "ὑδρεύσασθαι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să scoată."
      },
      {
        "t": " apă și căreia îi voi "
      },
      {
        "t": "spune",
        "w": "spune",
        "heb": "וְאָמַרְתִּי",
        "translit": "ve'amarti",
        "strong": "H559",
        "pos": "verb",
        "greek": "ἐρῶ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "voi spune."
      },
      {
        "t": ": ‘"
      },
      {
        "t": "Dă-mi",
        "w": "Dă-mi",
        "heb": "הַשְׁקִינִי",
        "translit": "hashkini",
        "strong": "H8248",
        "pos": "verb, imperativ, cu sufix",
        "greek": "Πότισόν με",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Dă-mi."
      },
      {
        "t": ", te rog, să "
      },
      {
        "t": "beau",
        "w": "beau",
        "heb": "נָא",
        "translit": "na",
        "strong": "H4994",
        "pos": "particulă",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să beau."
      },
      {
        "t": " puțină "
      },
      {
        "t": "apă",
        "w": "apă",
        "heb": "מַיִם",
        "translit": "mayim",
        "strong": "H4325",
        "pos": "substantiv",
        "greek": "ὕδωρ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "apă."
      },
      {
        "t": " din "
      },
      {
        "t": "ulciorul",
        "w": "ulciorul",
        "heb": "מִכַּדֵּךְ",
        "translit": "mikadekh",
        "strong": "H3537",
        "pos": "substantiv cu sufix",
        "greek": "ἐκ τῆς ὑδρίας σου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ulciorul tău."
      },
      {
        "t": " tău’,"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "הִנֵּה אָנֹכִי נִצָּב עַל־עֵין הַמָּיִם וְהָיָה הָעַלְמָה הַיֹּצֵאת לִשְׁאֹב וְאָמַרְתִּי אֵלֶיהָ הַשְׁקִינִי־נָא מְעַט־מַיִם מִכַּדֵּךְ",
        "translation": "„iată, eu stau lângă izvorul de apă; fie ca tânăra care va ieși să scoată apă și căreia îi voi spune: ‘Dă-mi, te rog, să beau puțină apă din ulciorul tău’,” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "ἰδοὺ ἐγὼ ἐφέστηκα ἐπὶ τῆς πηγῆς τοῦ ὕδατος, καὶ αἱ θυγατέρες τῶν ἀνθρώπων τῆς πόλεως ἐξελεύσονται ὑδρεύσασθαι ὕδωρ, καὶ ἔσται ἡ παρθένος, ᾗ ἂν ἐγὼ εἴπω Πότισόν με μικρὸν ὕδωρ ἐκ τῆς ὑδρίας σου,",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "הנה אנכי נצב על עין המים והיה העלמה היצאת לשאב ואמרתי אליה השקיני נא מעט מים מכדך",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:13"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Se remarcă o schimbare de termen între rugăciunea inițială și repetarea ei — de la „tânără” (na'ara) la „fecioară” (alma) — variație stilistică observată de comentatorii clasici, fără explicație unanimă."
      }
    ]
  },
  {
    "num": 44,
    "tokens": [
      {
        "t": "și care îmi va "
      },
      {
        "t": "spune",
        "w": "spune",
        "heb": "וְאָמְרָה",
        "translit": "ve'amerah",
        "strong": "H559",
        "pos": "verb",
        "greek": "ἐρεῖ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "va spune."
      },
      {
        "t": ": ‘"
      },
      {
        "t": "Bea",
        "w": "Bea",
        "heb": "שְׁתֵה",
        "translit": "shteh",
        "strong": "H8354",
        "pos": "verb, imperativ",
        "greek": "Πίε",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Bea."
      },
      {
        "t": " și tu și voi "
      },
      {
        "t": "scoate",
        "w": "scoate",
        "heb": "אֶשְׁאָב",
        "translit": "esh'av",
        "strong": "H7579",
        "pos": "verb",
        "greek": "ἀντλήσω",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "voi scoate."
      },
      {
        "t": " apă și "
      },
      {
        "t": "cămilelor",
        "w": "cămilelor",
        "heb": "וְלִגְמַלֶּיךָ",
        "translit": "veligemalekha",
        "strong": "H1581",
        "pos": "substantiv cu sufix",
        "greek": "ταῖς καμήλοις σου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămilelor tale."
      },
      {
        "t": " tale’ – aceea să fie "
      },
      {
        "t": "soția",
        "w": "soția",
        "heb": "הָאִשָּׁה",
        "translit": "ha'ishah",
        "strong": "H802",
        "pos": "substantiv, cu articol",
        "greek": "γυναῖκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "soția."
      },
      {
        "t": " pe care a "
      },
      {
        "t": "hotărât-o",
        "w": "hotărât-o",
        "heb": "הֹכִיחַ",
        "translit": "hokhiach",
        "strong": "H3198",
        "pos": "verb",
        "greek": "ἡτοίμασεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a hotărât-o."
      },
      {
        "t": " "
      },
      {
        "t": "DOMNUL",
        "w": "DOMNUL",
        "heb": "יְהוָה",
        "translit": "YHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κύριος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNUL."
      },
      {
        "t": " pentru fiul stăpânului meu.»"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וְאָמְרָה אֵלַי גַּם־אַתָּה שְׁתֵה וְגַם לִגְמַלֶּיךָ אֶשְׁאָב הִוא הָאִשָּׁה אֲשֶׁר־הֹכִיחַ יְהוָה לְבֶן־אֲדֹנִי",
        "translation": "„și care îmi va spune: ‘Bea și tu și voi scoate apă și cămilelor tale’ – aceea să fie soția pe care a hotărât-o DOMNUL pentru fiul stăpânului meu.»” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ εἴπῃ μοι Καὶ σὺ πίε, καὶ ταῖς καμήλοις σου ὑδρεύσομαι, αὕτη ἡ γυνή, ἣν ἡτοίμασεν Κύριος τῷ ἑαυτοῦ θεράποντι Ισαακ, καὶ ἐν τούτῳ γνώσομαι ὅτι πεποίηκας ἔλεος τῷ κυρίῳ μου Αβρααμ.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ואמרה אלי גם אתה שתה וגם לגמליך אשאב היא האשה אשר הוכיח יהוה לבן אדני",
        "translation": "Diferență reală, confirmată: ואמרה אלי גם אתה שתה וגם לגמליך אשאב היא האשה אשר הוכיח יהוה לבן אדני — „And she say to me, Both drink thou, and I will also draw for thy camels: [let] the same [be] the woman whom the LORD hath appointed out for my master's son.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:14"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Repetarea condiției exacte a semnului cerut arată consecvență completă între rugăciune și relatarea ei ulterioară."
      }
    ]
  },
  {
    "num": 45,
    "tokens": [
      {
        "t": "Nici nu "
      },
      {
        "t": "terminasem",
        "w": "terminasem",
        "heb": "כִּלֵּיתִי",
        "translit": "kileti",
        "strong": "H3615",
        "pos": "verb",
        "greek": "συνετέλεσα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "terminasem."
      },
      {
        "t": " de "
      },
      {
        "t": "vorbit",
        "w": "vorbit",
        "heb": "לְדַבֵּר",
        "translit": "ledaber",
        "strong": "H1696",
        "pos": "verb (infinitiv)",
        "greek": "λαλῶν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "de vorbit."
      },
      {
        "t": " în "
      },
      {
        "t": "sinea",
        "w": "sinea",
        "heb": "",
        "translit": "",
        "strong": "",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "sinea."
      },
      {
        "t": " mea că iată, "
      },
      {
        "t": "Rebeca",
        "w": "Rebeca",
        "heb": "רִבְקָה",
        "translit": "Rivkah",
        "strong": "H7259",
        "pos": "nume propriu",
        "greek": "Ρεβεκκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Rebeca."
      },
      {
        "t": " a "
      },
      {
        "t": "ieșit",
        "w": "ieșit",
        "heb": "יֹצֵאת",
        "translit": "yotset",
        "strong": "H3318",
        "pos": "verb, participiu",
        "greek": "ἐξεπορεύετο",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a ieșit."
      },
      {
        "t": " cu "
      },
      {
        "t": "ulciorul",
        "w": "ulciorul",
        "heb": "וְכַדָּהּ",
        "translit": "vekhadah",
        "strong": "H3537",
        "pos": "substantiv cu sufix",
        "greek": "ἡ ὑδρία",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ulciorul."
      },
      {
        "t": " pe "
      },
      {
        "t": "umăr",
        "w": "umăr",
        "heb": "שִׁכְמָהּ",
        "translit": "shikhmah",
        "strong": "H7926",
        "pos": "substantiv cu sufix",
        "greek": "τὸν ὦμον αὐτῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "umărul ei."
      },
      {
        "t": " și a "
      },
      {
        "t": "coborât",
        "w": "coborât",
        "heb": "וַתֵּרֶד",
        "translit": "vatered",
        "strong": "H3381",
        "pos": "verb",
        "greek": "κατέβη",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a coborât."
      },
      {
        "t": " către "
      },
      {
        "t": "izvor",
        "w": "izvor",
        "heb": "הָעַיְנָה",
        "translit": "ha'aynah",
        "strong": "H5869",
        "pos": "substantiv, cu articol",
        "greek": "τὴν πηγὴν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "izvor."
      },
      {
        "t": " și a "
      },
      {
        "t": "scos",
        "w": "scos",
        "heb": "וַתִּשְׁאָב",
        "translit": "vatish'av",
        "strong": "H7579",
        "pos": "verb",
        "greek": "ὑδρεύσατο",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a scos."
      },
      {
        "t": " apă; și i-am "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וָאֹמַר",
        "translit": "va'omar",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-am spus."
      },
      {
        "t": ": «"
      },
      {
        "t": "Dă-mi",
        "w": "Dă-mi",
        "heb": "הַשְׁקִינִי",
        "translit": "hashkini",
        "strong": "H8248",
        "pos": "verb, imperativ, cu sufix",
        "greek": "Πότισόν με",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Dă-mi."
      },
      {
        "t": ", te rog, să "
      },
      {
        "t": "beau",
        "w": "beau",
        "heb": "",
        "translit": "",
        "strong": "",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să beau."
      },
      {
        "t": ".»"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "אֲנִי טֶרֶם אֲכַלֶּה לְדַבֵּר אֶל־לִבִּי וְהִנֵּה רִבְקָה יֹצֵאת וְכַדָּהּ עַל־שִׁכְמָהּ וַתֵּרֶד הָעַיְנָה וַתִּשְׁאָב וָאֹמַר אֵלֶיהָ הַשְׁקִינִי נָא",
        "translation": "„Nici nu terminasem de vorbit în sinea mea că iată, Rebeca a ieșit cu ulciorul pe umăr și a coborât către izvor și a scos apă; și i-am spus: «Dă-mi, te rog, să beau.»” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἐγένετο πρὸ τοῦ συντελέσαι με λαλοῦντα ἐν τῇ διανοίᾳ εὐθὺς Ρεβεκκα ἐξεπορεύετο ἔχουσα τὴν ὑδρίαν ἐπὶ τῶν ὤμων καὶ κατέβη ἐπὶ τὴν πηγὴν καὶ ὑδρεύσατο. εἶπα δὲ αὐτῇ Πότισόν με.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "אני טרם אכלה לדבר אל לבי והנה רבקה יצאת וכדה על שכמה ותרד העין ותשאב ואמר אליה השקיני נא מעט מים מכדך",
        "translation": "Diferență reală, confirmată: אני טרם אכלה לדבר אל לבי והנה רבקה יצאת וכדה על שכמה ותרד העין ותשאב ואמר אליה השקיני נא מעט מים מכדך — „And before I had done speaking in mine heart, behold, Rebekah came forth with her pitcher on her shoulder; and she went down unto the well, and drew [water]: and I said unto her, Let me drink, I pray thee a little from waters of your pitcher.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:15"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Detaliul suplimentar „în sinea mea” dezvăluie că rugăciunea inițială fusese una interioară, nerostită cu voce tare — totuși „auzită” și împlinită."
      }
    ]
  },
  {
    "num": 46,
    "tokens": [
      {
        "t": "Și ea s-a "
      },
      {
        "t": "grăbit",
        "w": "grăbit",
        "heb": "וַתְּמַהֵר",
        "translit": "vatemaher",
        "strong": "H4116",
        "pos": "verb",
        "greek": "σπεύσασα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "s-a grăbit."
      },
      {
        "t": ", și-a "
      },
      {
        "t": "coborât",
        "w": "coborât",
        "heb": "וַתּוֹרֶד",
        "translit": "vatored",
        "strong": "H3381",
        "pos": "verb",
        "greek": "καθεῖλεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "și-a coborât."
      },
      {
        "t": " "
      },
      {
        "t": "ulciorul",
        "w": "ulciorul",
        "heb": "כַּדָּהּ",
        "translit": "khadah",
        "strong": "H3537",
        "pos": "substantiv cu sufix",
        "greek": "τὴν ὑδρίαν αὐτῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ulciorul ei."
      },
      {
        "t": " de pe ea și a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַתֹּאמֶר",
        "translit": "vatomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a spus."
      },
      {
        "t": ": «"
      },
      {
        "t": "Bea",
        "w": "Bea",
        "heb": "שְׁתֵה",
        "translit": "shteh",
        "strong": "H8354",
        "pos": "verb, imperativ",
        "greek": "Πίε",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Bea."
      },
      {
        "t": " și îți voi "
      },
      {
        "t": "adăpa",
        "w": "adăpa",
        "heb": "וְגַם־גְּמַלֶּיךָ אַשְׁקֶה",
        "translit": "vegam gemalekha ashkeh",
        "strong": "H8248",
        "pos": "verb",
        "greek": "τὰς καμήλους σου ποτιῶ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "voi adăpa."
      },
      {
        "t": " și "
      },
      {
        "t": "cămilele",
        "w": "cămilele",
        "heb": "",
        "translit": "",
        "strong": "",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămilele."
      },
      {
        "t": ".» Și am "
      },
      {
        "t": "băut",
        "w": "băut",
        "heb": "וָאֵשְׁתְּ",
        "translit": "va'eshte",
        "strong": "H8354",
        "pos": "verb",
        "greek": "ἔπιον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "am băut."
      },
      {
        "t": " și ea a "
      },
      {
        "t": "adăpat",
        "w": "adăpat",
        "heb": "הִשְׁקָתָה",
        "translit": "hishkatah",
        "strong": "H8248",
        "pos": "verb",
        "greek": "ἐπότισεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a adăpat."
      },
      {
        "t": " și "
      },
      {
        "t": "cămilele",
        "w": "cămilele",
        "heb": "הַגְּמַלִּים",
        "translit": "hagemalim",
        "strong": "H1581",
        "pos": "substantiv, cu articol",
        "greek": "τὰς καμήλους",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămilele."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַתְּמַהֵר וַתּוֹרֶד כַּדָּהּ מֵעָלֶיהָ וַתֹּאמֶר שְׁתֵה וְגַם־גְּמַלֶּיךָ אַשְׁקֶה וָאֵשְׁתְּ וְגַם הַגְּמַלִּים הִשְׁקָתָה",
        "translation": "„Și ea s-a grăbit, și-a coborât ulciorul de pe ea și a spus: «Bea și îți voi adăpa și cămilele.» Și am băut și ea a adăpat și cămilele.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ σπεύσασα καθεῖλεν τὴν ὑδρίαν αὐτῆς ἀφ᾿ ἑαυτῆς καὶ εἶπεν Πίε σύ, καὶ τὰς καμήλους σου ποτιῶ. καὶ ἔπιον, καὶ τὰς καμήλους μου ἐπότισεν.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ותמהר ותורד כדה מעליה ותאמר שתה וגם גמליך אשקה ואשתה וגם הגמלים השקתה",
        "translation": "Diferență reală, confirmată: ותמהר ותורד כדה מעליה ותאמר שתה וגם גמליך אשקה ואשתה וגם הגמלים השקתה — „And she made haste, and let down her pitcher from her [shoulder], and said, Drink, and I will give thy camels drink also: so I drank, and she made the camels drink also.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:18"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Repetarea exactă a gesturilor Rebecăi la fântână întărește autenticitatea relatării, fără spații pentru îndoială."
      }
    ]
  },
  {
    "num": 47,
    "tokens": [
      {
        "t": "Am "
      },
      {
        "t": "întrebat-o",
        "w": "întrebat-o",
        "heb": "וָאֶשְׁאַל",
        "translit": "va'esh'al",
        "strong": "H7592",
        "pos": "verb",
        "greek": "καὶ ἠρώτησα αὐτὴν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Am întrebat-o."
      },
      {
        "t": " și am "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וָאֹמַר",
        "translit": "va'omar",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "am spus."
      },
      {
        "t": ": «A cui "
      },
      {
        "t": "fiică",
        "w": "fiică",
        "heb": "בַת",
        "translit": "vat",
        "strong": "H1323",
        "pos": "substantiv",
        "greek": "θυγάτηρ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "fiică."
      },
      {
        "t": " ești tu?» Și ea a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַתֹּאמֶר",
        "translit": "vatomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a spus."
      },
      {
        "t": ": «"
      },
      {
        "t": "Fiica",
        "w": "Fiica",
        "heb": "בַּת",
        "translit": "vat",
        "strong": "H1323",
        "pos": "substantiv",
        "greek": "θυγάτηρ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Fiica."
      },
      {
        "t": " lui "
      },
      {
        "t": "Betuel",
        "w": "Betuel",
        "heb": "בְתוּאֵל",
        "translit": "Vetu'el",
        "strong": "H1328",
        "pos": "nume propriu",
        "greek": "Βαθουηλ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Betuel."
      },
      {
        "t": ", fiul lui "
      },
      {
        "t": "Nahor",
        "w": "Nahor",
        "heb": "נָחוֹר",
        "translit": "Nachor",
        "strong": "H5152",
        "pos": "nume propriu",
        "greek": "Ναχωρ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Nahor."
      },
      {
        "t": ", pe care i l-a "
      },
      {
        "t": "născut",
        "w": "născut",
        "heb": "יָלְדָה",
        "translit": "yaldah",
        "strong": "H3205",
        "pos": "verb",
        "greek": "ἔτεκεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i l-a născut."
      },
      {
        "t": " "
      },
      {
        "t": "Milca",
        "w": "Milca",
        "heb": "מִלְכָּה",
        "translit": "Milkah",
        "strong": "H4435",
        "pos": "nume propriu",
        "greek": "Μελχα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Milca."
      },
      {
        "t": ".» Atunci i-am "
      },
      {
        "t": "pus",
        "w": "pus",
        "heb": "וָאָשִׂם",
        "translit": "va'asim",
        "strong": "H7760",
        "pos": "verb",
        "greek": "περιέθηκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-am pus."
      },
      {
        "t": " "
      },
      {
        "t": "inelul",
        "w": "inelul",
        "heb": "הַנֶּזֶם",
        "translit": "hanezem",
        "strong": "H5141",
        "pos": "substantiv, cu articol",
        "greek": "τὰ ἐνώτια",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "inelul."
      },
      {
        "t": " în "
      },
      {
        "t": "nas",
        "w": "nas",
        "heb": "עַל־אַפָּהּ",
        "translit": "al apah",
        "strong": "H639",
        "pos": "substantiv cu sufix",
        "greek": "τῇ ὄψει αὐτῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "nasul ei."
      },
      {
        "t": " și "
      },
      {
        "t": "brățările",
        "w": "brățările",
        "heb": "וְהַצְּמִידִים",
        "translit": "vehatsemidim",
        "strong": "H6781",
        "pos": "substantiv, cu articol",
        "greek": "τὰ ψέλια",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "brățările."
      },
      {
        "t": " pe "
      },
      {
        "t": "mâini",
        "w": "mâini",
        "heb": "יָדֶיהָ",
        "translit": "yadeiha",
        "strong": "H3027",
        "pos": "substantiv cu sufix",
        "greek": "τὰς χεῖρας αὐτῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mâinile ei."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וָאֶשְׁאַל אֹתָהּ וָאֹמַר בַּת־מִי אַתְּ וַתֹּאמֶר בַּת־בְּתוּאֵל בֶּן־נָחוֹר אֲשֶׁר יָלְדָה־לּוֹ מִלְכָּה וָאָשִׂם הַנֶּזֶם עַל־אַפָּהּ וְהַצְּמִידִים עַל־יָדֶיהָ",
        "translation": "„Am întrebat-o și am spus: «A cui fiică ești tu?» Și ea a spus: «Fiica lui Betuel, fiul lui Nahor, pe care i l-a născut Milca.» Atunci i-am pus inelul în nas și brățările pe mâini.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἠρώτησα αὐτὴν καὶ εἶπα Τίνος εἶ θυγάτηρ; ἡ δὲ ἔφη Θυγάτηρ Βαθουηλ εἰμὶ τοῦ υἱοῦ Ναχωρ, ὃν ἔτεκεν αὐτῷ Μελχα. καὶ περιέθηκα αὐτῇ τὰ ἐνώτια καὶ τὰ ψέλια περὶ τὰς χεῖρας αὐτῆς.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ואשאל אתה ואמר בת מי אתי ותאמר בת בתואל בן נחור אשר ילדה לו מלכה ואשים הנזם על אפה והצמידים על ידיה",
        "translation": "Diferență reală, confirmată: ואשאל אתה ואמר בת מי אתי ותאמר בת בתואל בן נחור אשר ילדה לו מלכה ואשים הנזם על אפה והצמידים על ידיה — „And I asked her, and said, Whose daughter [art] thou? And she said, The daughter of Bethuel, Nahor's son, whom Milcah bare unto him: and I put the earring upon her face, and the bracelets upon her hands.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:24"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Ordinea repetării — întrebarea despre identitate, apoi darurile — clarifică, de această dată explicit, că darurile au fost oferite după confirmarea genealogiei (vezi și nota la v.22)."
      }
    ]
  },
  {
    "num": 48,
    "tokens": [
      {
        "t": "M-am "
      },
      {
        "t": "înclinat",
        "w": "înclinat",
        "heb": "וָאֶקֹּד",
        "translit": "va'ekod",
        "strong": "H6915",
        "pos": "verb",
        "greek": "εὐδοκήσας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "M-am înclinat."
      },
      {
        "t": " și m-am "
      },
      {
        "t": "prosternat",
        "w": "prosternat",
        "heb": "וָאֶשְׁתַּחֲוֶה",
        "translit": "va'eshtachaveh",
        "strong": "H7812",
        "pos": "verb",
        "greek": "προσεκύνησα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "m-am prosternat."
      },
      {
        "t": " "
      },
      {
        "t": "DOMNULUI",
        "w": "DOMNULUI",
        "heb": "לַיהוָה",
        "translit": "laYHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κυρίῳ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNULUI."
      },
      {
        "t": " și L-am "
      },
      {
        "t": "binecuvântat",
        "w": "binecuvântat",
        "heb": "וָאֲבָרֵךְ",
        "translit": "va'avarekh",
        "strong": "H1288",
        "pos": "verb",
        "greek": "εὐλόγησα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "L-am binecuvântat."
      },
      {
        "t": " pe "
      },
      {
        "t": "DOMNUL",
        "w": "DOMNUL",
        "heb": "יְהוָה",
        "translit": "YHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κύριον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNUL."
      },
      {
        "t": ", "
      },
      {
        "t": "Dumnezeul",
        "w": "Dumnezeul",
        "heb": "אֱלֹהֵי",
        "translit": "Elohei",
        "strong": "H430",
        "pos": "substantiv, stare construită",
        "greek": "τὸν Θεὸν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Dumnezeul."
      },
      {
        "t": " stăpânului meu "
      },
      {
        "t": "Avraham",
        "w": "Avraham",
        "heb": "אֲדֹנִי אַבְרָהָם",
        "translit": "adoni Avraham",
        "strong": "H85",
        "pos": "nume propriu",
        "greek": "τοῦ κυρίου μου Αβρααμ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Avraham."
      },
      {
        "t": ", care m-a "
      },
      {
        "t": "călăuzit",
        "w": "călăuzit",
        "heb": "הִנְחַנִי",
        "translit": "hinchani",
        "strong": "H5148",
        "pos": "verb, cu sufix",
        "greek": "εὐόδωκέν με",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "m-a călăuzit."
      },
      {
        "t": " pe o "
      },
      {
        "t": "cale",
        "w": "cale",
        "heb": "בְּדֶרֶךְ",
        "translit": "bederekh",
        "strong": "H1870",
        "pos": "substantiv, stare construită",
        "greek": "ὁδὸν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cale."
      },
      {
        "t": " "
      },
      {
        "t": "adevărată",
        "w": "adevărată",
        "heb": "אֱמֶת",
        "translit": "emet",
        "strong": "H571",
        "pos": "substantiv",
        "greek": "ἀληθείας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "adevărată."
      },
      {
        "t": " să o "
      },
      {
        "t": "iau",
        "w": "iau",
        "heb": "לָקַחַת",
        "translit": "lakachat",
        "strong": "H3947",
        "pos": "verb (infinitiv)",
        "greek": "λαβεῖν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să o iau."
      },
      {
        "t": " pe "
      },
      {
        "t": "fiica",
        "w": "fiica",
        "heb": "בַּת",
        "translit": "vat",
        "strong": "H1323",
        "pos": "substantiv, stare construită",
        "greek": "τὴν θυγατέρα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "fiica."
      },
      {
        "t": " fratelui stăpânului meu pentru fiul său."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וָאֶקֹּד וָאֶשְׁתַּחֲוֶה לַיהוָה וָאֲבָרֵךְ אֶת־יְהוָה אֱלֹהֵי אֲדֹנִי אַבְרָהָם אֲשֶׁר הִנְחַנִי בְּדֶרֶךְ אֱמֶת לָקַחַת אֶת־בַּת־אֲחִי אֲדֹנִי לִבְנוֹ",
        "translation": "„M-am înclinat și m-am prosternat DOMNULUI și L-am binecuvântat pe DOMNUL, Dumnezeul stăpânului meu Avraham, care m-a călăuzit pe o cale adevărată să o iau pe fiica fratelui stăpânului meu pentru fiul său.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ εὐδοκήσας προσεκύνησα Κυρίῳ καὶ εὐλόγησα Κύριον τὸν θεὸν τοῦ κυρίου μου Αβρααμ, ὃς εὐόδωσέν μοι ἐν ὁδῷ ἀληθείας λαβεῖν τὴν θυγατέρα τοῦ ἀδελφοῦ τοῦ κυρίου μου τῷ υἱῷ αὐτοῦ.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ואקד ואשתחוי ליהוה ואברך את יהוה אלהי אדני אברהם אשר הנחני בדרך אמת לקחת את בת אחי אדני לבנו",
        "translation": "Diferență reală, confirmată: ואקד ואשתחוי ליהוה ואברך את יהוה אלהי אדני אברהם אשר הנחני בדרך אמת לקחת את בת אחי אדני לבנו — „And I bowed down my head, and worshipped the LORD, and blessed the LORD God of my master Abraham, which had led me in the right way to take my master's brother's daughter unto his son.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:26-27"
    ],
    "commentaries": [
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Leagă „drumul cel drept” de confirmarea cuvintelor lui Dumnezeu de a face bunătate față de Avraham și fiul său — călăuzirea slujitorului dovedește că promisiunea divină s-a împlinit exact."
      }
    ]
  },
  {
    "num": 49,
    "tokens": [
      {
        "t": "Și acum, dacă "
      },
      {
        "t": "vreți",
        "w": "vreți",
        "heb": "יֶשְׁכֶם",
        "translit": "yeshkhem",
        "strong": "H3426",
        "pos": "particulă cu sufix",
        "greek": "ἐστε",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "vreți."
      },
      {
        "t": " să-i "
      },
      {
        "t": "arătați",
        "w": "arătați",
        "heb": "עֹשִׂים",
        "translit": "osim",
        "strong": "H6213",
        "pos": "verb, participiu",
        "greek": "ποιεῖτε",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să-i arătați."
      },
      {
        "t": " "
      },
      {
        "t": "bunăvoință",
        "w": "bunăvoință",
        "heb": "חֶסֶד",
        "translit": "chesed",
        "strong": "H2617",
        "pos": "substantiv",
        "greek": "ἔλεος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "bunăvoință."
      },
      {
        "t": " și "
      },
      {
        "t": "adevăr",
        "w": "adevăr",
        "heb": "וֶאֱמֶת",
        "translit": "ve'emet",
        "strong": "H571",
        "pos": "substantiv",
        "greek": "δικαιοσύνην",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "adevăr."
      },
      {
        "t": " stăpânului meu, "
      },
      {
        "t": "ziceți-mi",
        "w": "ziceți-mi",
        "heb": "הַגִּידוּ",
        "translit": "hagidu",
        "strong": "H5046",
        "pos": "verb, imperativ",
        "greek": "ἀπαγγείλατέ μοι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ziceți-mi."
      },
      {
        "t": "; iar dacă nu, "
      },
      {
        "t": "ziceți-mi",
        "w": "ziceți-mi",
        "heb": "הַגִּידוּ",
        "translit": "hagidu",
        "strong": "H5046",
        "pos": "verb, imperativ",
        "greek": "ἀπαγγείλατέ μοι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ziceți-mi."
      },
      {
        "t": "; și mă voi "
      },
      {
        "t": "îndrepta",
        "w": "îndrepta",
        "heb": "וְאֶפְנֶה",
        "translit": "ve'efneh",
        "strong": "H6437",
        "pos": "verb",
        "greek": "ἐπιστρέψω",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mă voi îndrepta."
      },
      {
        "t": " spre "
      },
      {
        "t": "dreapta",
        "w": "dreapta",
        "heb": "יָמִין",
        "translit": "yamin",
        "strong": "H3225",
        "pos": "substantiv",
        "greek": "δεξιὰν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "dreapta."
      },
      {
        "t": " sau spre "
      },
      {
        "t": "stânga",
        "w": "stânga",
        "heb": "שְׂמֹאול",
        "translit": "semol",
        "strong": "H8040",
        "pos": "substantiv",
        "greek": "ἀριστεράν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "stânga."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וְעַתָּה אִם־יֶשְׁכֶם עֹשִׂים חֶסֶד וֶאֱמֶת אֶת־אֲדֹנִי הַגִּידוּ לִי וְאִם־לֹא הַגִּידוּ לִי וְאֶפְנֶה עַל־יָמִין אוֹ עַל־שְׂמֹאל",
        "translation": "„Și acum, dacă vreți să-i arătați bunăvoință și adevăr stăpânului meu, ziceți-mi; iar dacă nu, ziceți-mi; și mă voi îndrepta spre dreapta sau spre stânga.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "εἰ οὖν ποιεῖτε ὑμεῖς ἔλεος καὶ δικαιοσύνην πρὸς τὸν κύριόν μου, ἀπαγγείλατέ μοι, εἰ δὲ μή, ἀπαγγείλατέ μοι, ἵνα ἐπιστρέψω εἰς δεξιὰν ἢ εἰς ἀριστεράν.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ועתה אם ישכם עשים חסד ואמת את אדני הגידו לי ואם לא הגידו לי ואפנה על הימין או על השמאל",
        "translation": "Diferență reală, confirmată: ועתה אם ישכם עשים חסד ואמת את אדני הגידו לי ואם לא הגידו לי ואפנה על הימין או על השמאל — „And now if ye will deal kindly and truly with my master, tell me: and if not, tell me; that I may turn to the right hand, or to the left.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "commentaries": [
      {
        "author": "Sforno (cca. 1475–1550)",
        "text": "Explică cele două cereri: „bunăvoință” înseamnă să renunțe la propriile dorințe și să accepte trimiterea fiicei într-o țară îndepărtată, fără a se gândi la avantajul de a avea rude aproape; „adevăr” înseamnă recunoașterea că onoarea reală a fiicei lor vine tocmai din intrarea în casa lui Avraham, nu din păstrarea ei acasă."
      }
    ],
    "refs": [
      "Geneza 47:29"
    ]
  },
  {
    "num": 50,
    "tokens": [
      {
        "t": "Lavan",
        "w": "Lavan",
        "heb": "לָבָן",
        "translit": "Lavan",
        "strong": "H3837",
        "pos": "nume propriu",
        "greek": "Λαβαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Lavan."
      },
      {
        "t": " și "
      },
      {
        "t": "Betuel",
        "w": "Betuel",
        "heb": "וּבְתוּאֵל",
        "translit": "uVetu'el",
        "strong": "H1328",
        "pos": "nume propriu",
        "greek": "Βαθουηλ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Betuel."
      },
      {
        "t": " au "
      },
      {
        "t": "răspuns",
        "w": "răspuns",
        "heb": "וַיַּעַן",
        "translit": "vaya'an",
        "strong": "H6030",
        "pos": "verb",
        "greek": "ἀπεκρίθη",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "au răspuns."
      },
      {
        "t": " și au "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמְרוּ",
        "translit": "vayomeru",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "au spus."
      },
      {
        "t": ": „De la "
      },
      {
        "t": "DOMNUL",
        "w": "DOMNUL",
        "heb": "יְהוָה",
        "translit": "YHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κυρίου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNUL."
      },
      {
        "t": " a "
      },
      {
        "t": "ieșit",
        "w": "ieșit",
        "heb": "יָצָא",
        "translit": "yatsa",
        "strong": "H3318",
        "pos": "verb",
        "greek": "ἐξῆλθεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a ieșit."
      },
      {
        "t": " "
      },
      {
        "t": "lucrul",
        "w": "lucrul",
        "heb": "הַדָּבָר",
        "translit": "hadavar",
        "strong": "H1697",
        "pos": "substantiv, cu articol",
        "greek": "τὸ πρᾶγμα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "lucrul."
      },
      {
        "t": " [acesta]! Nu îți putem "
      },
      {
        "t": "zice",
        "w": "zice",
        "heb": "נוּכַל דַּבֵּר",
        "translit": "nukhal daber",
        "strong": "H1696",
        "pos": "verb",
        "greek": "δυνησόμεθα ἀντειπεῖν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "putem zice."
      },
      {
        "t": " nici de "
      },
      {
        "t": "rău",
        "w": "rău",
        "heb": "רַע",
        "translit": "ra",
        "strong": "H7451",
        "pos": "adjectiv",
        "greek": "κακὸν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "rău."
      },
      {
        "t": ", nici de "
      },
      {
        "t": "bine",
        "w": "bine",
        "heb": "טוֹב",
        "translit": "tov",
        "strong": "H2896",
        "pos": "adjectiv",
        "greek": "καλόν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "bine."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיַּעַן לָבָן וּבְתוּאֵל וַיֹּאמְרוּ מֵיְהוָה יָצָא הַדָּבָר לֹא נוּכַל דַּבֵּר אֵלֶיךָ רַע אוֹ־טוֹב",
        "translation": "„Lavan și Betuel au răspuns și au spus: „De la DOMNUL a ieșit lucrul [acesta]! Nu îți putem zice nici de rău, nici de bine.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "Ἀποκριθεὶς δὲ Λαβαν καὶ Βαθουηλ εἶπαν Παρὰ Κυρίου ἐξῆλθεν τὸ πρόσταγμα τοῦτο· οὐ δυνησόμεθα οὖν σοι ἀντειπεῖν κακὸν καλῷ.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויען לבן ובתואל ויאמרו מיהוה יצא הדבר לא נוכל דבר אליך רע וטוב",
        "translation": "Diferență reală, confirmată: ויען לבן ובתואל ויאמרו מיהוה יצא הדבר לא נוכל דבר אליך רע וטוב — „Then Laban and Bethuel answered and said, The thing proceedeth from the LORD: we cannot speak unto thee bad or good.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 31:24,29"
    ],
    "commentaries": [
      {
        "author": "Sforno (cca. 1475–1550)",
        "text": "Interpretează „nu putem să-ți spunem nici rău, nici bine” ca recunoaștere că nici respingerea, nici aprobarea propunerii nu mai depindeau de voința lor — decizia fiind deja hotărâtă de Dumnezeu."
      },
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Notează același lucru din unghi gramatical: nici desfacerea, nici încheierea învoielii nu mai țineau de voința lor, fiind un act implicat de Dumnezeu însuși, „căci puterea e în mâna Lui”."
      }
    ]
  },
  {
    "num": 51,
    "tokens": [
      {
        "t": "Iată, "
      },
      {
        "t": "Rebeca",
        "w": "Rebeca",
        "heb": "רִבְקָה",
        "translit": "Rivkah",
        "strong": "H7259",
        "pos": "nume propriu",
        "greek": "Ρεβεκκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Rebeca."
      },
      {
        "t": " este înaintea ta; "
      },
      {
        "t": "ia-o",
        "w": "ia-o",
        "heb": "קַח",
        "translit": "kach",
        "strong": "H3947",
        "pos": "verb, imperativ",
        "greek": "λαβὼν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ia-o."
      },
      {
        "t": " și "
      },
      {
        "t": "du-te",
        "w": "du-te",
        "heb": "וָלֵךְ",
        "translit": "valekh",
        "strong": "H1980",
        "pos": "verb, imperativ",
        "greek": "ἀπότρεχε",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "du-te."
      },
      {
        "t": ", și ea să fie "
      },
      {
        "t": "soție",
        "w": "soție",
        "heb": "אִשָּׁה",
        "translit": "ishah",
        "strong": "H802",
        "pos": "substantiv",
        "greek": "γυνὴ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "soție."
      },
      {
        "t": " pentru fiul stăpânului tău, după cum a "
      },
      {
        "t": "vorbit",
        "w": "vorbit",
        "heb": "דִּבֶּר",
        "translit": "diber",
        "strong": "H1696",
        "pos": "verb",
        "greek": "ἐλάλησεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a vorbit."
      },
      {
        "t": " "
      },
      {
        "t": "DOMNUL",
        "w": "DOMNUL",
        "heb": "יְהוָה",
        "translit": "YHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κύριος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNUL."
      },
      {
        "t": ".”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "הִנֵּה־רִבְקָה לְפָנֶיךָ קַח וָלֵךְ וּתְהִי אִשָּׁה לְבֶן־אֲדֹנֶיךָ כַּאֲשֶׁר דִּבֶּר יְהוָה",
        "translation": "„Iată, Rebeca este înaintea ta; ia-o și du-te, și ea să fie soție pentru fiul stăpânului tău, după cum a vorbit DOMNUL.”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "ἰδοὺ Ρεβεκκα ἐνώπιόν σου· λαβὼν ἀπότρεχε, καὶ ἔστω γυνὴ τῷ υἱῷ τοῦ κυρίου σου, καθὰ ἐλάλησεν Κύριος.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "הנה רבקה לפניך קח ולך ותהי אשה לבן אדניך כאשר דבר יהוה",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:4"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Consimțământul complet și necondiționat al familiei, fără negocieri suplimentare, arată acceptarea directă a ceea ce ei înșiși recunosc drept voință divină (v.50)."
      }
    ]
  },
  {
    "num": 52,
    "tokens": [
      {
        "t": "Iar când "
      },
      {
        "t": "slujitorul",
        "w": "slujitorul",
        "heb": "עֶבֶד",
        "translit": "eved",
        "strong": "H5650",
        "pos": "substantiv, stare construită",
        "greek": "ὁ παῖς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "slujitorul."
      },
      {
        "t": " lui "
      },
      {
        "t": "Avraham",
        "w": "Avraham",
        "heb": "אַבְרָהָם",
        "translit": "Avraham",
        "strong": "H85",
        "pos": "nume propriu",
        "greek": "τοῦ Αβρααμ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Avraham."
      },
      {
        "t": " a "
      },
      {
        "t": "auzit",
        "w": "auzit",
        "heb": "שָׁמַע",
        "translit": "shama",
        "strong": "H8085",
        "pos": "verb",
        "greek": "ἤκουσεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a auzit."
      },
      {
        "t": " "
      },
      {
        "t": "vorbele",
        "w": "vorbele",
        "heb": "דִּבְרֵיהֶם",
        "translit": "divreihem",
        "strong": "H1697",
        "pos": "substantiv cu sufix",
        "greek": "τῶν λόγων τούτων",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "vorbele lor."
      },
      {
        "t": " lor, s-a "
      },
      {
        "t": "prosternat",
        "w": "prosternat",
        "heb": "וַיִּשְׁתַּחוּ",
        "translit": "vayishtachu",
        "strong": "H7812",
        "pos": "verb",
        "greek": "προσεκύνησεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "s-a prosternat."
      },
      {
        "t": " "
      },
      {
        "t": "DOMNULUI",
        "w": "DOMNULUI",
        "heb": "יְהוָה",
        "translit": "YHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κυρίῳ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNULUI."
      },
      {
        "t": ", până la "
      },
      {
        "t": "pământ",
        "w": "pământ",
        "heb": "אָרְצָה",
        "translit": "artsah",
        "strong": "H776",
        "pos": "substantiv",
        "greek": "τὴν γῆν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "pământ."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיְהִי כַּאֲשֶׁר שָׁמַע עֶבֶד אַבְרָהָם אֶת־דִּבְרֵיהֶם וַיִּשְׁתַּחוּ אַרְצָה לַיהוָה",
        "translation": "„Iar când slujitorul lui Avraham a auzit vorbele lor, s-a prosternat DOMNULUI, până la pământ.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "ἐγένετο δὲ ἐν τῷ ἀκοῦσαι τὸν παῖδα τὸν Αβρααμ τῶν ῥημάτων τούτων προσεκύνησεν ἐπὶ τὴν γῆν Κυρίῳ.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויהי כאשר שמע עבד אברהם את דבריהם וישתחוי ארצה ליהוה",
        "translation": "Diferență reală, confirmată: ויהי כאשר שמע עבד אברהם את דבריהם וישתחוי ארצה ליהוה — „And it came to pass, that, when Abraham's servant heard their words, he worshipped the LORD, [bowing himself] to the earth.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "A doua prosternare a slujitorului, de această dată în fața familiei, repetă gestul făcut deja la fântână (v.26) — recunoștință reînnoită la fiecare pas important al misiunii."
      }
    ],
    "refs": [
      "Geneza 24:26"
    ]
  },
  {
    "num": 53,
    "tokens": [
      {
        "t": "Și "
      },
      {
        "t": "slujitorul",
        "w": "slujitorul",
        "heb": "הָעֶבֶד",
        "translit": "ha'eved",
        "strong": "H5650",
        "pos": "substantiv, cu articol",
        "greek": "ὁ παῖς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "slujitorul."
      },
      {
        "t": " a "
      },
      {
        "t": "scos",
        "w": "scos",
        "heb": "וַיּוֹצֵא",
        "translit": "vayotse",
        "strong": "H3318",
        "pos": "verb",
        "greek": "ἐξενέγκας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a scos."
      },
      {
        "t": " "
      },
      {
        "t": "obiecte",
        "w": "obiecte",
        "heb": "כְלֵי",
        "translit": "kelei",
        "strong": "H3627",
        "pos": "substantiv, stare construită",
        "greek": "σκεύη",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "obiecte."
      },
      {
        "t": " de "
      },
      {
        "t": "argint",
        "w": "argint",
        "heb": "כֶסֶף",
        "translit": "khesef",
        "strong": "H3701",
        "pos": "substantiv",
        "greek": "ἀργυρᾶ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "argint."
      },
      {
        "t": " și "
      },
      {
        "t": "obiecte",
        "w": "obiecte",
        "heb": "וּכְלֵי",
        "translit": "ukhelei",
        "strong": "H3627",
        "pos": "substantiv, stare construită",
        "greek": "σκεύη",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "obiecte."
      },
      {
        "t": " de "
      },
      {
        "t": "aur",
        "w": "aur",
        "heb": "זָהָב",
        "translit": "zahav",
        "strong": "H2091",
        "pos": "substantiv",
        "greek": "χρυσᾶ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "aur."
      },
      {
        "t": " și "
      },
      {
        "t": "haine",
        "w": "haine",
        "heb": "וּבְגָדִים",
        "translit": "uvegadim",
        "strong": "H899",
        "pos": "substantiv",
        "greek": "ἱματισμὸν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "haine."
      },
      {
        "t": " și le-a "
      },
      {
        "t": "dat",
        "w": "dat",
        "heb": "וַיִּתֵּן",
        "translit": "vayiten",
        "strong": "H5414",
        "pos": "verb",
        "greek": "ἔδωκεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "le-a dat."
      },
      {
        "t": " "
      },
      {
        "t": "Rebecăi",
        "w": "Rebecăi",
        "heb": "לְרִבְקָה",
        "translit": "leRivkah",
        "strong": "H7259",
        "pos": "nume propriu",
        "greek": "τῇ Ρεβεκκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Rebecăi."
      },
      {
        "t": "; și a "
      },
      {
        "t": "dat",
        "w": "dat",
        "heb": "נָתַן",
        "translit": "natan",
        "strong": "H5414",
        "pos": "verb",
        "greek": "ἔδωκεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a dat."
      },
      {
        "t": " "
      },
      {
        "t": "delicatese",
        "w": "delicatese",
        "heb": "מִגְדָּנֹת",
        "translit": "migdanot",
        "strong": "H4030",
        "pos": "substantiv",
        "greek": "δῶρα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "delicatese."
      },
      {
        "t": " fratelui ei și mamei ei."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיּוֹצֵא הָעֶבֶד כְּלֵי־כֶסֶף וּכְלֵי זָהָב וּבְגָדִים וַיִּתֵּן לְרִבְקָה וּמִגְדָּנֹת נָתַן לְאָחִיהָ וּלְאִמָּהּ",
        "translation": "„Și slujitorul a scos obiecte de argint și obiecte de aur și haine și le-a dat Rebecăi; și a dat delicatese fratelui ei și mamei ei.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἐξενέγκας ὁ παῖς σκεύη ἀργυρᾶ καὶ χρυσᾶ καὶ ἱματισμὸν ἔδωκεν Ρεβεκκα καὶ δῶρα ἔδωκεν τῷ ἀδελφῷ αὐτῆς καὶ τῇ μητρὶ αὐτῆς.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויוצא העבד כלי כסף וכלי זהב ובגדים ויתן לרבקה ומגדנות נתן לאחיה ולאמה",
        "translation": "Diferență reală, confirmată: ויוצא העבד כלי כסף וכלי זהב ובגדים ויתן לרבקה ומגדנות נתן לאחיה ולאמה — „And the servant brought forth jewels of silver, and jewels of gold, and raiment, and gave [them] to Rebekah: he gave also to her brother and to her mother precious things.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 34:12"
    ],
    "commentaries": [
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Identifică „obiectele de argint și aur” drept podoabe femeiești obișnuite, comparabile cu darurile de nuntă menționate în alte pasaje din Tora (Numeri 31:50, Exod 3:22)."
      }
    ]
  },
  {
    "num": 54,
    "tokens": [
      {
        "t": "Au "
      },
      {
        "t": "mâncat",
        "w": "mâncat",
        "heb": "וַיֹּאכְלוּ",
        "translit": "vayokhlu",
        "strong": "H398",
        "pos": "verb",
        "greek": "ἔφαγον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Au mâncat."
      },
      {
        "t": " și au "
      },
      {
        "t": "băut",
        "w": "băut",
        "heb": "וַיִּשְׁתּוּ",
        "translit": "vayishtu",
        "strong": "H8354",
        "pos": "verb",
        "greek": "ἔπιον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "au băut."
      },
      {
        "t": ", el și "
      },
      {
        "t": "oamenii",
        "w": "oamenii",
        "heb": "וְהָאֲנָשִׁים",
        "translit": "veha'anashim",
        "strong": "H376",
        "pos": "substantiv, cu articol",
        "greek": "οἱ ἄνδρες",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "oamenii."
      },
      {
        "t": " care erau cu el; au "
      },
      {
        "t": "înnoptat",
        "w": "înnoptat",
        "heb": "וַיָּלִינוּ",
        "translit": "vayalinu",
        "strong": "H3885",
        "pos": "verb",
        "greek": "ηὐλίσθησαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "au înnoptat."
      },
      {
        "t": ", s-au "
      },
      {
        "t": "trezit",
        "w": "trezit",
        "heb": "וַיָּקוּמוּ",
        "translit": "vayakumu",
        "strong": "H6965",
        "pos": "verb",
        "greek": "ἀναστὰς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "s-au trezit."
      },
      {
        "t": " "
      },
      {
        "t": "dis-de-dimineață",
        "w": "dis-de-dimineață",
        "heb": "בַבֹּקֶר",
        "translit": "vaboker",
        "strong": "H1242",
        "pos": "substantiv, cu prefix",
        "greek": "τὸ πρωὶ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "dis-de-dimineață."
      },
      {
        "t": " și el a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמֶר",
        "translit": "vayomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a spus."
      },
      {
        "t": ": „"
      },
      {
        "t": "Lăsați-mă",
        "w": "Lăsați-mă",
        "heb": "שַׁלְּחֻנִי",
        "translit": "shalechuni",
        "strong": "H7971",
        "pos": "verb, imperativ, cu sufix",
        "greek": "Ἐκπέμψατέ με",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Lăsați-mă."
      },
      {
        "t": " să plec la stăpânul meu.”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיֹּאכְלוּ וַיִּשְׁתּוּ הוּא וְהָאֲנָשִׁים אֲשֶׁר־עִמּוֹ וַיָּלִינוּ וַיָּקוּמוּ בַבֹּקֶר וַיֹּאמֶר שַׁלְּחֻנִי לַאדֹנִי",
        "translation": "„Au mâncat și au băut, el și oamenii care erau cu el; au înnoptat, s-au trezit dis-de-dimineață și el a spus: „Lăsați-mă să plec la stăpânul meu.”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἔφαγον καὶ ἔπιον, αὐτὸς καὶ οἱ ἄνδρες οἱ μετ᾿ αὐτοῦ ὄντες, καὶ ἐκοιμήθησαν. Καὶ ἀναστὰς πρωὶ εἶπεν Ἐκπέμψατέ με, ἵνα ἀπέλθω πρὸς τὸν κύριόν μου.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויאכלו וישתו הוא והאנשים אשר עמו וילינו ויקמו בבקר ויאמר שלחוני לאדני",
        "translation": "Diferență reală, confirmată: ויאכלו וישתו הוא והאנשים אשר עמו וילינו ויקמו בבקר ויאמר שלחוני לאדני — „And they did eat and drink, he and the men that [were] with him, and tarried all night; and they rose up in the morning, and he said, Send me away unto my master.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 18:4-5"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Prioritatea slujitorului rămâne clară: masa vine abia după încheierea afacerii, iar imediat după aceea cere plecarea, fără întârziere inutilă."
      }
    ]
  },
  {
    "num": 55,
    "tokens": [
      {
        "t": "Fratele",
        "w": "Fratele",
        "heb": "אָחִיהָ",
        "translit": "achiha",
        "strong": "H251",
        "pos": "substantiv cu sufix",
        "greek": "οἱ ἀδελφοὶ αὐτῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Fratele."
      },
      {
        "t": " ei și "
      },
      {
        "t": "mama",
        "w": "mama",
        "heb": "וְאִמָּהּ",
        "translit": "ve'imah",
        "strong": "H517",
        "pos": "substantiv cu sufix",
        "greek": "ἡ μήτηρ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mama."
      },
      {
        "t": " ei au "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַתֹּאמֶר",
        "translit": "vatomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "au spus."
      },
      {
        "t": ": „"
      },
      {
        "t": "Tânăra",
        "w": "Tânăra",
        "heb": "הַנַּעֲרָ",
        "translit": "hana'ara",
        "strong": "H5291",
        "pos": "substantiv, cu articol",
        "greek": "ἡ παρθένος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Tânăra."
      },
      {
        "t": " să "
      },
      {
        "t": "stea",
        "w": "stea",
        "heb": "תֵּשֵׁב",
        "translit": "teshev",
        "strong": "H3427",
        "pos": "verb",
        "greek": "μεινάτω",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să stea."
      },
      {
        "t": " cu noi [un an de] "
      },
      {
        "t": "zile",
        "w": "zile",
        "heb": "יָמִים",
        "translit": "yamim",
        "strong": "H3117",
        "pos": "substantiv",
        "greek": "ἡμέρας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "zile."
      },
      {
        "t": " sau "
      },
      {
        "t": "zece",
        "w": "zece",
        "heb": "עָשׂוֹר",
        "translit": "asor",
        "strong": "H6235",
        "pos": "numeral",
        "greek": "δέκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "zece."
      },
      {
        "t": " [luni], apoi să "
      },
      {
        "t": "meargă",
        "w": "meargă",
        "heb": "תֵּלֵךְ",
        "translit": "teilekh",
        "strong": "H1980",
        "pos": "verb",
        "greek": "ἀπελεύσεται",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să meargă."
      },
      {
        "t": ".”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיֹּאמֶר אָחִיהָ וְאִמָּהּ תֵּשֵׁב הַנַּעֲרָ אִתָּנוּ יָמִים אוֹ עָשׂוֹר אַחַר תֵּלֵךְ",
        "translation": "„Fratele ei și mama ei au spus: „Tânăra să stea cu noi [un an de] zile sau zece [luni], apoi să meargă.”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "εἶπαν δὲ οἱ ἀδελφοὶ αὐτῆς καὶ ἡ μήτηρ Μεινάτω ἡ παρθένος μεθ᾿ ἡμῶν ἡμέρας ὡσεὶ δέκα, καὶ μετὰ ταῦτα ἀπελεύσεται.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויאמרו אחיה ואמה תשב הנערה אתנו ימים או חדש ואחר תלך",
        "translation": "Diferență reală, confirmată: ויאמרו אחיה ואמה תשב הנערה אתנו ימים או חדש ואחר תלך — „And her brother and her mother said, Let the damsel abide with us [a few] days, or a month; after that she shall go.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:58"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Cererea familiei de a o mai păstra pe Rebeca „vreo zece zile” a fost citită divers de comentatorii tradiționali — unii ca zece zile literale, alții ca o perioadă simbolică de până la un an — semn al ezitării fireasca a unei familii care își vede fiica plecând departe."
      }
    ]
  },
  {
    "num": 56,
    "tokens": [
      {
        "t": "El le-a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמֶר",
        "translit": "vayomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "le-a spus."
      },
      {
        "t": ": „Nu mă "
      },
      {
        "t": "întârziați",
        "w": "întârziați",
        "heb": "תְּאַחֲרוּ",
        "translit": "te'acharu",
        "strong": "H309",
        "pos": "verb",
        "greek": "κατάσχητέ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mă întârziați."
      },
      {
        "t": ", acum că "
      },
      {
        "t": "DOMNUL",
        "w": "DOMNUL",
        "heb": "יְהוָה",
        "translit": "YHVH",
        "strong": "H3068",
        "pos": "substantiv",
        "greek": "Κύριος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "DOMNUL."
      },
      {
        "t": " a făcut să-mi "
      },
      {
        "t": "reușească",
        "w": "reușească",
        "heb": "הִצְלִיחַ",
        "translit": "hitsliach",
        "strong": "H6743",
        "pos": "verb",
        "greek": "εὐόδωσεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să-mi reușească."
      },
      {
        "t": " "
      },
      {
        "t": "drumul",
        "w": "drumul",
        "heb": "דַּרְכִּי",
        "translit": "darki",
        "strong": "H1870",
        "pos": "substantiv cu sufix",
        "greek": "τὴν ὁδόν μου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "drumul meu."
      },
      {
        "t": ", "
      },
      {
        "t": "lăsați-mă",
        "w": "lăsați-mă",
        "heb": "שַׁלְּחוּנִי",
        "translit": "shalechuni",
        "strong": "H7971",
        "pos": "verb, imperativ, cu sufix",
        "greek": "ἐκπέμψατέ με",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "lăsați-mă."
      },
      {
        "t": " să plec și voi "
      },
      {
        "t": "merge",
        "w": "merge",
        "heb": "וְאֵלְכָה",
        "translit": "ve'elekhah",
        "strong": "H1980",
        "pos": "verb",
        "greek": "πορεύσωμαι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "voi merge."
      },
      {
        "t": " la stăpânul meu!”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיֹּאמֶר אֲלֵהֶם אַל־תְּאַחֲרוּ אֹתִי וַיהוָה הִצְלִיחַ דַּרְכִּי שַׁלְּחוּנִי וְאֵלְכָה לַאדֹנִי",
        "translation": "„El le-a spus: „Nu mă întârziați, acum că DOMNUL a făcut să-mi reușească drumul, lăsați-mă să plec și voi merge la stăpânul meu!”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "ὁ δὲ εἶπεν πρὸς αὐτούς Μὴ κατέχετέ με, καὶ Κύριος εὐόδωσεν τὴν ὁδόν μου ἐν ἐμοί· ἐκπέμψατέ με, ἵνα ἀπέλθω πρὸς τὸν κύριόν μου.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויאמר אליהם אל תאחרו אתי ויהוה הצליח את דרכי שלחוני ואלכה אל אדני",
        "translation": "Diferență reală, confirmată: ויאמר אליהם אל תאחרו אתי ויהוה הצליח את דרכי שלחוני ואלכה אל אדני — „And he said unto them, Hinder me not, seeing the LORD hath prospered my way; send me away that I may go to my master.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "commentaries": [
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Explică insistența slujitorului: din moment ce Dumnezeu a făcut deja să reușească misiunea, orice întârziere suplimentară nu ar mai adăuga nimic — succesul deplin cere finalizare imediată, nu tergiversare."
      }
    ],
    "refs": [
      "Geneza 45:9"
    ]
  },
  {
    "num": 57,
    "tokens": [
      {
        "t": "Și ei au "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמְרוּ",
        "translit": "vayomeru",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "au spus."
      },
      {
        "t": ": „S-o "
      },
      {
        "t": "chemăm",
        "w": "chemăm",
        "heb": "נִקְרָא",
        "translit": "nikra",
        "strong": "H7121",
        "pos": "verb",
        "greek": "καλέσωμεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "s-o chemăm."
      },
      {
        "t": " pe "
      },
      {
        "t": "tânără",
        "w": "tânără",
        "heb": "לַנַּעֲרָ",
        "translit": "lana'ara",
        "strong": "H5291",
        "pos": "substantiv, cu prefix",
        "greek": "τὴν παῖδα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "tânără."
      },
      {
        "t": " și s-o "
      },
      {
        "t": "întrebăm",
        "w": "întrebăm",
        "heb": "וְנִשְׁאֲלָה",
        "translit": "venish'alah",
        "strong": "H7592",
        "pos": "verb",
        "greek": "ἐρωτήσωμεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "s-o întrebăm."
      },
      {
        "t": ".”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיֹּאמְרוּ נִקְרָא לַנַּעֲרָ וְנִשְׁאֲלָה אֶת־פִּיהָ",
        "translation": "„Și ei au spus: „S-o chemăm pe tânără și s-o întrebăm.”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "οἱ δὲ εἶπαν Καλέσωμεν τὴν παῖδα καὶ ἐρωτήσωμεν τὸ στόμα αὐτῆς.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויאמרו נקרא לנערה ונשאל את פיה",
        "translation": "Diferență reală, confirmată: ויאמרו נקרא לנערה ונשאל את פיה — „And they said, We will call the damsel, and inquire at her mouth.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:5"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Decizia familiei de a o consulta direct pe Rebeca, nu doar bărbații casei, arată că era considerat necesar consimțământul ei personal pentru validitatea căsătoriei (vezi și Sforno la v.50 despre limitele deciziei familiei)."
      }
    ]
  },
  {
    "num": 58,
    "tokens": [
      {
        "t": "Și au "
      },
      {
        "t": "chemat-o",
        "w": "chemat-o",
        "heb": "וַיִּקְרְאוּ",
        "translit": "vayikre'u",
        "strong": "H7121",
        "pos": "verb",
        "greek": "ἐκάλεσαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "au chemat-o."
      },
      {
        "t": " pe "
      },
      {
        "t": "Rebeca",
        "w": "Rebeca",
        "heb": "לְרִבְקָה",
        "translit": "leRivkah",
        "strong": "H7259",
        "pos": "nume propriu",
        "greek": "τὴν Ρεβεκκαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "pe Rebeca."
      },
      {
        "t": " și i-au "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמְרוּ",
        "translit": "vayomeru",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-au spus."
      },
      {
        "t": ": „Te "
      },
      {
        "t": "duci",
        "w": "duci",
        "heb": "הֲתֵלְכִי",
        "translit": "hatelkhi",
        "strong": "H1980",
        "pos": "verb",
        "greek": "πορεύσῃ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "te duci."
      },
      {
        "t": " cu "
      },
      {
        "t": "omul",
        "w": "omul",
        "heb": "הָאִישׁ",
        "translit": "ha'ish",
        "strong": "H376",
        "pos": "substantiv, cu articol",
        "greek": "τοῦ ἀνθρώπου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "omul."
      },
      {
        "t": " acesta?” Și ea a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַתֹּאמֶר",
        "translit": "vatomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a spus."
      },
      {
        "t": ": „Mă "
      },
      {
        "t": "duc",
        "w": "duc",
        "heb": "אֵלֵךְ",
        "translit": "elekh",
        "strong": "H1980",
        "pos": "verb",
        "greek": "πορεύσομαι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mă duc."
      },
      {
        "t": ".”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיִּקְרְאוּ לְרִבְקָה וַיֹּאמְרוּ אֵלֶיהָ הֲתֵלְכִי עִם־הָאִישׁ הַזֶּה וַתֹּאמֶר אֵלֵךְ",
        "translation": "„Și au chemat-o pe Rebeca și i-au spus: „Te duci cu omul acesta?” Și ea a spus: „Mă duc.”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἐκάλεσαν τὴν Ρεβεκκαν καὶ εἶπαν αὐτῇ Πορεύσῃ μετὰ τοῦ ἀνθρώπου τούτου; ἡ δὲ εἶπεν Πορεύσομαι.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויקראו לרבקה ויאמרו לה התלכי עם האיש הזה ותאמר אלך",
        "translation": "Diferență reală, confirmată: ויקראו לרבקה ויאמרו לה התלכי עם האיש הזה ותאמר אלך — „And they called Rebekah, and said unto her, Wilt thou go with this man? And she said, I will go.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Rut 1:16-18"
    ],
    "commentaries": [
      {
        "author": "Rashi (1040–1105)",
        "text": "Notează hotărârea din răspunsul scurt al Rebecăi, „mă duc”: se va duce singură, chiar dacă familia ei nu ar mai vrea să o lase."
      },
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Precizează contextul întrebării puse Rebecăi: era o formă de curtoazie — chiar dacă voia lui Dumnezeu în privința unirii era deja clară, familia îi oferă totuși alegerea, amintind obiceiul de a lăsa unei fecioare până la douăsprezece luni ca să se pregătească. Răspunsul ei, „mă duc”, arată că nu voia să întârzie din dorința de a se împodobi mai întâi."
      }
    ]
  },
  {
    "num": 59,
    "tokens": [
      {
        "t": "Și au "
      },
      {
        "t": "lăsat-o",
        "w": "lăsat-o",
        "heb": "וַיְשַׁלְּחוּ",
        "translit": "vayeshalchu",
        "strong": "H7971",
        "pos": "verb",
        "greek": "ἐξέπεμψαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "au lăsat-o."
      },
      {
        "t": " să plece pe sora lor "
      },
      {
        "t": "Rebeca",
        "w": "Rebeca",
        "heb": "רִבְקָה",
        "translit": "Rivkah",
        "strong": "H7259",
        "pos": "nume propriu",
        "greek": "Ρεβεκκαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Rebeca."
      },
      {
        "t": " și pe "
      },
      {
        "t": "doica",
        "w": "doica",
        "heb": "וְאֶת־מֵנִקְתָּהּ",
        "translit": "ve'et menikatah",
        "strong": "H3243",
        "pos": "substantiv cu sufix",
        "greek": "τὴν τροφὸν αὐτῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "doica ei."
      },
      {
        "t": " ei și pe "
      },
      {
        "t": "slujitorul",
        "w": "slujitorul",
        "heb": "עֶבֶד",
        "translit": "eved",
        "strong": "H5650",
        "pos": "substantiv, stare construită",
        "greek": "τὸν παῖδα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "slujitorul."
      },
      {
        "t": " lui "
      },
      {
        "t": "Avraham",
        "w": "Avraham",
        "heb": "אַבְרָהָם",
        "translit": "Avraham",
        "strong": "H85",
        "pos": "nume propriu",
        "greek": "τοῦ Αβρααμ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Avraham."
      },
      {
        "t": " și pe "
      },
      {
        "t": "oamenii",
        "w": "oamenii",
        "heb": "וְאֶת־אֲנָשָׁיו",
        "translit": "ve'et anashav",
        "strong": "H376",
        "pos": "substantiv cu sufix",
        "greek": "τοὺς μετ᾿ αὐτοῦ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "oamenii lui."
      },
      {
        "t": " lui."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיְשַׁלְּחוּ אֶת־רִבְקָה אֲחֹתָם וְאֶת־מֵנִקְתָּהּ וְאֶת־עֶבֶד אַבְרָהָם וְאֶת־אֲנָשָׁיו",
        "translation": "„Și au lăsat-o să plece pe sora lor Rebeca și pe doica ei și pe slujitorul lui Avraham și pe oamenii lui.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἐξέπεμψαν Ρεβεκκαν τὴν ἀδελφὴν αὐτῶν καὶ τὰ ὑπάρχοντα αὐτῆς καὶ τὸν παῖδα τὸν Αβρααμ καὶ τοὺς μετ᾿ αὐτοῦ.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "וישלחו את רבקה אחותם ואת מינקתה ואת עבד אברהם ואת אנשיו",
        "translation": "Diferență reală, confirmată: וישלחו את רבקה אחותם ואת מינקתה ואת עבד אברהם ואת אנשיו — „And they sent away Rebekah their sister, and her nurse, and Abraham's servant, and his men.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 35:8"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Menționarea doicii Rebecăi — identificată tradițional, în afara acestui capitol, cu Devora amintită mai târziu la Geneza 35:8 — arată grija practică pentru însoțirea ei pe un drum lung."
      }
    ]
  },
  {
    "num": 60,
    "tokens": [
      {
        "t": "Au "
      },
      {
        "t": "binecuvântat-o",
        "w": "binecuvântat-o",
        "heb": "וַיְבָרֲכוּ",
        "translit": "vayevarakhu",
        "strong": "H1288",
        "pos": "verb",
        "greek": "εὐλόγησαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Au binecuvântat-o."
      },
      {
        "t": " pe "
      },
      {
        "t": "Rebeca",
        "w": "Rebeca",
        "heb": "אֶת־רִבְקָה",
        "translit": "et Rivkah",
        "strong": "H7259",
        "pos": "nume propriu",
        "greek": "Ρεβεκκαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Rebeca."
      },
      {
        "t": " și i-au "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמְרוּ",
        "translit": "vayomeru",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-au spus."
      },
      {
        "t": ": „"
      },
      {
        "t": "Sora",
        "w": "Sora",
        "heb": "אֲחֹתֵנוּ",
        "translit": "achotenu",
        "strong": "H269",
        "pos": "substantiv cu sufix",
        "greek": "ἀδελφὴ ἡμῶν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Sora."
      },
      {
        "t": " noastră, să devii "
      },
      {
        "t": "mii",
        "w": "mii",
        "heb": "לְאַלְפֵי",
        "translit": "le'alfei",
        "strong": "H505",
        "pos": "substantiv, stare construită",
        "greek": "εἰς χιλιάδας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "mii."
      },
      {
        "t": " de "
      },
      {
        "t": "miriade",
        "w": "miriade",
        "heb": "רְבָבָה",
        "translit": "revavah",
        "strong": "H7233",
        "pos": "substantiv",
        "greek": "μυριάδων",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "miriade."
      },
      {
        "t": ", iar "
      },
      {
        "t": "seminția",
        "w": "seminția",
        "heb": "זַרְעֵךְ",
        "translit": "zar'ekh",
        "strong": "H2233",
        "pos": "substantiv cu sufix",
        "greek": "τὸ σπέρμα σου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "seminția ta."
      },
      {
        "t": " ta să "
      },
      {
        "t": "moștenească",
        "w": "moștenească",
        "heb": "וְיִירַשׁ",
        "translit": "veyirash",
        "strong": "H3423",
        "pos": "verb",
        "greek": "κληρονομείτω",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să moștenească."
      },
      {
        "t": " "
      },
      {
        "t": "poarta",
        "w": "poarta",
        "heb": "שַׁעַר",
        "translit": "sha'ar",
        "strong": "H8179",
        "pos": "substantiv, stare construită",
        "greek": "τὰς πόλεις",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "poarta."
      },
      {
        "t": " "
      },
      {
        "t": "vrăjmașilor",
        "w": "vrăjmașilor",
        "heb": "שֹׂנְאָיו",
        "translit": "son'av",
        "strong": "H8130",
        "pos": "verb, participiu cu sufix",
        "greek": "τῶν ὑπεναντίων",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "vrăjmașilor."
      },
      {
        "t": " ei.”"
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיְבָרֲכוּ אֶת־רִבְקָה וַיֹּאמְרוּ לָהּ אֲחֹתֵנוּ אַתְּ הֲיִי לְאַלְפֵי רְבָבָה וְיִירַשׁ זַרְעֵךְ אֵת שַׁעַר שֹׂנְאָיו",
        "translation": "„Au binecuvântat-o pe Rebeca și i-au spus: „Sora noastră, să devii mii de miriade, iar seminția ta să moștenească poarta vrăjmașilor ei.”” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ εὐλόγησαν Ρεβεκκαν τὴν ἀδελφὴν αὐτῶν καὶ εἶπαν αὐτῇ Ἀδελφὴ ἡμῶν εἶ, γίνου εἰς χιλιάδας μυριάδων, καὶ κληρονομησάτω τὸ σπέρμα σου τὰς πόλεις τῶν ὑπεναντίων.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויברכו את רבקה ויאמרו לה אחותנו אתי הוי לאלפי רבבה ויירש זרעיך את שער איביו",
        "translation": "Diferență reală, confirmată: ויברכו את רבקה ויאמרו לה אחותנו אתי הוי לאלפי רבבה ויירש זרעיך את שער איביו — „And they blessed Rebekah, and said unto her, Thou [art] our sister, be thou [the mother] of thousands of millions, and let thy seed possess the gate of their enemies.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 17:16",
      "Geneza 22:17"
    ],
    "commentaries": [
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Leagă binecuvântarea „mii de miriade” de promisiunea făcută deja la Legarea lui Isaac (Geneza 22:17) — „urmașii tăi vor stăpâni porțile dușmanilor lor” — semn că familia Rebecăi repetă, poate fără să știe, o binecuvântare deja rostită."
      }
    ]
  },
  {
    "num": 61,
    "tokens": [
      {
        "t": "Apoi "
      },
      {
        "t": "Rebeca",
        "w": "Rebeca",
        "heb": "רִבְקָה",
        "translit": "Rivkah",
        "strong": "H7259",
        "pos": "nume propriu",
        "greek": "Ρεβεκκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Rebeca."
      },
      {
        "t": " s-a "
      },
      {
        "t": "sculat",
        "w": "sculat",
        "heb": "וַתָּקָם",
        "translit": "vatakam",
        "strong": "H6965",
        "pos": "verb",
        "greek": "ἀναστᾶσα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "s-a sculat."
      },
      {
        "t": " împreună cu "
      },
      {
        "t": "slujnicele",
        "w": "slujnicele",
        "heb": "וְנַעֲרֹתֶיהָ",
        "translit": "vena'aroteiha",
        "strong": "H5291",
        "pos": "substantiv cu sufix",
        "greek": "αἱ ἅβραι αὐτῆς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "slujnicele ei."
      },
      {
        "t": " ei; au "
      },
      {
        "t": "încălecat",
        "w": "încălecat",
        "heb": "וַתִּרְכַּבְנָה",
        "translit": "vatirkavnah",
        "strong": "H7392",
        "pos": "verb",
        "greek": "ἐπέβησαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "au încălecat."
      },
      {
        "t": " pe "
      },
      {
        "t": "cămile",
        "w": "cămile",
        "heb": "הַגְּמַלִּים",
        "translit": "hagemalim",
        "strong": "H1581",
        "pos": "substantiv, cu articol",
        "greek": "τὰς καμήλους",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămile."
      },
      {
        "t": " și au "
      },
      {
        "t": "mers",
        "w": "mers",
        "heb": "וַתֵּלַכְנָה",
        "translit": "vatelakhnah",
        "strong": "H1980",
        "pos": "verb",
        "greek": "ἐπορεύθησαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "au mers."
      },
      {
        "t": " după "
      },
      {
        "t": "om",
        "w": "om",
        "heb": "הָאִישׁ",
        "translit": "ha'ish",
        "strong": "H376",
        "pos": "substantiv, cu articol",
        "greek": "τοῦ ἀνθρώπου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "om."
      },
      {
        "t": "; și "
      },
      {
        "t": "slujitorul",
        "w": "slujitorul",
        "heb": "הָעֶבֶד",
        "translit": "ha'eved",
        "strong": "H5650",
        "pos": "substantiv, cu articol",
        "greek": "ὁ παῖς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "slujitorul."
      },
      {
        "t": " a "
      },
      {
        "t": "luat-o",
        "w": "luat-o",
        "heb": "וַיִּקַּח",
        "translit": "vayikach",
        "strong": "H3947",
        "pos": "verb",
        "greek": "ἀναλαβὼν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a luat-o."
      },
      {
        "t": " pe "
      },
      {
        "t": "Rebeca",
        "w": "Rebeca",
        "heb": "אֶת־רִבְקָה",
        "translit": "et Rivkah",
        "strong": "H7259",
        "pos": "nume propriu",
        "greek": "τὴν Ρεβεκκαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Rebeca."
      },
      {
        "t": " și a "
      },
      {
        "t": "plecat",
        "w": "plecat",
        "heb": "וַיֵּלַךְ",
        "translit": "vayelakh",
        "strong": "H1980",
        "pos": "verb",
        "greek": "ἀπῆλθεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a plecat."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַתָּקָם רִבְקָה וְנַעֲרֹתֶיהָ וַתִּרְכַּבְנָה עַל־הַגְּמַלִּים וַתֵּלַכְנָה אַחֲרֵי הָאִישׁ וַיִּקַּח הָעֶבֶד אֶת־רִבְקָה וַיֵּלַךְ",
        "translation": "„Apoi Rebeca s-a sculat împreună cu slujnicele ei; au încălecat pe cămile și au mers după om; și slujitorul a luat-o pe Rebeca și a plecat.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "ἀναστᾶσα δὲ Ρεβεκκα καὶ αἱ ἅβραι αὐτῆς ἐπέβησαν ἐπὶ τὰς καμήλους καὶ ἐπορεύθησαν μετὰ τοῦ ἀνθρώπου, καὶ ἀναλαβὼν ὁ παῖς τὴν Ρεβεκκαν ἀπῆλθεν.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ותקם רבקה ונערתיה ותרכבנה על הגמלים ותלכנה אחרי האיש ויקח העבד את רבקה וילך",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:64"
    ],
    "commentaries": [
      {
        "author": "Ramban / Nahmanide (1194–1270)",
        "text": "Notează grija slujitorului care „a luat pe Rebeca și a plecat” — abia ieșiți din cetate, cu toate femeile urmându-l, slujitorul a preluat-o direct pe Rebeca lângă el, ca s-o poată păzi de orice pericol pe drum. Citează și explicația alternativă a lui Ibn Ezra: fiind ocupat s-o însoțească pe Rebeca, slujitorul nici n-a mai observat lungimea și greutatea drumului, până când Isaac le-a ieșit în întâmpinare."
      }
    ]
  },
  {
    "num": 62,
    "tokens": [
      {
        "t": "Iar "
      },
      {
        "t": "Isaac",
        "w": "Isaac",
        "heb": "וְיִצְחָק",
        "translit": "veYitschak",
        "strong": "H3327",
        "pos": "nume propriu",
        "greek": "Ισαακ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Isaac."
      },
      {
        "t": " tocmai "
      },
      {
        "t": "venise",
        "w": "venise",
        "heb": "בָּא",
        "translit": "ba",
        "strong": "H935",
        "pos": "verb",
        "greek": "ἐπορεύετο",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "venise."
      },
      {
        "t": " de la "
      },
      {
        "t": "Beer-Lehai-Roi",
        "w": "Beer-Lehai-Roi",
        "heb": "בְּאֵר לַחַי רֹאִי",
        "translit": "Be'er Lachai Ro'i",
        "strong": "H883",
        "pos": "nume propriu",
        "greek": "τὸ φρέαρ τῆς ὁράσεως",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Beer-Lehai-Roi."
      },
      {
        "t": ", căci "
      },
      {
        "t": "locuia",
        "w": "locuia",
        "heb": "יוֹשֵׁב",
        "translit": "yoshev",
        "strong": "H3427",
        "pos": "verb, participiu",
        "greek": "κατῴκει",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "locuia."
      },
      {
        "t": " în "
      },
      {
        "t": "ținutul",
        "w": "ținutul",
        "heb": "בְּאֶרֶץ",
        "translit": "be'erets",
        "strong": "H776",
        "pos": "substantiv, stare construită",
        "greek": "ἐπὶ τὴν γῆν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ținutul."
      },
      {
        "t": " de la "
      },
      {
        "t": "miazăzi",
        "w": "miazăzi",
        "heb": "הַנֶּגֶב",
        "translit": "hanegev",
        "strong": "H5045",
        "pos": "substantiv, cu articol",
        "greek": "τὴν πρὸς λίβα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "miazăzi."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וְיִצְחָק בָּא מִבּוֹא בְּאֵר לַחַי רֹאִי וְהוּא יוֹשֵׁב בְּאֶרֶץ הַנֶּגֶב",
        "translation": "„Iar Isaac tocmai venise de la Beer-Lehai-Roi, căci locuia în ținutul de la miazăzi.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "Ισαακ δὲ ἐπορεύετο διὰ τῆς ἐρήμου κατὰ τὸ φρέαρ τῆς ὁράσεως· αὐτὸς δὲ κατῴκει ἐν τῇ γῇ τῇ πρὸς λίβα.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויצחק בא במדבר באר לחי ראה והוא ישב בארץ הנגב",
        "translation": "Diferență reală, confirmată: ויצחק בא במדבר באר לחי ראה והוא ישב בארץ הנגב — „And Isaac came from the wilderness of the well Lahai-roi; for he dwelt in the south country.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 25:11",
      "Geneza 16:14"
    ],
    "commentaries": [
      {
        "author": "Ramban / Nahmanide (1194–1270)",
        "text": "Explică precizarea „venea de la Beer-Lahai-Roi”: Isaac nu locuia acolo, ci se întorcea dintr-o vizită scurtă — loc de rugăciune pentru el, legat de întâlnirea îngerului cu Hagar. Ramban notează și traducerea lui Onkelos, care identifică Beer-Lahai-Roi aproape de Beer-Șeba."
      },
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Precizează aceeași idee prin comparație gramaticală cu alte pasaje („până la Sodoma”): Isaac locuia în Neghev, aproape de Beer-Lahai-Roi, și se întorcea în cetatea lui în ziua sosirii slujitorului."
      }
    ]
  },
  {
    "num": 63,
    "tokens": [
      {
        "t": "Isaac",
        "w": "Isaac",
        "heb": "יִצְחָק",
        "translit": "Yitschak",
        "strong": "H3327",
        "pos": "nume propriu",
        "greek": "Ισαακ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Isaac."
      },
      {
        "t": " a "
      },
      {
        "t": "ieșit",
        "w": "ieșit",
        "heb": "וַיֵּצֵא",
        "translit": "vayetse",
        "strong": "H3318",
        "pos": "verb",
        "greek": "καὶ ἐξῆλθεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a ieșit."
      },
      {
        "t": " să "
      },
      {
        "t": "cugete",
        "w": "cugete",
        "heb": "לָשׂוּחַ",
        "translit": "lasu'ach",
        "strong": "H7742",
        "pos": "verb (infinitiv)",
        "greek": "ἀδολεσχῆσαι",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "să cugete."
      },
      {
        "t": " pe "
      },
      {
        "t": "câmp",
        "w": "câmp",
        "heb": "בַּשָּׂדֶה",
        "translit": "basadeh",
        "strong": "H7704",
        "pos": "substantiv, cu prefix",
        "greek": "τῷ πεδίῳ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "câmp."
      },
      {
        "t": " pe "
      },
      {
        "t": "înserat",
        "w": "înserat",
        "heb": "לִפְנוֹת עֶרֶב",
        "translit": "lifnot erev",
        "strong": "H6437",
        "pos": "substantiv",
        "greek": "τὸ δειλινόν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "pe înserat."
      },
      {
        "t": "; și-a "
      },
      {
        "t": "ridicat",
        "w": "ridicat",
        "heb": "וַיִּשָּׂא",
        "translit": "vayisa",
        "strong": "H5375",
        "pos": "verb",
        "greek": "ἀναβλέψας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "și-a ridicat."
      },
      {
        "t": " "
      },
      {
        "t": "ochii",
        "w": "ochii",
        "heb": "עֵינָיו",
        "translit": "einav",
        "strong": "H5869",
        "pos": "substantiv cu sufix",
        "greek": "τοῖς ὀφθαλμοῖς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ochii lui."
      },
      {
        "t": " și a "
      },
      {
        "t": "văzut",
        "w": "văzut",
        "heb": "וַיַּרְא",
        "translit": "vayar",
        "strong": "H7200",
        "pos": "verb",
        "greek": "εἶδεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a văzut."
      },
      {
        "t": " și iată, "
      },
      {
        "t": "veneau",
        "w": "veneau",
        "heb": "בָּאִים",
        "translit": "ba'im",
        "strong": "H935",
        "pos": "verb, participiu",
        "greek": "ἐρχομένας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "veneau."
      },
      {
        "t": " "
      },
      {
        "t": "cămile",
        "w": "cămile",
        "heb": "גְמַלִּים",
        "translit": "gemalim",
        "strong": "H1581",
        "pos": "substantiv",
        "greek": "καμήλους",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămile."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיֵּצֵא יִצְחָק לָשׂוּחַ בַּשָּׂדֶה לִפְנוֹת עָרֶב וַיִּשָּׂא עֵינָיו וַיַּרְא וְהִנֵּה גְמַלִּים בָּאִים",
        "translation": "„Isaac a ieșit să cugete pe câmp pe înserat; și-a ridicat ochii și a văzut și iată, veneau cămile.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἐξῆλθεν Ισαακ ἀδολεσχῆσαι εἰς τὸ πεδίον τὸ δειλινόν καὶ ἀναβλέψας τοῖς ὀφθαλμοῖς εἶδεν καμήλους ἐρχομένας.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויצא יצחק לשוח בשדה לפנות ערב וישא עיניו וירא והנה הגמלים באים",
        "translation": "Diferență reală, confirmată: ויצא יצחק לשוח בשדה לפנות ערב וישא עיניו וירא והנה הגמלים באים — „And Isaac went out to meditate in the field at the eventide: and he lifted up his eyes, and saw, and, behold, the camels [were] coming.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Psalmul 1:2",
      "Psalmul 77:12"
    ],
    "commentaries": [
      {
        "author": "Rashbam (cca. 1085–1158)",
        "text": "Explică „lasuach” (a cugeta/a vorbi) prin paralela cu „tufișurile câmpului” din Geneza 2:5 — Isaac ieșise să vadă de lucrătorii și livezile sale; acolo, în câmp, a văzut cămilele venind și a mers să vadă dacă sunt ale tatălui său."
      },
      {
        "author": "Talmud Babilonian, Berakhot 26b (verificat direct în arhivă)",
        "text": "Talmudul citează exact acest verset ca temei pentru instituirea rugăciunii de after-amiază (Minha): „Isaac a instituit rugăciunea de după-amiază, după cum se spune: «Și Isaac a ieșit să cugete (lasuach) pe câmp, spre seară»” — iar „a cugeta” înseamnă aici rugăciune, paralel cu Psalmul 102:1, „o rugăciune a celui asuprit, când e doborât și își revarsă plângerea înaintea DOMNULUI”."
      }
    ]
  },
  {
    "num": 64,
    "tokens": [
      {
        "t": "Rebeca",
        "w": "Rebeca",
        "heb": "רִבְקָה",
        "translit": "Rivkah",
        "strong": "H7259",
        "pos": "nume propriu",
        "greek": "Ρεβεκκα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Rebeca."
      },
      {
        "t": " și-a "
      },
      {
        "t": "ridicat",
        "w": "ridicat",
        "heb": "וַתִּשָּׂא",
        "translit": "vatisa",
        "strong": "H5375",
        "pos": "verb",
        "greek": "ἀναβλέψασα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "și-a ridicat."
      },
      {
        "t": " "
      },
      {
        "t": "ochii",
        "w": "ochii",
        "heb": "עֵינֶיהָ",
        "translit": "eineiha",
        "strong": "H5869",
        "pos": "substantiv cu sufix",
        "greek": "τοῖς ὀφθαλμοῖς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "ochii ei."
      },
      {
        "t": " și l-a "
      },
      {
        "t": "văzut",
        "w": "văzut",
        "heb": "וַתֵּרֶא",
        "translit": "vatere",
        "strong": "H7200",
        "pos": "verb",
        "greek": "εἶδεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "l-a văzut."
      },
      {
        "t": " pe "
      },
      {
        "t": "Isaac",
        "w": "Isaac",
        "heb": "אֶת־יִצְחָק",
        "translit": "et Yitschak",
        "strong": "H3327",
        "pos": "nume propriu",
        "greek": "τὸν Ισαακ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Isaac."
      },
      {
        "t": " și s-a "
      },
      {
        "t": "înclinat",
        "w": "înclinat",
        "heb": "וַתִּפֹּל",
        "translit": "vatipol",
        "strong": "H5307",
        "pos": "verb",
        "greek": "κατεπήδησεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "s-a înclinat."
      },
      {
        "t": " de pe "
      },
      {
        "t": "cămilă",
        "w": "cămilă",
        "heb": "הַגָּמָל",
        "translit": "hagamal",
        "strong": "H1581",
        "pos": "substantiv, cu articol",
        "greek": "τῆς καμήλου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cămilă."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַתִּשָּׂא רִבְקָה אֶת־עֵינֶיהָ וַתֵּרֶא אֶת־יִצְחָק וַתִּפֹּל מֵעַל הַגָּמָל",
        "translation": "„Rebeca și-a ridicat ochii și l-a văzut pe Isaac și s-a înclinat de pe cămilă.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ ἀναβλέψασα Ρεβεκκα τοῖς ὀφθαλμοῖς εἶδεν τὸν Ισαακ καὶ κατεπήδησεν ἀπὸ τῆς καμήλου",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ותשא רבקה את עיניה ותרא את יצחק ותפל מעל הגמל",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:19"
    ],
    "commentaries": [
      {
        "author": "Ramban / Nahmanide (1194–1270)",
        "text": "Citează o interpretare atribuită lui Rashi: Rebeca a văzut că Isaac era impunător/strălucitor și s-a simțit stânjenită în fața lui. Notează și explicația lui Ibn Ezra despre ordinea evenimentelor: propoziția „ea a spus slujitorului” ar trebui înțeleasă ca „ea îi spusese deja”, o inversiune de ordine frecventă în Tora."
      }
    ]
  },
  {
    "num": 65,
    "tokens": [
      {
        "t": "Și i-a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַתֹּאמֶר",
        "translit": "vatomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-a spus."
      },
      {
        "t": " "
      },
      {
        "t": "slujitorului",
        "w": "slujitorului",
        "heb": "אֶל־הָעֶבֶד",
        "translit": "el ha'eved",
        "strong": "H5650",
        "pos": "substantiv, cu articol",
        "greek": "τῷ παιδί",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "slujitorului."
      },
      {
        "t": ": „Cine-i acel "
      },
      {
        "t": "om",
        "w": "om",
        "heb": "הָאִישׁ",
        "translit": "ha'ish",
        "strong": "H376",
        "pos": "substantiv, cu articol",
        "greek": "ὁ ἄνθρωπος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "om."
      },
      {
        "t": " care "
      },
      {
        "t": "merge",
        "w": "merge",
        "heb": "הַהֹלֵךְ",
        "translit": "haholekh",
        "strong": "H1980",
        "pos": "verb, participiu, cu articol",
        "greek": "πορευόμενος",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "merge."
      },
      {
        "t": " pe "
      },
      {
        "t": "câmp",
        "w": "câmp",
        "heb": "בַּשָּׂדֶה",
        "translit": "basadeh",
        "strong": "H7704",
        "pos": "substantiv, cu prefix",
        "greek": "τῷ πεδίῳ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "câmp."
      },
      {
        "t": " în "
      },
      {
        "t": "întâmpinarea",
        "w": "întâmpinarea",
        "heb": "לִקְרָאתֵנוּ",
        "translit": "likratenu",
        "strong": "H7125",
        "pos": "substantiv cu sufix",
        "greek": "εἰς συνάντησιν ἡμῖν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "întâmpinarea noastră."
      },
      {
        "t": " noastră?” Și a "
      },
      {
        "t": "spus",
        "w": "spus",
        "heb": "וַיֹּאמֶר",
        "translit": "vayomer",
        "strong": "H559",
        "pos": "verb",
        "greek": "εἶπεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a spus."
      },
      {
        "t": " "
      },
      {
        "t": "slujitorul",
        "w": "slujitorul",
        "heb": "הָעֶבֶד",
        "translit": "ha'eved",
        "strong": "H5650",
        "pos": "substantiv, cu articol",
        "greek": "ὁ παῖς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "slujitorul."
      },
      {
        "t": ": „Este "
      },
      {
        "t": "stăpânul",
        "w": "stăpânul",
        "heb": "אֲדֹנִי",
        "translit": "adoni",
        "strong": "H113",
        "pos": "substantiv cu sufix",
        "greek": "ὁ κύριός μου",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "stăpânul."
      },
      {
        "t": " meu.” Și ea a "
      },
      {
        "t": "luat",
        "w": "luat",
        "heb": "וַתִּקַּח",
        "translit": "vatikach",
        "strong": "H3947",
        "pos": "verb",
        "greek": "λαβοῦσα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a luat."
      },
      {
        "t": " "
      },
      {
        "t": "voalul",
        "w": "voalul",
        "heb": "הַצָּעִיף",
        "translit": "hatsa'if",
        "strong": "H6809",
        "pos": "substantiv, cu articol",
        "greek": "τὸ θέριστρον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "voalul."
      },
      {
        "t": " și s-a "
      },
      {
        "t": "acoperit",
        "w": "acoperit",
        "heb": "וַתִּתְכָּס",
        "translit": "vatitkas",
        "strong": "H3680",
        "pos": "verb",
        "greek": "περιεβάλετο",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "s-a acoperit."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַתֹּאמֶר אֶל־הָעֶבֶד מִי־הָאִישׁ הַלָּזֶה הַהֹלֵךְ בַּשָּׂדֶה לִקְרָאתֵנוּ וַיֹּאמֶר הָעֶבֶד הוּא אֲדֹנִי וַתִּקַּח הַצָּעִיף וַתִּתְכָּס",
        "translation": "„Și i-a spus slujitorului: „Cine-i acel om care merge pe câmp în întâmpinarea noastră?” Și a spus slujitorul: „Este stăpânul meu.” Și ea a luat voalul și s-a acoperit.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ εἶπεν τῷ παιδί Τίς ἐστιν ὁ ἄνθρωπος ἐκεῖνος ὁ πορευόμενος ἐν τῷ πεδίῳ εἰς συνάντησιν ἡμῖν; εἶπεν δὲ ὁ παῖς Οὗτός ἐστιν ὁ κύριός μου. ἡ δὲ λαβοῦσα τὸ θέριστρον περιεβάλετο.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ותאמר אל העבד מי האיש הלז ההלך בשדה לקראתנו ויאמר העבד הוא אדני ותקח הצעיף ותתכס",
        "translation": "Diferență reală, confirmată: ותאמר אל העבד מי האיש הלז ההלך בשדה לקראתנו ויאמר העבד הוא אדני ותקח הצעיף ותתכס — „For she [had] said unto the servant, What man [is] this that walketh in the field to meet us? And the servant [had] said, It [is] my master: therefore she took a veil, and covered herself.”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "1 Corinteni 11:6,10"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Gestul Rebecăi de a coborî de pe cămilă la vederea lui Isaac și de a se acoperi cu voal (v.65) e citit ca recunoaștere instinctivă a cuiva important, urmată de un gest de modestie premarital."
      }
    ]
  },
  {
    "num": 66,
    "tokens": [
      {
        "t": "Și "
      },
      {
        "t": "slujitorul",
        "w": "slujitorul",
        "heb": "הָעֶבֶד",
        "translit": "ha'eved",
        "strong": "H5650",
        "pos": "substantiv, cu articol",
        "greek": "ὁ παῖς",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "slujitorul."
      },
      {
        "t": " i-a "
      },
      {
        "t": "povestit",
        "w": "povestit",
        "heb": "וַיְסַפֵּר",
        "translit": "vayesaper",
        "strong": "H5608",
        "pos": "verb",
        "greek": "διηγήσατο",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-a povestit."
      },
      {
        "t": " lui "
      },
      {
        "t": "Isaac",
        "w": "Isaac",
        "heb": "לְיִצְחָק",
        "translit": "leYitschak",
        "strong": "H3327",
        "pos": "nume propriu",
        "greek": "τῷ Ισαακ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Isaac."
      },
      {
        "t": " toate "
      },
      {
        "t": "lucrurile",
        "w": "lucrurile",
        "heb": "הַדְּבָרִים",
        "translit": "hadevarim",
        "strong": "H1697",
        "pos": "substantiv, cu articol",
        "greek": "πάντα τὰ ῥήματα",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "lucrurile."
      },
      {
        "t": " pe care le "
      },
      {
        "t": "făcuse",
        "w": "făcuse",
        "heb": "עָשָׂה",
        "translit": "asah",
        "strong": "H6213",
        "pos": "verb",
        "greek": "ἐποίησεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "le făcuse."
      },
      {
        "t": "."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיְסַפֵּר הָעֶבֶד לְיִצְחָק אֵת כָּל־הַדְּבָרִים אֲשֶׁר עָשָׂה",
        "translation": "„Și slujitorul i-a povestit lui Isaac toate lucrurile pe care le făcuse.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "καὶ διηγήσατο ὁ παῖς τῷ Ισαακ πάντα τὰ ῥήματα, ἃ ἐποίησεν.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויספר העבד ליצחק את כל הדברים אשר עשה",
        "translation": "Verificat direct: conținutul e identic cu Textul Masoretic la acest verset — fără variante.",
        "note": "Confirmat prin comparație directă cuvânt-cu-cuvânt cu textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "Geneza 24:34-49"
    ],
    "commentaries": [
      {
        "author": "Notă contextuală (sinteză editorială — sursele verificate în arhivă tac la acest verset)",
        "text": "Relatarea completă a slujitorului către Isaac repetă, pentru al treilea ascultător (după Rebeca și familia ei), aceeași poveste — transparență totală asupra întregii misiuni."
      }
    ]
  },
  {
    "num": 67,
    "tokens": [
      {
        "t": "Și "
      },
      {
        "t": "Isaac",
        "w": "Isaac",
        "heb": "יִצְחָק",
        "translit": "Yitschak",
        "strong": "H3327",
        "pos": "nume propriu",
        "greek": "Ισαακ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Isaac."
      },
      {
        "t": " a "
      },
      {
        "t": "adus-o",
        "w": "adus-o",
        "heb": "וַיְבִאֶהָ",
        "translit": "vayevi'eha",
        "strong": "H935",
        "pos": "verb, cu sufix",
        "greek": "εἰσήγαγεν δὲ αὐτὴν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a adus-o."
      },
      {
        "t": " în "
      },
      {
        "t": "cortul",
        "w": "cortul",
        "heb": "הָאֹהֱלָה",
        "translit": "ha'ohelah",
        "strong": "H168",
        "pos": "substantiv, cu articol",
        "greek": "τὸν οἶκον",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "cortul."
      },
      {
        "t": " mamei sale "
      },
      {
        "t": "Sara",
        "w": "Sara",
        "heb": "שָׂרָה",
        "translit": "Sarah",
        "strong": "H8283",
        "pos": "nume propriu",
        "greek": "Σαρρας",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Sara."
      },
      {
        "t": ", a "
      },
      {
        "t": "luat-o",
        "w": "luat-o",
        "heb": "וַיִּקַּח",
        "translit": "vayikach",
        "strong": "H3947",
        "pos": "verb",
        "greek": "ἔλαβεν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a luat-o."
      },
      {
        "t": " pe "
      },
      {
        "t": "Rebeca",
        "w": "Rebeca",
        "heb": "אֶת־רִבְקָה",
        "translit": "et Rivkah",
        "strong": "H7259",
        "pos": "nume propriu",
        "greek": "τὴν Ρεβεκκαν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Rebeca."
      },
      {
        "t": " și ea i-a "
      },
      {
        "t": "devenit",
        "w": "devenit",
        "heb": "וַתְּהִי",
        "translit": "vatehi",
        "strong": "H1961",
        "pos": "verb",
        "greek": "ἐγένετο",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "i-a devenit."
      },
      {
        "t": " "
      },
      {
        "t": "soție",
        "w": "soție",
        "heb": "לְאִשָּׁה",
        "translit": "le'ishah",
        "strong": "H802",
        "pos": "substantiv",
        "greek": "γυνή",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "soție."
      },
      {
        "t": " și a "
      },
      {
        "t": "iubit-o",
        "w": "iubit-o",
        "heb": "וַיֶּאֱהָבֶהָ",
        "translit": "vaye'ehaveha",
        "strong": "H157",
        "pos": "verb, cu sufix",
        "greek": "ἠγάπησεν αὐτήν",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a iubit-o."
      },
      {
        "t": "; și "
      },
      {
        "t": "Isaac",
        "w": "Isaac",
        "heb": "יִצְחָק",
        "translit": "Yitschak",
        "strong": "H3327",
        "pos": "nume propriu",
        "greek": "Ισαακ",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "Isaac."
      },
      {
        "t": " a fost "
      },
      {
        "t": "consolat",
        "w": "consolat",
        "heb": "וַיִּנָּחֵם",
        "translit": "vayinachem",
        "strong": "H5162",
        "pos": "verb",
        "greek": "παρεκλήθη",
        "samaritan": "presupus apropiat de Textul Masoretic la acest cuvânt — nu verificat individual cuvânt cu cuvânt.",
        "def": "a fost consolat."
      },
      {
        "t": " după mama sa."
      }
    ],
    "textCompare": [
      {
        "source": "Textul Masoretic (ebraică)",
        "original": "וַיְבִאֶהָ יִצְחָק הָאֹהֱלָה שָׂרָה אִמּוֹ וַיִּקַּח אֶת־רִבְקָה וַתְּהִי־לוֹ לְאִשָּׁה וַיֶּאֱהָבֶהָ וַיִּנָּחֵם יִצְחָק אַחֲרֵי אִמּוֹ",
        "translation": "„Și Isaac a adus-o în cortul mamei sale Sara, a luat-o pe Rebeca și ea i-a devenit soție și a iubit-o; și Isaac a fost consolat după mama sa.” — traducerea rabinului Rosen.",
        "note": ""
      },
      {
        "source": "Septuaginta (greacă)",
        "original": "εἰσῆλθεν δὲ Ισαακ εἰς τὸν οἶκον τῆς μητρὸς αὐτοῦ καὶ ἔλαβεν τὴν Ρεβεκκαν, καὶ ἐγένετο αὐτοῦ γυνή, καὶ ἠγάπησεν αὐτήν· καὶ παρεκλήθη Ισαακ περὶ Σαρρας τῆς μητρὸς αὐτοῦ.",
        "greek": true,
        "translation": "",
        "note": ""
      },
      {
        "source": "Pentateuhul Samaritean",
        "original": "ויביאה יצחק האהלה שרה אמו ויקח את רבקה ותהי לו לאשה ויאהבה וינחם יצחק אחרי אמו",
        "translation": "Diferență reală, confirmată: ויביאה יצחק האהלה שרה אמו ויקח את רבקה ותהי לו לאשה ויאהבה וינחם יצחק אחרי אמו — „And Isaac brought her into his mother Sarah's tent, and took Rebekah, and she became his wife; and he loved her: and Isaac was comforted after his mother's [death].”",
        "note": "Verificat direct în textul samaritean real (Schorch, ed. critică 2018, ms. Chester Beatty 751)."
      }
    ],
    "refs": [
      "1 Corinteni 7:2",
      "Geneza 25:20"
    ],
    "commentaries": [
      {
        "author": "Rashi (1040–1105)",
        "text": "Leagă intrarea Rebecăi în cortul mamei sale decedate de o tradiție: cât timp trăia Sara, în cortul ei ardea o candelă din ajun de Șabat până în ajun de Șabat, aluatul frământat era binecuvântat, iar un nor de protecție stătea deasupra cortului; la moartea ei, toate acestea au încetat — iar la intrarea Rebecăi, au reapărut."
      },
      {
        "author": "Ramban / Nahmanide (1194–1270)",
        "text": "Explică de ce Isaac o duce pe Rebeca tocmai în cortul Sarei: din respect pentru mama sa, cortul ei nu fusese ocupat de nimeni de la moartea ei — „să nu intre altă femeie în cortul stăpânei cinstite” — dar la sosirea Rebecăi, Isaac i l-a oferit ei, ca onoare. Leagă mângâierea lui Isaac de golul lăsat de moartea mamei, umplut acum prin dragostea pentru soția sa — motivul, spune Ramban, pentru care Tora menționează explicit iubirea unui bărbat față de soția lui, lucru neobișnuit de subliniat altfel."
      }
    ]
  }
];
